package member.service;

import game.HancomVO;

import java.util.List;
import java.util.Map;

import product.productVO.ProductVO;
import member.memberVO.MemberVO;

public interface IMemberService {

	   // 고객
	   /*
	    * 회원가입 memberCreate() : 회원가입 - 입력받은 값을 Check들을 불러확인하는 작업 - memberCheck() :
	    * 중복아이디확인(전화번호), 맞는form인지
	    */

	   /**
	    * memberList에 있는 리스트들을 갖고와서 회원가입 시 Number 중복 체크를 한다.
	    * 성공적으로 수행 시 true 값 리턴
	    * 회원들의 정보를 hash맵에 저장한 뒤 최종적으로 List에 적재시키는 역할을 수행한다.
	    * 
	    * @param MemberVO
	    *            newMember
	    * @return boolean true(가입성공) / false(가입실패)
	    */
	   public boolean memberCreate(MemberVO newMember);// memberCheck들을 호출

	   /**
	    * 입력되는 전화번호가 올바른 form인지 확인 후 값이 맞을경우 true값 리턴 matchpattern
	    * 
	    * @param memberTel
	    * @return boolean (중복이면 1, 중복값이 없으면 0)
	    */
	   public boolean memberCheckNum(String memberTel);
	   
	   //@@kjy
	   /**
	    * 개인 회원의 회원정보 수정
	    * @param changeMyInfo
	    * @return
	    */
	   public boolean memberUpdate(Map<String, String> changeMyInfo);

	   
	 //회원정보수정(관리자) , interface
	   /**
	    * 회원정보 수정 메뉴 String 형태의 키 값을 갖고 사용자가 원하는 정보를 수정해줌.
	    * @param updateSend
	    * @return
	    */
	   public boolean updateMemberInfo(Map<String, String> updateSend);

	   /*
	    * 회원모드(주문) login() : login하는것 loginCheck() : ID, PW 체크 productOrder() :
	    * 주문상품확인, 재고확인, 금액반환,StampCheck productRceipt() : 영수증출력
	    */

	   /**
	    * 매서드 내에서 member객체에 저장되어있는 login, pw 값 대조 후, 없다면 관리자 id, pw와 일치하는지 확인.
	    * login 후 view에 로그인 한 사람의 정보를 저장한 뒤 지속적으로 접근 가능하도록 반환타입은 MemberVO
	    * 
	    * @param loginInfo
	    * @return MemberVO
	    */
	   public MemberVO loginCheck(Map<String, String> loginInfo);

	   /**
	    * id와 pw를 Map에 저장된 키, value값과 비교하여 
	    * 같을 경우 true 리턴, 다를 경우 false 리턴
	    * @param loginInfo
	    * @return 
	    */
	   public boolean loginAdmin(Map<String, String> loginInfo);
	   
	   /**
	    * 회원리스트에있는 전화번호와 대조하여 일치하는 경우
	    * 해당 VO를 넘겨받는 메서드
	    * @param memberNumber
	    * @return
	    */
	   public List<MemberVO> searchMemberInfo0(String memberNumber);
	   
	   public MemberVO searchMemberInfo(String memberNumber);
	   
	   //회원삭제 implement
	   /**
	    * 회원 삭제 시 member의 Number를 입력받아 해당 내용을 삭제해준다.
	    * list에 있는 값이 삭제 시 true, 삭제 불가 시 false 리턴
	    * @param memberNumber
	    * @return
	    */
	   public boolean deleteMember(String memberNumber);

	   /**
	    * Member의 summary를 받아서 Member의 구매내역에 저장한다.
	    * @return 
	    */
		public boolean memberSummaryVO(Map<String, ProductVO> summary);

		/**
		 * 회원의 전화번호를 입력받아 영수증의 총 합을 반환함
		 * @param memeberNumber
		 * @return int
		 */
		public int allSum(String memberNumber);
		
		/**
		 * 해당 member의 영수증을 반환해준다.
		 * @param memberNumber
		 * @return member summary List
		 */
		public List<ProductVO> memberGetSummary(String memberNumber);

	   // 관리자
	   /*
	    * 로그인 login(), loginCheck() : 관리자 ID, PW확인하는 메서드 //중복임
	    */
	   /*
	    * 회원관리 memberAll() : 전체 회원 출력 memberRead() : 특정 회원정보확인 memberUpdate() : 특정
	    * 회원정보수정 memberDelete() : 특정 회원탈퇴
	    */

	   /**
	    * DB클래스에서 회원 리스트를 뽑아준다.
	    */
	   public List<MemberVO> memberAll();
	   
	   /**
	    * 특정 회원의 전화번호를 통해 회원의 정보를 출력해준다.
	    * @param memberNum
	    * @return MemberVO
	    */
	   public MemberVO memberSearchNum(String memberNum);

	   boolean getMemberExcel();
	   
	   boolean getSummaryPDF(String memberNumber);
	   
	   public boolean hancomplay(String memberId);
	   
	   public List<HancomVO> hancomview(String memberId);

	   public void hangMan();
	
}
