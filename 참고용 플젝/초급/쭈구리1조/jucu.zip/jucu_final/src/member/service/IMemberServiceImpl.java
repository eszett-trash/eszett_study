package member.service;

import game.HancomPlay;
import game.HancomVO;
import game.HangManPlay;

import java.util.List;
import java.util.Map;

import common.Utill;
import product.productVO.ProductVO;
import member.dao.IMemberDao;
import member.dao.IMemberDaoImpl;
import member.memberVO.MemberVO;

public class IMemberServiceImpl implements IMemberService {

	private HancomPlay hn = new HancomPlay();
	private static IMemberService service = null;
	private IMemberDao dao = null;
	Utill ut = new Utill();
	HangManPlay hmp = new HangManPlay();
	
	private IMemberServiceImpl(){
		dao = IMemberDaoImpl.getInstance();
	}
	
	public static IMemberService getInstance() {
		if(service==null){
			service = new IMemberServiceImpl();
		}
		return service;
	}

	@Override
	public boolean memberCreate(MemberVO newMember) {
		return dao.memberCreate(newMember);
	}

	@Override
	public boolean memberCheckNum(String memberTel) {
		return dao.memberCheckNum(memberTel);
	}

	@Override
	public boolean memberUpdate(Map<String, String> changeMyInfo) {
		return dao.memberUpdate(changeMyInfo);
	}

	@Override
	public boolean updateMemberInfo(Map<String, String> updateSend) {
		return dao.updateMemberInfo(updateSend);
	}

	@Override
	public MemberVO loginCheck(Map<String, String> loginInfo) {
		return dao.loginCheck(loginInfo);
	}

	@Override
	public boolean loginAdmin(Map<String, String> loginInfo) {
		return dao.loginAdmin(loginInfo);
	}

	@Override
	public List<MemberVO> searchMemberInfo0(String memberNumber) {
		return dao.searchMemberInfo0(memberNumber);
	}

	@Override
	public MemberVO searchMemberInfo(String memberNumber) {
		return dao.searchMemberInfo(memberNumber);
	}

	@Override
	public boolean deleteMember(String memberNumber) {
		return dao.deleteMember(memberNumber);
	}

	@Override
	public boolean memberSummaryVO(Map<String, ProductVO> summary) {
		return dao.memberSummaryVO(summary);
	}

	@Override
	public int allSum(String memberNumber) {
		return dao.allSum(memberNumber);
	}

	@Override
	public List<ProductVO> memberGetSummary(String memberNumber) {
		return dao.memberGetSummary(memberNumber);
	}

	@Override
	public List<MemberVO> memberAll() {
		return dao.memberAll();
	}

	@Override
	public MemberVO memberSearchNum(String memberNum) {
		return dao.memberSearchNum(memberNum);
	}
	
	@Override
	public boolean getMemberExcel(){
		return ut.memberListExcel(dao.memberAll());
	}

	@Override
	public boolean getSummaryPDF(String memberNumber) {
		try {
			return ut.summaryPDF(dao.memberGetSummary(memberNumber));
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public boolean hancomplay(String memberId) {
		return dao.hancomplay(hn.gameStart(memberId));
	}

	@Override
	public List<HancomVO> hancomview(String memberId) {
		return dao.hancomView(memberId);
	}

	@Override
	public void hangMan() {
		hmp.play();
	}
	
	
}
