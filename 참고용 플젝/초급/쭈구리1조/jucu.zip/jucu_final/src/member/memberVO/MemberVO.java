package member.memberVO;

import java.util.ArrayList;
import java.util.List;

import game.*;

public class MemberVO {
	
	private String memberNumber; // 아이디기능의 전화번호
	private String memberName; // pw기능의 이름
	private String memberEmail; // 회원 이메일
	private int memberStamp; // 스탬프 //주스 한개 살때마다 특수문자 하나 추가됨 ♥
	private List<HancomVO> hancomRecord= new ArrayList<HancomVO>();

	public String getMemberNumber() {
		return memberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberEmail() {
		return memberEmail;
	}

	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}

	public int getMemberStamp() {
		return memberStamp;
	}

	public void setMemberStamp(int memberStamp) {
		this.memberStamp = memberStamp;
	}


	public List<HancomVO> getHancomRecord() {
		return hancomRecord;
	}

	public void setHancomRecord(HancomVO hancomRecord) {
		this.hancomRecord.add(hancomRecord);
	}
	@Override
	public String toString() {
		return "MemberVO [memberNumber=" + memberNumber + ", memberName="
				+ memberName + ", memberEmail=" + memberEmail
				+ ", memberStamp=" + memberStamp + "]";
	}
}
