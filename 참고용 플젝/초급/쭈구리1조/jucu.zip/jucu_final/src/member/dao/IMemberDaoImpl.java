package member.dao;

import game.HancomVO;

import java.util.List;
import java.util.Map;

import member.memberVO.MemberVO;
import product.productVO.ProductVO;
import db.DBclass;

public class IMemberDaoImpl implements IMemberDao {
	
	private static IMemberDao dao = null;
	private DBclass db = null;
	
	private IMemberDaoImpl(){
		db = DBclass.getInstance();
	}
	
	public static IMemberDao getInstance() {
		if(dao == null){
			dao = new IMemberDaoImpl();
		}
		return dao;
	}

	@Override
	public boolean memberCreate(MemberVO newMember) {
		return db.memberCreate(newMember);
	}

	@Override
	public boolean memberCheckNum(String memberTel) {
		return db.memberCheckNum(memberTel);
	}

	@Override
	public boolean memberUpdate(Map<String, String> changeMyInfo) {
		return db.memberUpdate(changeMyInfo);
	}

	@Override
	public boolean updateMemberInfo(Map<String, String> updateSend) {
		return db.updateMemberInfo(updateSend);
	}

	@Override
	public MemberVO loginCheck(Map<String, String> loginInfo) {
		return db.loginCheck(loginInfo);
	}

	@Override
	public boolean loginAdmin(Map<String, String> loginInfo) {
		return db.loginAdmin(loginInfo);
	}

	@Override
	public List<MemberVO> searchMemberInfo0(String memberNumber) {
		return db.searchMemberInfo0(memberNumber);
	}

	@Override
	public MemberVO searchMemberInfo(String memberNumber) {
		return db.searchMemberInfo(memberNumber);
	}

	@Override
	public boolean deleteMember(String memberNumber) {
		return db.deleteMember(memberNumber);
	}

	@Override
	public boolean memberSummaryVO(Map<String, ProductVO> summary) {
		return db.memberSummaryVO(summary);
	}

	@Override
	public int allSum(String memberNumber) {
		return db.allSum(memberNumber);
	}

	@Override
	public List<ProductVO> memberGetSummary(String memberNumber) {
		return db.memberGetSummary(memberNumber);
	}

	@Override
	public List<MemberVO> memberAll() {
		return db.memberAll();
	}

	@Override
	public MemberVO memberSearchNum(String memberNum) {
		return db.memberSearchNum(memberNum);
	}

	@Override
	public boolean hancomplay(HancomVO gameend) {
		return db.hancomplay(gameend);
	}

	@Override
	public List<HancomVO> hancomView(String memberId) {
		return db.hancomView(memberId);
	}

}
