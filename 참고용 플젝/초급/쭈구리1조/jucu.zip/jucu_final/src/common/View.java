package common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import product.productVO.ProductVO;
import product.recordVO.RecordVO;
import product.service.IProductService;
import product.service.IProductServiceImpl;
import sun.print.resources.serviceui;
import member.memberVO.MemberVO;
import member.service.IMemberService;
import member.service.IMemberServiceImpl;

public class View {
	private static IMemberService mService = IMemberServiceImpl.getInstance();
	private static IProductService pService = IProductServiceImpl.getInstance();

	Scanner sc = new Scanner(System.in);// 입력
	MemberVO member = new MemberVO();// 로그인한 회원의 객체를 저장
	PatternCheck patternC = new PatternCheck(); // 정규식 클래스
	Utill in = new Utill();
	
	String back = "";

	/**
	 * 콘솔을 빈화면으로 보이게 하기 위함.
	 */
	public static void clearScreen() {
		for (int i = 0; i < 10; i++)
			System.out.println("");
	}

	/**
	 * 첫실행화면
	 * @throws Exception 
	 */
	void mainMenu() throws Exception {
		while (true) {
			System.out.println("사랑합니다 손님! 생과일 쥬슈에 오신것을 환영합니다.");
			System.out.println("1. 로그인");
			System.out.println("2. 회원가입");
			System.out.println("3. 행맨플레이하기");
			System.out.println("4. 종료");
			System.out.print("Command>>");

			String choice = sc.next();
			// clearScreen();

			switch (choice) {
			case "1":
				login();
				break;

			case "2":
				signUp();
				break;

			case "3":
				playHangman();
				break;
				
			case "4":
				System.out.println("프로그램을 종료합니다.");
				System.exit(0);
				break;
				
			default:
				System.out.println("\n\n올바르지 않은 명령어입니다.");
				continue;
			}
		}
	}



	/**
	 * 회원로그인 mainMenu() : 2. 회원로그인 선택
	 * @throws Exception 
	 */
	void login() throws Exception {
		HashMap<String, String> loginInfo = new HashMap<String, String>();
		while (true) {
			System.out.println("============== 로그인 =============");
			System.out.println("전화번호와 이름을 알맞게 입력하세요.");
			System.out.println("전화번호를 입력하세요");
			System.out.print("Command>>");
			String tel = sc.next();
			// @kjy
			if (exitMenu(tel)) {
				return;
			}

			System.out.println("이름을 입력하세요");
			System.out.print("Command>>");
			String name = sc.next();
			// @kjy
			if (exitMenu(name)) {
				return;
			}

			loginInfo.put("loginNumber", tel);
			loginInfo.put("loginName", name);
			if(mService.loginAdmin(loginInfo)){
				System.out.println("관리자 로그인");
				adminMenu();
				return;
			}else if (mService.loginCheck(loginInfo) == null) {
				clearScreen();
				System.out.println("로그인 정보가 일치하지 않습니다.");
				System.out.println("메인메뉴로 돌아가기: Q or q");
				System.out.println("로그인 재시도: 아무키나");
				System.out.print("Command>>");
				back = sc.next();
				// @kjy
				if (exitMenu(back)) {
					System.out.println("메인화면으로 돌아갑니다.");
					return;
				}
			} else {
				clearScreen();
				this.member = mService.loginCheck(loginInfo);
				Map<String, ProductVO> sum = new HashMap<String, ProductVO>();
				ProductVO pr = new ProductVO();
				sum.put(member.getMemberNumber(), pr);
				mService.memberSummaryVO(sum);
				System.out.println(member.getMemberName() + "님 환영합니다.");
				break;
			}
		}
		memberMenu();
	}

	/**
	 * 관리자 로그아웃 adminMenu() : 3. 로그아웃 선택
	 * 
	 * @return boolean
	 */
	boolean adminLogOut() {
		System.out.println("로그아웃 하시겠습니까? y/n");
		System.out.print("Command>>");
		String yn = sc.next();

		if (yn.equals("y") || yn.equals("Y")) {
			System.out.println("로그아웃 하였습니다.");
			return true;
		} else {
			System.out.println("관리자 화면으로 돌아갑니다.");
			return false;
		}
	}

	/**
	 * 고객 회원가입 mainMenu() : 3. 회원가입 선택
	 */
	void signUp() {
		MemberVO newMember = new MemberVO();
		while (true) {
			while (true) {
				System.out.println("전화번호를 입력하세요 (01*-****-****)");
				System.out.println("Command>>");
				String tel = sc.next();

				// @kjy
				if (exitMenu(tel)) {
					return;
				}
				if (patternC.telFormCheck(tel)) {
					// 중복 값이 있으면 true, 없으면 false
					boolean check = mService.memberCheckNum(tel);

					if (check) {
						System.out.println("중복된 전화번호 입니다.");
						continue;
					} else {
						newMember.setMemberNumber(tel);
						break;
					}
				} else {
					System.out.println("전화번호가 양식에 맞지 않습니다.");
					signUp();
				}
			}
			System.out.println("이름을 입력하세요.");
			System.out.print("Command>>");
			String name = sc.next();

			// @kjy
			if (exitMenu(name)) {
				return;
			}
			newMember.setMemberName(name);

			while (true) {
				System.out.println("이메일 주소를 입력하세요. ***@***.***");
				System.out.print("Command>>");
				String email = sc.next();
				// @kjy
				if (exitMenu(email)) {
					return;
				}
				if (patternC.emailFormCheck(email)) {
					newMember.setMemberEmail(email);
					break;
				} else {
					System.out.println("올바른 이메일 양식이 아닙니다.");
					continue;
				}
			}

			// 스탬프 추가하기
			newMember.setMemberStamp(0);

			if (mService.memberCreate(newMember)) {
				clearScreen();
				System.out.println("가입 완료!!");
				break;
			} else {
				clearScreen();
				System.out.println("가입 실패!!");
				System.out.println("메인메뉴로 돌아가기: Q or q");
				System.out.println("로그인 재시도: 아무키나");
				System.out.print("Command>>");
				back = sc.next();
				if (exitMenu(back)) {
					System.out.println("메인화면으로 돌아갑니다.");
					break;
				} else {
					continue;
				}
			}
		}
	}

	/**
	 * 고객 로그인 후 화면
	 * @throws Exception 
	 */
	void memberMenu() throws Exception {
		while (true) {
			System.out.println("회원용 페이지");
			System.out.println("1. 주문하기");
			System.out.println("2. 마이페이지");
			System.out.println("3. 한컴타자");
			System.out.println("4. 로그아웃");
			System.out.print("Command>>");

			String num = sc.next();

			clearScreen();
			switch (num) {
			case "1":
				order();
				break;
			case "2":
				myInfoPage();
				break;
			case "3":
				hancomplay();
				break;
			case "4":
				if (logOut()) {
					return;
				} else {
					continue;
				}
			default:
				System.out.println("올바르지 않은 명령어입니다.");
				continue;
			}
		}
	}

	private void hancomplay() {
		boolean check;
		System.out.println("==========게임 전적===============");
		if(mService.hancomview(member.getMemberNumber()).toString().equals("[]")){
			System.out.println("아직 전적이 없습니다.");
		}else{
			System.out.println(mService.hancomview(member.getMemberNumber()));
		}
		System.out.println("\n================================");
		check = mService.hancomplay(member.getMemberNumber());
	}

	/**
	 * 고객 음료 주문하기 memberMenu() : 1.주문하기 선택
	 * @throws Exception 
	 */
	void order() throws Exception {
		while (true) {
			RecordVO record = new RecordVO();
			ProductVO summaryset = new ProductVO();
			int productIndex = 0;
			int productAmount = 0;
			String productString = "";
			Map<String, ProductVO> summarySave = new HashMap<String, ProductVO>();
			Map<String, String> productorder = new HashMap<String, String>();
			summarySave.put(member.getMemberNumber(), summaryset);

			while (true) {
				orderProductList(pService.showProduct());
				System.out.println("상품 번호를 입력하세요.");
				System.out.print("Command>>");
				try {
					productString = sc.next();
					// @kjy
					if (exitMenu(productString)) {
						return;
					}
					productIndex = Integer.parseInt(productString);
				} catch (NumberFormatException e) {
					System.out.println("잘못된 입력입니다.");
					continue;
				}
				if (productIndex >= 0
						&& (productIndex - 1) < pService.showProduct().size()) {
					break;
				} else {
					System.out.println("잘못된 입력입니다.");
					if (exitMenu()) {
						return;
					}
				}
			}
			ProductVO productVO = pService.showProduct().get(productIndex - 1);

			while (true) {
				System.out.println("구매 수량을 입력하세요");
				System.out.print("Command>>");
				String Amount = sc.next();
				if (exitMenu(Amount)) {
					return;
				}
				if (patternC.lessAmountFormCheck(Amount)) {
					try {
						productAmount = Integer.parseInt(Amount);
					} catch (NumberFormatException e) {
						System.out.println("수량이 올바르지 않습니다.");
						continue;
					}

					productorder.put("product_id", productVO.getProductId());
					productorder.put("Amount", Amount);
					if (pService.productOrder(productorder)) { // 구매 성공 시
						for (int i = 0; i < productAmount; i++) {
							member.setMemberStamp(member.getMemberStamp() + 1);
							productIndex = i + 1;
						}
						clearScreen();
						System.out.println(productIndex + "개 ♥쿠폰적립♥");
						if (member.getMemberStamp() >= 10) {
							System.out.println("쿠폰" + member.getMemberStamp()
									/ 10 + "장의 도장을 모두 찍으셨습니다!");
							member.setMemberStamp(member.getMemberStamp() % 10);
							System.out.println("새 쿠폰을 발급합니다.");
							System.out.println("현재 쿠폰 현황: "
									+ member.getMemberStamp() + "/10");
						}
						record.setGoods(productVO.getProductName());
						record.setCount(productAmount);
						record.setIncome(productAmount
								* productVO.getProductPrice());
						pService.recordAdd(record);
						summaryset.setProductId(productVO.getProductId());
						summaryset.setProductName(productVO.getProductName());
						summaryset.setProductNum(productAmount);
						summaryset.setProductPrice(productVO.getProductPrice());
						summarySave.put(member.getMemberNumber(), summaryset);
						if (mService.memberSummaryVO(summarySave)) {
							showSummary(member);
							System.out.println("영수증을 출력하시겠습니까?");
							Scanner sc = new Scanner(System.in);
							String answer = sc.next();
							if(answer.equals("Y")||answer.equals("y")){
//								if(in.summaryPDF(mService.memberGetSummary(member.getMemberNumber()))){
								if(mService.getSummaryPDF(member.getMemberNumber())){
									System.out.println("영수증이 정상 출력되었습니다.");
								}
							}else{
								if (exitMenu()) {
									return;
								}
								break;
							}
						}
					} else {
						System.out.println("재고량이 부족합니다.");
						if (exitMenu()) {
							return;
						}
						break;
					}
				}
			}
		}
	}

	/**
	 * 고객 마이페이지 memberMenu() : 2. 마이페이지 선택
	 */
	void myInfoPage() {
		while (true) {
			System.out.println("1. 내 정보 보기");
			System.out.println("2. 내 정보 수정");
			System.out.println("q. 이전 페이지로");
			System.out.print("Command>>");

			String check = sc.next();

			switch (check) {
			case "1":
				showMyInfo(); // 자신의 정보 보기
				break;
			case "2":
				updateMyInfo();
				break;
			case "q":
				return;
			default:
				System.out.println("올바르지 않은 명령어입니다.");
				break;
			}
		}
	}

	/**
	 * 고객의 자신의 정보 출력 myInfoPage() : 1. 내 정보 보기 선택
	 */
	void showMyInfo() {
		do {
			System.out.println("내 정보");
			System.out.println("이름\t전화번호\t\t이메일주소");
			System.out.println(member.getMemberName() + "\t"
					+ member.getMemberNumber() + "\t\t"
					+ member.getMemberEmail());
			System.out.println("stamp - " + member.getMemberStamp());
			showSummary(member);
		} while (!exitMenu());
	}

	/**
	 * 고객 자신의 회원정보 수정 myInfoPage() : 2. 내 정보 수정 선택
	 */
	void updateMyInfo() {
		String tel = "";
		HashMap<String, String> changeMyInfo = new HashMap<String, String>();

		changeMyInfo.put("changeNumber", member.getMemberNumber());
		viewMemberInfo(member.getMemberNumber());
		while (true) {
			System.out.println("\n===================");
			System.out.println("수정하실 정보를 입력해주세요.");
			System.out.println("1. number");
			System.out.println("2. name");
			System.out.println("3. eamil");
			System.out.println("q. exit");
			System.out.println("===================\n");
			String changeElement = sc.next();

			if (exitMenu(changeElement) || changeElement.equals("exit")) {
				break;
			} else if (changeElement.equals("1")
					|| changeElement.equals("number")
					|| changeElement.equals("2")
					|| changeElement.equals("name")
					|| changeElement.equals("3")
					|| changeElement.equals("email")) {
				switch (changeElement) {
				case "1":
				case "number":
					while (true) {
						while (true) {
							System.out
									.println("변경할 전화번호를 입력하세요.(01*-****-****)");
							System.out.print("Command>>");
							tel = sc.next();
							if (exitMenu(tel)) {
								break;
							}

							if (patternC.telFormCheck(tel)) {
								if (tel.equals(member.getMemberNumber())) {
									System.out
											.println("기존의 번호가 입력된 번호와 일치합니다.");
								} else {
									break;
								}
							} else {
								System.out.println("양식에 맞지 않습니다.");
							}
						}

						// 중복되는 값이 있는지 확인 후 true일 경우 중복 값 false 중복값 없음
						boolean checkNum = mService.memberCheckNum(tel);

						if (checkNum) {
							System.out.println("중복된 전화번호 입니다.");
							continue;
						} else {
							clearScreen();
							// 전화번호 넘겨주기
							// Smember.setMemberNumber(tel);
							// 변경할 전화번호 넘겨주기
							changeMyInfo.put("updateNumber", tel);
							changeMyInfo.put("updateValue", "updateNumber");
							if (mService.memberUpdate(changeMyInfo)) {
								// 변경된 전화번호라서 tel뿌림.
								viewMemberInfo(tel);
								System.out.println("성공적으로 전화번호를 변경하였습니다.");
							} else {
								System.out.println("전화번호를 변경하는데 실패하였습니다");
							}
							break;
						}
					}
					break;
				case "2":
				case "name":
					while (true) {
						System.out.println("변경할 이름을 입력하세요.");
						System.out.print("Command>>");
						String name = sc.next();
						if (exitMenu(name)) {
							break;
						}
						if (!member.getMemberEmail().equals(name)) {
							clearScreen();
							// Smember.setMemberName(name);
							// 새로 넣어줘야함.
							changeMyInfo.put("updateName", name);
							changeMyInfo.put("updateValue", "updateName");
							if (mService.memberUpdate(changeMyInfo)) {
								// 이름변경이라 원래 전화번호를 불러옴
								viewMemberInfo(member.getMemberNumber());
								System.out.println("성공적으로 이름을 변경하였습니다.");
							} else {
								System.out.println("이름을 변경하는데 실패하였습니다");
							}
							break;
						} else {
							System.out.println("기존에 입력 된 이름과 같습니다.");
						}
					}
					break;
				case "3":
				case "email":
					while (true) {
						System.out.println("이메일 주소를 입력하세요.");
						System.out.print("Command>>");
						String email = sc.next();
						if (exitMenu(email)) {
							break;
						}
						if (patternC.emailFormCheck(email)) {
							changeMyInfo.put("updateEmail", email);
							changeMyInfo.put("updateValue", "updateEmail");
							if (mService.memberUpdate(changeMyInfo)) {
								// 이름변경이라 원래 전화번호를 불러옴
								viewMemberInfo(member.getMemberNumber());
								System.out.println("성공적으로 E-mail을 변경하였습니다.");
							} else {
								System.out.println("E-mail을 변경하는데 실패하였습니다");
							}
							break;
						} else if (member.getMemberEmail().equals(email)) {
							System.out.println("기존에 입력된 E-mail과 같습니다.");
						} else {
							System.out.println("E-mail 패턴이 다릅니다.");
						}
					}
					break;
				default:
					if (exitMenu()) {
						return;
					}
				}
			} else {
				System.out.println("명령을 잘못 입력하셨습니다. ");
				if (exitMenu()) {
					return;
				}
				continue;
			}
		}
		return;
	}

	/**
	 * 로그인한 고객을 로그아웃을 해주는 기능 memberMenu() : 3. 로그아웃 선택
	 * 
	 * @return boolean 성공여부를 알려준다.
	 */
	boolean logOut() {
		System.out.println("로그아웃 하시겠습니까? (y/n)");
		String yn = sc.next().trim();

		if (yn.equals("y") || yn.equals("Y")) {
			Map<String, ProductVO> summary = null;
			try {
				summary.put(member.getMemberNumber(), null);
			} catch (NullPointerException e) {
				if(!mService.memberSummaryVO(summary)){
					member = null;
					System.out.println("로그아웃 하였습니다. 메인 화면으로 돌아갑니다.");
					return true;
				}
			}
			return true;
		} else {
			System.out.println("이전 화면으로 돌아갑니다.");
			return false;
		}
	}

	/**
	 * 관리자가 로그인 한후 출력하는 화면 mainMenu() : 1. 관리자 로그인 선택
	 */
	void adminMenu() {
		while (true) {
			System.out.println("===========관리자 페이지============");
			System.out.println("1. 회원관리");
			System.out.println("2. 재고관리");
			System.out.println("3. 로그아웃");
			System.out.print("Command>>");

			String check = sc.next();
			clearScreen();

			switch (check) {
			case "1":
				memberManagement();
				break;
			case "2":
				storeManagement();
				break;
			case "3":
				if (adminLogOut()) {
					return;
				} else {
					continue;
				}
			default:
				System.out.println("올바르지 않은 명령어입니다.");
				continue;
			}
		}
	}

	/**
	 * 관리자가 회원을 관리할 수 있는 화면 adminMenu() : 1.회원관리 선택
	 */
	void memberManagement() {
		while (true) {
			System.out.println("회원관리");
			System.out.println("1. 회원 리스트 출력");
			System.out.println("2. 회원 정보 검색");
			System.out.println("3. 회원 정보 수정");
			System.out.println("4. 회원 탈퇴");
			System.out.println("q. 이전 화면으로");
			System.out.print("Command>>");
			String check = sc.next();
			clearScreen();

			switch (check) {
			case "1":
				showMemberList();
				break;
			case "2":
				searchMemberInfo0();
				break;
			case "3":
				updateMemberInfo();
				break;
			case "4":
				deleteMember();
				break;
			case "q":
				return;
			default:
				System.out.println("올바르지 않은 명령어입니다.");
				continue;
			}
		}
	}

	/**
	 * 관리자가 모든 회원들을 볼수있는 메서드 memberManagement() : 1. 회원 리스트 출력
	 */
	void showMemberList() {
		List<MemberVO> memlist = mService.memberAll();
		while (true) {
		System.out.println("회원 이름\t회원 전화번호\t\t이메일주소\t\t\t스탬프현황");
		for (int i = 0; i < memlist.size(); i++) {
			System.out.println(memlist.get(i).getMemberName() + "\t"
					+ memlist.get(i).getMemberNumber() + "\t"
					+ memlist.get(i).getMemberEmail() + "\t"
					+ memlist.get(i).getMemberStamp());
		}
		System.out.println("회원목록을 엑셀 파일로 추출하시겠습니까? y/n");
		String excelCheck = sc.next();
		if(excelCheck.equals("y")){
			if(mService.getMemberExcel()){
				System.out.println("엑셀파일 추출에 성공하였습니다.");
				System.out.println("D드라이브에서 파일을 확인하세요.");
			}else{
				System.out.println("엑셀파일 추출에 실패하였습니다.");
			}
		}
			if (exitMenu()) {
				return;
			} else {
				continue;
			}
		}
	}

	/**
	 * 관리자가 회원의 전화번호로 정보를 검색 할 수 있음. memberManagement() : 2. 회원정보 검색
	 */
	void searchMemberInfo0() {
		while (true) {
			System.out.println("조회할 회원의 전화번호를 입력하세요.(나가기=Q or q)");
			System.out.println("전화번호의 일부만 입력해도 됩니다.");
			System.out.print("Command>>");
			String memberNumber = sc.next();
			List<MemberVO> memberSearchList = mService
					.searchMemberInfo0(memberNumber);
			if (exitMenu(memberNumber)) {
				break;
			} else {
				if (memberSearchList == null) {
					System.out.println("\n입력하신 회원의 정보가 없습니다. 다시 입력해주세요\n");
					continue;
				} else {
					System.out
							.println("=========================검색결과=========================");
					System.out.println("회원 이름\t회원 전화번호\t\t이메일주소\t\t\t스탬프현황");
					for (int i = 0; i < memberSearchList.size(); i++) {
						System.out.println(memberSearchList.get(i)
								.getMemberName()
								+ "\t"
								+ memberSearchList.get(i).getMemberNumber()
								+ "\t"
								+ memberSearchList.get(i).getMemberEmail()
								+ "\t"
								+ memberSearchList.get(i).getMemberStamp());
					}
					break;
				}

			}
		}
	}

	/**
	 * 특정 회원의 전화번호를 받고 객체를 반환 받는다.
	 * 
	 * @param memberNumber
	 *            회원전화번호
	 */
	void viewMemberInfo(String memberNumber) {
		MemberVO Vmember = mService.searchMemberInfo(memberNumber);
		System.out.println("회원 이름\t회원 전화번호\t\t이메일주소\t\t\t스탬프현황");
		System.out.println(Vmember.getMemberName() + "\t"
				+ Vmember.getMemberNumber() + "\t" + Vmember.getMemberEmail()
				+ "\t" + Vmember.getMemberStamp());
	}

	/**
	 * 관리자에서 특정 회원정보를 수정할 수 있음. memberManagement() : 3. 회원정보수정
	 */
	void updateMemberInfo() {

		String tel = "";
		// 전화번호랑 변경해야할 것 해쉬맵에 저장하기
		HashMap<String, String> updateSend = new HashMap<String, String>();
		// 변경된 정보알려주기

		System.out.println("\n수정할 회원의 전화번호를 정확하게 입력하세요.(나가기=Q or q)");
		System.out.print("Command>>");
		String memberNumber = sc.next();

		if (exitMenu(memberNumber)) {
			return;
		} else {
			MemberVO Smember = mService.searchMemberInfo(memberNumber);
			// 해쉬맵에 전화번호 저장
			while (true) {
				if (Smember != null) {
					updateSend.put("changeNumber", Smember.getMemberNumber());
					viewMemberInfo(memberNumber);
					System.out.println("===================");
					System.out.println("수정하실 정보를 입력해주세요.");
					System.out.println("1. number");
					System.out.println("2. name");
					System.out.println("3. eamil");
					System.out.println("q. exit");
					System.out.print("Command>>");
					String updateM = sc.next();

					if (exitMenu(updateM) || updateM.equals("exit")) {
						break;
					} else if (updateM.equals("1") || updateM.equals("number")
							|| updateM.equals("2") || updateM.equals("name")
							|| updateM.equals("3") || updateM.equals("email")) {
						switch (updateM) {
						case "1":
						case "number":
							while (true) {
								while (true) {
									System.out
											.println("변경할 전화번호를 입력하세요.(01*-****-****)");
									System.out.print("Command>>");
									tel = sc.next();
									if (exitMenu(tel)) {
										break;
									}

									if (patternC.telFormCheck(tel)) {
										if (tel.equals(Smember
												.getMemberNumber())) {
											System.out
													.println("기존의 번호가 입력된 번호와 일치합니다.");
										} else {
											break;
										}
									} else {
										System.out.println("양식에 맞지 않습니다.");
									}
								}

								// 중복되는 값이 있는지 확인 후 true일 경우 중복 값 false 중복값 없음
								boolean checkNum = mService.memberCheckNum(tel);

								if (checkNum) {
									System.out.println("중복된 전화번호 입니다.");
									continue;
								} else {
									clearScreen();
									// 전화번호 넘겨주기
									// Smember.setMemberNumber(tel);
									// 변경할 전화번호 넘겨주기
									updateSend.put("updateNumber", tel);
									updateSend.put("updateValue",
											"updateNumber");
									if (mService.updateMemberInfo(updateSend)) {
										// 변경된 전화번호라서 tel뿌림.
										viewMemberInfo(tel);
										System.out
												.println("성공적으로 전화번호를 변경하였습니다.");
									} else {
										System.out
												.println("전화번호를 변경하는데 실패하였습니다");
									}
									break;
								}
							}
							break;
						case "2":
						case "name":
							while (true) {
								System.out.println("변경할 이름을 입력하세요.");
								System.out.print("Command>>");
								String name = sc.next();
								if (exitMenu(name)) {
									break;
								}
								if (!Smember.getMemberEmail().equals(name)) {
									clearScreen();
									// Smember.setMemberName(name);
									// 새로 넣어줘야함.
									updateSend.put("updateName", name);
									updateSend.put("updateValue", "updateName");
									if (mService.updateMemberInfo(updateSend)) {
										// 이름변경이라 원래 전화번호를 불러옴
										viewMemberInfo(memberNumber);
										System.out
												.println("성공적으로 이름을 변경하였습니다.");
									} else {
										System.out.println("이름을 변경하는데 실패하였습니다");
									}
									break;
								} else {
									System.out.println("기존에 입력 된 이름과 같습니다.");
								}
							}
							break;
						case "3":
						case "email":
							while (true) {
								System.out.println("이메일 주소를 입력하세요.");
								System.out.print("Command>>");
								String email = sc.next();
								if (exitMenu(email)) {
									break;
								}
								if (patternC.emailFormCheck(email)) {
									updateSend.put("updateEmail", email);
									updateSend
											.put("updateValue", "updateEmail");
									if (mService.updateMemberInfo(updateSend)) {
										// 이름변경이라 원래 전화번호를 불러옴
										viewMemberInfo(memberNumber);
										System.out
												.println("성공적으로 E-mail을 변경하였습니다.");
									} else {
										System.out
												.println("E-mail을 변경하는데 실패하였습니다");
									}
									break;
								} else if (Smember.getMemberEmail().equals(
										email)) {
									System.out.println("기존에 입력된 E-mail과 같습니다.");
								} else {
									System.out.println("E-mail 패턴이 다릅니다.");
								}
							}
							break;
						}
					} else {
						System.out.println("명령을 잘못 입력하셨습니다. 다시 입력해주세요.");
						continue;
					}
				} else {
					System.out.println("회원의 전화번호가 올바르지 않습니다.");
				}
				return;
			}
		}
	} // update끝

	/**
	 * 관리자에서 특정회원의 전화번호를 입력받고 특정회원을 삭제하는 기능 memberManagement() : 4. 회원탈퇴
	 */
	void deleteMember() {
		List<MemberVO> memlist = mService.memberAll();
		printMemberList(memlist);

		System.out.println("탈퇴할 회원의 전화번호를 정확하게 입력하세요.");
		String memberNumber = sc.next();
		if (exitMenu(memberNumber)) {

		}
		if (mService.deleteMember(memberNumber)) {
			System.out.println("탈퇴를 성공하셨습니다.");
		} else {
			System.out.println("탈퇴를 실패하셨습니다. 관리자에게 문의해주세요.");
		}
	}

	/**
	 * 관리자가 재고를 관리하는 화면 adminMenu() : 2. 재고관리 선택
	 */
	void storeManagement() {

		while (true) {
			clearScreen();
			System.out.println("==========재고관리===========");
			System.out.println("1. 재고 목록 확인");
			System.out.println("2. 재고량 추가");
			System.out.println("3. 품목 삭제");
			System.out.println("4. 신메뉴 추가");
			System.out.println("5. 누적 판매량 출력");
			System.out.println("q. 이전 페이지로");
			System.out.print("Command>>");

			String check = sc.next();

			switch (check) {
			case "1":
				showStoreList();
				break;
			case "2":
				addStoreAmount();
				break;
			case "3":
				deleteStoreAmount();
				break;
			case "4":
				creatNewMenu();
				break;
			case "5":
				showSaleList();
				break;
			case "q":
				return;
			default:
				System.out.println("올바르지 않은 명령어입니다.");
				break;
			}
		}
	}

	/**
	 * 관리자가 모든 상품들의 재고를 확인 할수 있음. storeManagement() : 1. 재고목록 확인
	 */
	void showStoreList() {
		List<ProductVO> productlist = pService.productRead();
		String amount;
		
		while(true){
			System.out.println("몇개 이하의 상품 재고가 부족한지 출력할까요?");
			System.out.print("Command>>");
			amount = sc.next();
			if (exitMenu(amount)) {
				return;
			}
			if(patternC.lessAmountFormCheck(amount)){
				break;
			}
		}

		List<ProductVO> missproduct = pService.productCheckNum(Integer.parseInt(amount));

		while (true) {
		showProductList(productlist);

		System.out.println();
		if (missproduct.size() == 0) {
			System.out.println("!!!창고가 빵빵하군요!!!");
		} else {
			System.out.println("======= "+amount+"이하의 품목은 아래와 같습니다 ========");
			System.out.println("상품ID\t상품명\t상품가격\t재고량");
			for (int i = 0; i < missproduct.size(); i++) {
				System.out.println(missproduct.get(i).getProductId() + "\t"
						+ missproduct.get(i).getProductName() + "\t"
						+ missproduct.get(i).getProductPrice() + "\t"
						+ missproduct.get(i).getProductNum());
			}
		}
		
		System.out.println("재고현황을 엑셀 파일로 추출하시겠습니까? y/n");
		String excelCheck = sc.next();
		if(excelCheck.equals("y")){
			if(pService.getProductExcel()){
				System.out.println("엑셀파일 추출에 성공하였습니다.");
				System.out.println("D드라이브에서 파일을 확인하세요.");
			}else{
				System.out.println("엑셀파일 추출에 실패하였습니다.");
			}
		}
		
		
			if (exitMenu()) {
				return;
			}else{
				continue;
			}
		}
	}

	/**
	 * 관리자가 특정한 상품을 선택한뒤 재고량을 추가 함. storeManagement() : 2. 재고량 추가 선택
	 */
	void addStoreAmount() {
		HashMap<String, String> productAdd = new HashMap<String, String>();
		productAdd.put("productId", "");
		productAdd.put("Amount", "");

		String productId = "";
		String amount = "";

		clearScreen();
		while (true) {
			showProductList(pService.productRead());
			System.out.println("수량 추가 할 상품의 ID를 입력하시오.");
			System.out.print("Command>>");
			productId = sc.next();

			if (exitMenu(productId)) {
				return;
			}

			if (pService.productCheckIndex(productId) == -1) {
				clearScreen();
				System.out.println("일치하는 ID가 없습니다.");
				if (exitMenu()) {
					return;
				}
			} else {
				productAdd.put("productId", productId);
				break;
			}
		}

		while (true) {
			System.out.println("추가 할 상품의 수량을 입력하시오.(최대 999개)");
			System.out.print("Command>>");
			amount = sc.next();
			if (exitMenu(amount)) {
				return;
			}

			if (patternC.lessAmountFormCheck(amount)) {
				productAdd.put("Amount", amount);
			} else {
				System.out.println("올바른 범위를 벗어납니다.");
				continue;
			}

			if (pService.productAdd(productAdd)) {
				clearScreen();
				showProductList(pService.productRead());
				System.out.println("상품이 정상적으로 추가되었습니다.");
				while (true) {
					if (exitMenu()) {
						return;
					}
					break;
				}
			} else {
				System.out.println("상품추가에 실패했습니다.");
				while (true) {
					if (exitMenu()) {
						return;
					}
					break;
				}
			}
		}
	}

	/**
	 * 관리자가 특정한 상품을 삭제함. storeManagement() : 3. 품목 삭제
	 */
	void deleteStoreAmount() {

		String productId = "";
		clearScreen();
		while (true) {
			showProductList(pService.productRead());
			System.out.println("삭제 할 상품 ID를 입력하시오.");
			System.out.print("Command>>");
			productId = sc.next();
			if (exitMenu(productId)) {
				return;
			}

			if (pService.productCheckIndex(productId) == -1) {
				clearScreen();
				System.out.println("일치하는 ID가 없습니다.");
				while (true) {
					if (exitMenu()) {
						return;
					}
					break;
				}
				continue;
			}
			if (pService.productDelete(productId)) {
				clearScreen();
				showProductList(pService.productRead());
				System.out.println("성공적으로 상품이 삭제되었습니다.");
				if (exitMenu()) {
					return;
				}
			} else {
				if (exitMenu()) {
					return;
				}
			}
		}
	}

	/**
	 * 상위 메뉴로 돌아가는 메서드
	 * 
	 * @return boolean 성공여부를 반환함.
	 */
	boolean exitMenu() {
		System.out.println("나가시려면 Q or q를 입력하세요. 계속하려면 아무키나 누르세요.");
		System.out.print("Command>>");
		String q = sc.next();
		return (q.equals("Q") | q.equals("q"));
	}

	boolean exitMenu(String exitcommand) {
		return (exitcommand.equals("Q") | exitcommand.equals("q"));
	}

	/**
	 * 관리자가 상품을 추가하는 기능 storeManagement() : 4. 신메뉴 추가
	 */
	void creatNewMenu() {

		while (true) {
		ProductVO pTmp = new ProductVO();
		String productId = "";
		String productName = "";
		String productPrice = "";
		String productNum = "";

		clearScreen();
			showProductList(pService.productRead());
			System.out.println("=============신메뉴추가=============");
			while (true) {
				System.out.println("메뉴 ID 입력");
				System.out.print("Command>>");
				productId = sc.next();
				if (exitMenu(productId)) {
					return;
				}

				if (patternC.productIdFormCheck(productId)) {
					if (pService.productCheckId(productId)) {
						System.out.println("중복되는 ID가 있습니다.");
						if (exitMenu()) {
							return;
						}
					} else {
						break;
					}
				} else {
					System.out.println("상품ID의 양식이 올바르지 않습니다.");
					if (exitMenu()) {
						return;
					}
				}
			}

			// 메뉴 입력
			while (true) {
				System.out.println("메뉴 Name 입력");
				System.out.print("Command>>");
				productName = sc.next();
				if (exitMenu(productName)) {
					return;
				}
				if (patternC.productNameFormCheck(productName)) {
					if (pService.productCheckName(productName)) {
						System.out.println("중복되는 Name이 있습니다.");
						continue;
					}
				} else {
					System.out.println("상품 Name의 양식이 올바르지 않습니다.");
					continue;
				}
				break;
			}

			// 메뉴 가격 입력
			while (true) {
				System.out.println("메뉴 Price 입력");
				System.out.print("Command>>");
				productPrice = sc.next();
				if (exitMenu(productPrice)) {
					return;
				}
				if (patternC.productPriceFormCheck(productPrice)) {
					break;
				} else {
					System.out.println("올바른 양식이 아닙니다.");
				}
			}

			// 메뉴 수량 입력
			while (true) {
				System.out.println("메뉴 수량 입력 (999개 이하)");
				System.out.print("Command>>");
				productNum = sc.next();
				if (exitMenu(productNum)) {
					return;
				}
				if (patternC.lessAmountFormCheck(productNum)) {
					break;
				} else {
					System.out.println("올바른 양식이 아닙니다.");
				}
			}

			if (!pService.productCheckId(productId)) {
				pTmp.setProductId(productId);
				pTmp.setProductName(productName);
				pTmp.setProductPrice(Integer.parseInt(productPrice));
				pTmp.setProductNum(Integer.parseInt(productNum));
				if (pService.productCreate(pTmp)) {
					clearScreen();
					showProductList(pService.productRead());
					System.out.println("!!상품등록 성공!!");
				}
			} else {
				System.out.println("!!상품등록 실패!!");
			}
			while (true) {
				if (exitMenu()) {
					return;
				}
				System.out.println("다시 상품을 등록합니다.");
				break;
			}
		}
	}

	/**
	 * 관리자가 전체 상품의 판매량을 확인 할수 있음. storeManagement() : 5. 누적판매량 출력 선택
	 */
	void showSaleList() {
		List<RecordVO> totalRecord = pService.recordSale();

		clearScreen();
		showRecordList(totalRecord);
		while (true) {
			if (exitMenu()) {
				return;
			}
		}
	}

	/**
	 * 회원이 구입한 상품과 수량을 보여주는 메서드 (showMyInfo(), order() 사용)
	 * 
	 * @param member
	 *            로그인한 멤버의 객체를 입력받는다.
	 */
	void showSummary(MemberVO member) {
		System.out.println("===========" + member.getMemberName()
				+ "의 영수증============");
		List<ProductVO> summary = mService.memberGetSummary(member
				.getMemberNumber());
		System.out.println("상품명\t\t구매수량\t금액");
		for (int i = 0; i < summary.size(); i++) {
			System.out.println(summary.get(i).getProductName() + "\t\t"
					+ summary.get(i).getProductNum() + "\t"
					+ summary.get(i).getProductPrice());
		}
		System.out.println("총 구매 금액은 "
				+ mService.allSum(member.getMemberNumber()) + "입니다.");
	}

	/**
	 * 관리자가 볼수있는 모든 회원의 정보를 출력함. (deleteMember()사용)
	 * 
	 * @param memlist
	 *            객체를 입력받음
	 */
	void printMemberList(List<MemberVO> memlist) {
		System.out.println("회원 이름\t회원 전화번호\t\t이메일주소\t\t\t스탬프현황");
		for (int i = 0; i < memlist.size(); i++) {
			System.out.println(memlist.get(i).getMemberName() + "\t"
					+ memlist.get(i).getMemberNumber() + "\t"
					+ memlist.get(i).getMemberEmail() + "\t"
					+ memlist.get(i).getMemberStamp());
		}
	}

	/**
	 * 고객이 구입할 수있는 상품과 재고들을 출력(order()사용)(상품ID없음.)
	 * 
	 * @param productlist
	 */
	void orderProductList(List<ProductVO> productlist) {
		System.out.println("==========현재 상품 리스트===========");
		System.out.println("상품번호\t상품명\t\t상품가격\t\t재고량");
		for (int i = 0; i < productlist.size(); i++) {
			System.out.println(i + 1 + "." + "\t"
					+ productlist.get(i).getProductName() + "\t\t"
					+ productlist.get(i).getProductPrice() + "\t\t"
					+ productlist.get(i).getProductNum());
		}
	}

	/**
	 * 관리자가 모든 상품들의 리스트를 볼 수 있음.(상품의 ID출력) showStoreList(), addStoreAmount(),
	 * deleteStoreAmount(), creatNewMenu()
	 * 
	 * @param productlist
	 */
	void showProductList(List<ProductVO> productlist) {
		System.out.println("==========현재 상품 리스트===========");
		System.out.println("상품ID\t상품명\t\t상품가격\t\t재고량");
		for (int i = 0; i < productlist.size(); i++) {
			System.out.println(productlist.get(i).getProductId() + "\t"
					+ productlist.get(i).getProductName() + "\t\t"
					+ productlist.get(i).getProductPrice() + "\t\t"
					+ productlist.get(i).getProductNum());
		}
	}

	/**
	 * 판매 누적량을 출력
	 * 
	 * @param totalRecord
	 */
	void showRecordList(List<RecordVO> totalRecord) {
		System.out.println("============== 물품 판매량 ===============");
		System.out.println("상품 이름\t판매수량\t수입");
		for (int i = 0; i < totalRecord.size(); i++) {
			System.out.println(totalRecord.get(i).getGoods() + "\t"
					+ totalRecord.get(i).getCount() + "\t"
					+ totalRecord.get(i).getIncome());
		}
		System.out.println("누적 판매량은 : " + totalRecord.get(0).getTotalIncome()
				+ " 입니다.");
		System.out.println("고생하셨습니다. 관리자님");
	}
	
	/**
	 * 행맨플레이하기
	 */
	private void playHangman() {
		mService.hangMan();
	}

	
}
