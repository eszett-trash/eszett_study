package common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;

import product.productVO.ProductVO;
import member.memberVO.MemberVO;



public class Utill {
	
	/**
	 * 재고리스트를 받아서 엑셀 파일로 뽑아내는 매서드
	 * @param productList
	 * @return
	 */
	public boolean productListExcel(List<ProductVO> productList){
		HSSFWorkbook workbook = new HSSFWorkbook();
		
		HSSFSheet sheet = workbook.createSheet();
		
		HSSFRow row = sheet.createRow(0);
		
		HSSFCell cell;
		
		cell = row.createCell(0);
		cell.setCellValue("상품 아이디");
		
		cell = row.createCell(1);
		cell.setCellValue("상품명");
		
		cell = row.createCell(2);
		cell.setCellValue("가격");
		
		cell = row.createCell(3);
		cell.setCellValue("재고량");
		
		for(int i=0; i<productList.size(); i++){
			row = sheet.createRow(i+1);
			
			
			cell = row.createCell(0);
			cell.setCellValue(productList.get(i).getProductId());
			
			cell = row.createCell(1);
			cell.setCellValue(productList.get(i).getProductName());
			
			cell = row.createCell(2);
			cell.setCellValue(productList.get(i).getProductPrice());
			
			cell = row.createCell(3);
			cell.setCellValue(productList.get(i).getProductNum());
		}
		
		File file = new File("D:\\ProductList.xls");
		
		FileOutputStream fos = null;
		
		
		try{
			fos = new FileOutputStream(file);
			workbook.write(fos);
		}catch(FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}catch(IOException e){
			e.printStackTrace();
			return false;
		}finally{
			try{
				if(workbook != null){
					workbook.close();
				}
				if(fos != null){
					fos.close();
				}
			} catch(IOException e){
				e.printStackTrace();
				return false;
			}
		}
		return true;	// 정상종료
	}//재고량 엑셀 매서드 끝
	
	
	public boolean memberListExcel(List<MemberVO> memberList){
		HSSFWorkbook workbook = new HSSFWorkbook();
		
		HSSFSheet sheet = workbook.createSheet();
		
		HSSFRow row = sheet.createRow(0);
		
		HSSFCell cell;
		
		cell = row.createCell(0);
		cell.setCellValue("회원이름");
		
		cell = row.createCell(1);
		cell.setCellValue("회원전화번호");
		
		cell = row.createCell(2);
		cell.setCellValue("회원E-mail");
		
		for(int i=0; i<memberList.size(); i++){
			row = sheet.createRow(i+1);
			
			cell = row.createCell(0);
			cell.setCellValue(memberList.get(i).getMemberName());
			
			cell = row.createCell(1);
			cell.setCellValue(memberList.get(i).getMemberNumber());
			
			cell = row.createCell(2);
			cell.setCellValue(memberList.get(i).getMemberEmail());
		}
		
		File file = new File("D:\\MemberList.xls");
		
		FileOutputStream fos = null;
		
		
		try{
			fos = new FileOutputStream(file);
			workbook.write(fos);
		}catch(FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}catch(IOException e){
			e.printStackTrace();
			return false;
		}finally{
			try{
				if(workbook != null){
					workbook.close();
				}
				if(fos != null){
					fos.close();
				}
			} catch(IOException e){
				e.printStackTrace();
				return false;
			}
		}
		return true;	// 정상종료
	}//멤버 엑셀 매서드 끝
	
	// PDF파일 출력
	public boolean summaryPDF(List<ProductVO> summaryList) throws Exception {
		// pdf document 선언....
		Document document = new Document(PageSize.A4, 0, 0, 50, 50);
		// pdf 파일을 저장할 공간을 선언... pdf파일을 서버하드에 생성이된다.. 그후 스트림으로 쏜다..
		PdfWriter.getInstance(document, new FileOutputStream("D:/summary.pdf"));
		// document를 열어 pdf문서를 쓸수있도록한다..
		document.open();
		// 한글지원폰트 설정..
		BaseFont bf = BaseFont.createFont("HYGoThic-Medium", "UniKS-UCS2-H",
				BaseFont.NOT_EMBEDDED);
		Font font = new Font(bf, 9, Font.NORMAL);
		Font font2 = new Font(bf, 14, Font.BOLD);
		// 타이틀
		Paragraph title = new Paragraph("구매 영수증", font2);
		// 중간정렬
		title.setAlignment(Element.ALIGN_CENTER);
		// 문서에 추가
		document.add(title);
		document.add(new Paragraph("\r\n"));
		
		Paragraph regend = new Paragraph("상품명\t\t\t\t구매수량\t\t\t금액", font);
		regend.setAlignment(Element.ALIGN_CENTER);
		
		document.add(regend);
		
		for(int i=0; i<summaryList.size(); i++){
			Paragraph sum = new Paragraph(summaryList.get(i).getProductName()+"\t\t\t\t"+
										  summaryList.get(i).getProductNum() +"\t\t\t" + 
										  summaryList.get(i).getProductPrice(), font);
			sum.setAlignment(Element.ALIGN_CENTER);
			document.add(sum);
		}
		document.close();
		
		return true;
	}
	
}
