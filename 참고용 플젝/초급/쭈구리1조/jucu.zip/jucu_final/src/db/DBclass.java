package db;

import game.HancomVO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import product.productVO.ProductVO;
import product.recordVO.RecordVO;
import member.memberVO.MemberVO;

public class DBclass {

	private static DBclass db = null;
	
	private List<MemberVO> memberList = new ArrayList<MemberVO>();
	private List<ProductVO> productList = new ArrayList<ProductVO>();
	private List<RecordVO> recordList = new ArrayList<RecordVO>();
	private String adminId = "000"; // 관리자 아이디
	private String adminPw = "000"; // 관리자 비밀번호
	private Map<String, List<ProductVO>> summaryDB = new HashMap<String, List<ProductVO>>();
	
	
//	DBclass() {
//
//	}

	public static DBclass getInstance() {
		if (db == null) {
			db = new DBclass();
		}
		return db;
	}

	 private DBclass() { // 초기화 블럭
			ProductVO pro1 = new ProductVO();
			pro1.setProductId("sb");
			pro1.setProductName("딸바쥬스");
			pro1.setProductNum(30);
			pro1.setProductPrice(3000);

			ProductVO pro2 = new ProductVO();
			pro2.setProductId("ba");
			pro2.setProductName("포도쥬스");
			pro2.setProductNum(50);
			pro2.setProductPrice(2500);

			ProductVO pro3 = new ProductVO();
			pro3.setProductId("st");
			pro3.setProductName("딸기쥬스");
			pro3.setProductNum(40);
			pro3.setProductPrice(2000);

			productList.add(pro1);
			productList.add(pro2);
			productList.add(pro3);

			RecordVO re1 = new RecordVO();
			re1.setGoods("딸바쥬스");
			re1.setCount(0);

			RecordVO re2 = new RecordVO();
			re2.setGoods("포도쥬스");
			re2.setCount(0);

			RecordVO re3 = new RecordVO();
			re3.setGoods("딸기쥬스");
			re3.setCount(0);

			recordList.add(re1);
			recordList.add(re2);
			recordList.add(re3);

			MemberVO mem = new MemberVO();
			mem.setMemberNumber("123");
			mem.setMemberName("123");
			mem.setMemberEmail("123");
			mem.setMemberStamp(0);
			memberList.add(mem);

			List<ProductVO> pr = new ArrayList<ProductVO>();
			summaryDB.put("123", pr);
	}

	// 회원 로그인
	/**
	 * 회원의 로그인 시 아이디를 대조할 때 사용하는 메서드 loginNumber와 loginName을 키 값으로 하는 String 형태의
	 * Value값을 memberList에 있는 값과 비교하여 해당 객체를 반환한다.
	 * 
	 * @param loginInfo
	 * @return MemberVO
	 */
	public MemberVO loginCheck(Map<String, String> loginInfo) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberNumber()
					.equals(loginInfo.get("loginNumber"))
					&& memberList.get(i).getMemberName()
							.equals(loginInfo.get("loginName"))) {
				return memberList.get(i);
			}
		}
		return null;
	}

	// 특정회원찾기
	// 일치하는 값이 있다면 해당 VO 반환, 없다면 null 리턴
	/**
	 * 관리자가 특정 회원의 정보를 출력할 때 사용하는 메서드로 member의 전화번호를 통해 memberList와 대조 후 해당하는
	 * VO를 리턴함
	 * 
	 * @param memberNumber
	 * @return MemberVO
	 */
	public List<MemberVO> searchMemberInfo0(String memberNumber) {
		List<MemberVO> temp = new ArrayList<MemberVO>();
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberNumber().contains(memberNumber)) {
				temp.add(memberList.get(i));
			}
		}
		return temp;
	}

	public MemberVO searchMemberInfo(String memberNumber) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberNumber().equals(memberNumber)) {
				return memberList.get(i);
			}
		}
		return null;
	}

	// 회원정보수정(개인)
	/**
	 * 회원정보 수정 시 Map String형태의 Key값과 Value값을 받고 memberList에서 바꾸려는 사람과 일치하는 VO를
	 * 가져온 뒤 바꿔줄 정보를 Switch문으로 대조하여 변경한다.
	 * 
	 * @param changeMyInfo
	 * @return true(성공), false(실패)
	 */
	public boolean memberUpdate(Map<String, String> changeMyInfo) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberNumber()
					.equals(changeMyInfo.get("changeNumber"))) {
				switch (changeMyInfo.get("updateValue")) {
				case "updateNumber":
					memberList.get(i).setMemberNumber(
							changeMyInfo.get("updateNumber"));
					break;
				case "updateName":
					memberList.get(i).setMemberName(
							changeMyInfo.get("updateName"));
					break;
				case "updateEmail":
					System.out.println();
					memberList.get(i).setMemberEmail(
							changeMyInfo.get("updateEmail"));
					break;

				}
				return true;
			}
		}
		return false;
	}

	// 회원가입, 전화번호 체크
	// 회원가입
	/**
	 * 회원가입 시 새로운 member의 VO를 받아 현재의 멤버에 새로 추가해주고 영수증에 관한 정보를 저장할 수 있도록
	 * summaryDB List에도 넣어준다.
	 * 
	 * @param newMember
	 * @return
	 */
	public boolean memberCreate(MemberVO newMember) {
		List<ProductVO> pr = new ArrayList<ProductVO>();
		memberList.add(newMember);
		summaryDB.put(newMember.getMemberNumber(), pr);
		return true;
	}

	// 전화번호 중복확인
	/**
	 * memberList에 있는 전화번호 중 입력된 전화번호와 비교하여 동일한 전화번호가 있는지 확인한다.
	 * 
	 * @param memberTel
	 * @return true(중복 값 있음), false(중복 값 없음)
	 */
	public boolean memberCheckNum(String memberTel) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberTel.equals(memberList.get(i).getMemberNumber())) {
				return true;// 중복된 전화번호
			}
		}
		return false;
	}

	// 관리자
	/**
	 * 전역변수로 설정되어있는 admin id와 admin Pw를 비교함 map 형태의 string admin id과 admin pw를 키
	 * 값으로 하고 해당 value값을 비교하는 메서드
	 * 
	 * @param loginAdmininfo
	 * @return true(일치), false(불일치)
	 */
	public boolean loginAdmin(Map<String, String> loginAdmininfo) {
		if (adminId.equals(loginAdmininfo.get("loginNumber"))
				&& adminPw.equals(loginAdmininfo.get("loginName"))) {
			return true;
		}
		return false;
	}

	/**
	 * member List의 값을 List형태로 반환함
	 * 
	 * @return List<MemberVO>
	 */
	public List<MemberVO> memberAll() {
		return memberList;
	}

	// 전화번호 이용 특정 회원 정보 출력
	/**
	 * memberList에서 입력받은 member의 전화번호와 대조하여 맞는 전화번호가 있을 경우 해당VO를 반환한다.
	 * 
	 * @param memberNum
	 * @return MemberVO(일치), null(불일치)
	 */
	public MemberVO memberSearchNum(String memberNum) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberNum.equals(memberList.get(i).getMemberNumber())) {
				return memberList.get(i);
			}
		}
		return null;
	}

	// 회원정보 수정 (관리자)
	/**
	 * 회원정보 수정 시 Map String형태의 Key값과 Value값을 받고 memberList에서 바꾸려는 사람과 일치하는 VO를
	 * 가져온 뒤 바꿔줄 정보를 Switch문으로 대조하여 변경한다.
	 * 
	 * @param updateSend
	 * @return true(변경 성공), false(변경 실패)
	 */
	public boolean updateMemberInfo(Map<String, String> updateSend) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberNumber()
					.equals(updateSend.get("changeNumber"))) {
				switch (updateSend.get("updateValue")) {
				case "updateNumber":
					memberList.get(i).setMemberNumber(
							updateSend.get("updateNumber"));
					break;
				case "updateName":
					memberList.get(i).setMemberName(
							updateSend.get("updateName"));
					break;
				case "updateEmail":
					memberList.get(i).setMemberEmail(
							updateSend.get("updateEmail"));
					break;

				}
				return true;
			}
		}
		return false;
	}

	// 회원삭제 DB
	/**
	 * memberList에서 입력받은 String memberNumber와 대조하여 해당 VO를 삭제한다.
	 * 
	 * @param memberNumber
	 * @return true(성공), false(실패)
	 */
	public boolean deleteMember(String memberNumber) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberNumber().equals(memberNumber)) {
				memberList.remove(i);
				return true;
			}
		}
		return false;
	}

	// 주문 하기
	/**
	 * 현재 저장되어있는 ProductVO의 List를 보여준다.
	 * 
	 * @return List<ProductVO> productList
	 */
	public List<ProductVO> showProduct() {
		return productList;
	}

	/**
	 * 회원이 제품주문 시 제품명과 수량을 받아 productList의 아이디를 비교하고 일치하는 VO의 Number를 수량만큼 빼주고
	 * 리스트에 저장함.
	 * 
	 * @param productorder
	 * @return true(성공), false(실패)
	 */
	public boolean productOrder(Map<String, String> productorder) {
		int num = Integer.parseInt(productorder.get("Amount"));
		for (int i = 0; i < productList.size(); i++) {
			if (productList.get(i).getProductId()
					.equals(productorder.get("product_id"))) {
				if (productList.get(i).getProductNum() >= num) {
					productList.get(i).setProductNum(
							productList.get(i).getProductNum() - num);
					return true;
				}
			}
		}
		return false;
	}

	// Map, String에 해당하는 ProductVO를 summaryDB에 저장해준다.
	/**
	 * member의 전화번호 Key값, ProductVO를 Value값으로 전화번호에 해당하는 구매내역을 저장하기 위한 메서드
	 * productVO값을 가져와 sum에 저장한 뒤 summaryDB에 있는 memberNumber 의 VO값과 비교하여 일치하는 경우
	 * 값을 대조 후 최신화함
	 * 
	 * @param summary
	 * @return true(성공), false(실패)
	 */
	public boolean memberSummaryVO(Map<String, ProductVO> summary) {
		ProductVO sum = null;
		for (int i = 0; i < memberList.size(); i++) {
			String memberNumber = memberList.get(i).getMemberNumber();
			List<ProductVO> sumpro = summaryDB.get(memberNumber);
			try{
				sum = summary.get(memberNumber);
			}catch(NullPointerException e){
				summaryDB.put(memberNumber, null);
				return true;
			}
			if(sumpro == null){
				List<ProductVO> pr = new ArrayList<ProductVO>();
				summaryDB.put(memberNumber, pr);
				return true;
			}
			ProductVO sumList;
			if (summary.containsKey(memberNumber) && sumpro != null) {
				for (int j = 0; j < sumpro.size(); j++) {
					try{
						sumList = sumpro.get(j);
						if (sumList.getProductId().equals(sum.getProductId())) {
							sumList.setProductName(sum.getProductName());
							sumList.setProductNum(sumList.getProductNum()
									+ sum.getProductNum());
							sumList.setProductPrice(sum.getProductPrice()
									* sumList.getProductNum());
							sumpro.remove(j);
							sumpro.add(j, sumList);
							summaryDB.put(memberNumber, sumpro);
							return true;
						}
					}catch( NullPointerException e){
						sum.setProductPrice(sum.getProductNum() * sum.getProductPrice());
						sumpro.remove(0);
						sumpro.add(sum);
						summaryDB.put(memberNumber, sumpro);
						return true;
					}
				}
				sum.setProductPrice(sum.getProductNum() * sum.getProductPrice());
				sumpro.add(sum);
				summaryDB.put(memberNumber, sumpro);
				return true;
			} else if (summary.containsKey(memberNumber)) {
				sum.setProductPrice(sum.getProductNum() * sum.getProductPrice());
				sumpro.add(sum);
				summaryDB.put(memberNumber, sumpro);
				return true;
			}
		}
		return false;
	}

	public int allSum(String memberNumber) {
		List<ProductVO> productL = summaryDB.get(memberNumber);
		int sum = 0;
		for (int i = 0; i < productL.size(); i++) {
			sum += productL.get(i).getProductPrice();
		}
		return sum;
	}

	/**
	 * Map 형태의 summaryDB에 있는 member전화번호의 value값을 얻어와 반환해준다.
	 * 
	 * @param memberNumber
	 * @return List<ProductVO>
	 */
	public List<ProductVO> memberGetSummary(String memberNumber) {
		return summaryDB.get(memberNumber);
	}

	// 재고 관리
	/**
	 * ProductVO의 List에 있는 수량을 확인한 뒤 0이하일 경우 부족한 수량임을 관리자에게 알려준다.
	 * 
	 * @return
	 */
	public List<ProductVO> productCheckNum(int num) {
		List<ProductVO> tmp = new ArrayList<ProductVO>();
		for (int i = 0; i < productList.size(); i++) {
			if (productList.get(i).getProductNum() <= num) {
				tmp.add(productList.get(i));
			}
		}
		return tmp;
	}

	/**
	 * ProductList를 읽어오기 위한 메서드
	 * 
	 * @return productList
	 */
	public List<ProductVO> productRead() {
		return productList;
	}

	/**
	 * productOrder를 성공적으로 실행했을 경우에만 호출한다. 매서드 내에서 Map<Stirng, Integer>를 선언하고
	 * 키값에 product_id, 값에 수량을 넣어준 뒤, 출력해준다.
	 * 
	 * @param product_Id
	 * @return ProductVO
	 */
	public ProductVO productRceipt(String product_Id) {
		for (int i = 0; i < productList.size(); i++) {
			if (product_Id.equals(productList.get(i).getProductId())) {
				return productList.get(i);
			}
		}
		return null;
	}

	/**
	 * 제품의 수량을 추가하는 메서드로 productId를 키 값으로 받은 뒤 value값인 수량을 List내의 일치하는 product에
	 * 수량 추가해준다.
	 * 
	 * @param productAdd
	 * @return
	 */
	public boolean productAdd(Map<String, String> productAdd) {
		for (int i = 0; i < productList.size(); i++) {
			// productList에서 입력받은 id와 일치하는 경우
			if (productAdd.get("productId").equals(
					productList.get(i).getProductId())) {
				// 해당 id의 index값에 있는 product의 수량을 누적 추가해준다.
				try {
					productList.get(i)
							.setProductNum(
									productList.get(i).getProductNum()
											+ Integer.parseInt(productAdd
													.get("Amount")));
				} catch (NumberFormatException e) {
					return false;
				}
				return true;
			}
		}
		return false;
	}

	// productCreate 중복체크는 productCheckId 와 productCheckName 통해 사전 작업 완료
	/**
	 * 새 제품을 등록할 때 사용하는 메서드로 새로운 제품의 정보를 ProductVO의 매개변수로 받아 productlist에 추가해준다.
	 * 
	 * @param newProduct
	 * @return false(예외 발생 시), true(정상 추가)
	 */
	public boolean productCreate(ProductVO newProduct) {
		try {
			productList.add(newProduct);
		} catch (NumberFormatException e) {
			return false;
		}
		return true;
	}

	// productId만 중복 체크
	/**
	 * product의 id를 매개변수로 받아 productlist에 있는 목록과 대조 후 일치하는 값이 있는지 여부 판별
	 * 
	 * @param productId
	 * @return true(일치), false(불일치)
	 */
	public boolean productCheckId(String productId) {
		for (int i = 0; i < productList.size(); i++) {
			// productList에서 index 번째의 productId와 일치하면 true 값 리턴
			if (productList.get(i).getProductId().equals(productId)) {
				return true;
			}
		}
		return false;
	}

	// productName만 중복체크
	/**
	 * product의 Name을 매개변수로 받아 productlist에 있는 목록과 대조 후 일치하는 값이 있는지 여부 판별
	 * 
	 * @param productName
	 * @return true(일치), false(불일치)
	 */
	public boolean productCheckName(String productName) {
		for (int i = 0; i < productList.size(); i++) {
			// productList에서 index 번째의 productName와 일치하면 true 값 리턴
			if (productName.equals(productList.get(i).getProductName())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * productId를 매개변수로 받아 productlist에 있는 i번째의 값에서 삭제해준다.
	 * 
	 * @param productId
	 * @return true(성공), false(실패)
	 */
	public boolean productDelete(String productId) {
		for (int i = 0; i < productList.size(); i++) {
			// productList에서 index 번째의 productId와 일치하면 삭제
			if (productId.equals(productList.get(i).getProductId())) {
				productList.remove(i);
				return true;
			}
		}
		return false;
	}

	// 판매량 관리
	/**
	 * 사용자가 주문을 할 시 recordList에 기록을 하는데 관리자가 판매량을 알 수 있도록 해주는 메서드 view에서
	 * recordvo에 setting된 값들을 넘겨받아 recordList에 일치하는 id에 해당 정보들을 추가해준다.
	 * 
	 * @param recordvo
	 * @return true(성공), recordList.add(레코드 리스트에 없을경우)
	 */
	public boolean redcordAdd(RecordVO recordvo) {
		for (int i = 0; i < recordList.size(); i++) {
			// recordList에 저장되어있는 객체의 goods와 입력받은 goods가 일치할 때
			if (recordvo.getGoods().equals(recordList.get(i).getGoods())) {
				// 나머지 값들을 전달해준다.
				recordList.get(i).setCount(
						recordList.get(i).getCount() + recordvo.getCount());
				recordList.get(i).setIncome(
						recordList.get(i).getIncome() + recordvo.getIncome());
				recordList.get(0).setTotalIncome(
						recordList.get(0).getTotalIncome()
								+ recordvo.getIncome());
				return true;
			}
		}
		// 만일 recordAdd에 없을경우 list에 추가해준다.
		return recordList.add(recordvo);
	}

	/**
	 * 저장된 recordList를 반환한다.
	 * 
	 * @return List<RecordVO>
	 */
	public List<RecordVO> recordSale() {
		return recordList;
	}

	/**
	 * productId에 해당하는 값이 productList에서 몇번째에 있는지 값을 반환해주는 메서드
	 * 
	 * @param productId
	 * @return i(i번째에 있을 시), -1(productList에 없을 시)
	 */
	public int productCheckIndex(String productId) {
		for (int i = 0; i < productList.size(); i++) {
			if (productList.get(i).getProductId().equals(productId)) {
				return i;
			}
		}
		return -1;
	}

	public boolean hancomplay(HancomVO gameend) {
		for(int i=0; i<memberList.size(); i++){
			if(memberList.get(i).getMemberNumber().equals(gameend.getHanMemId())){
				memberList.get(i).setHancomRecord(gameend);
				return true;
			}
		}
		return false;
	}
	
	public List<HancomVO> hancomView(String memberId){
		for(int i=0; i<memberList.size(); i++){
			if(memberList.get(i).getMemberNumber().equals(memberId)){
				return memberList.get(i).getHancomRecord();
			}
		}
		return null;
	}

}
