package product.productVO;

public class ProductVO {

	private String productId; // 제품의 ID 값
	private String productName; // 제품명
	private int productNum; // 제품의 수량 저장
	private int productPrice; // 제품의 가격 저장

	// 제품의 ID값을 받아옴
	public String getProductId() {
		return productId;
	}

	// 제품의 ID값 셋팅
	public void setProductId(String product_id) {
		this.productId = product_id;
	}

	// 제품의 이름 받아옴
	public String getProductName() {
		return productName;
	}

	// 제품의 이름 셋팅
	public void setProductName(String productName) {
		this.productName = productName;
	}

	// 제품의 수량 받아옴
	public int getProductNum() {
		return productNum;
	}

	// 제품의 수량 셋팅
	public void setProductNum(int productNum) {
		this.productNum = productNum;
	}

	// 제품의 가격 받아옴
	public int getProductPrice() {
		return productPrice;
	}

	// 제품의 가격 셋팅
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	@Override
	public String toString() {
		return "ProductVO [" + " productId = " + productId + ", 제품명 = "
				+ productName + ", 제품 갯수 = " + productNum + ", 제품 가격 = "
				+ productPrice + " ]";
	}
	
}
