package product.dao;

import java.util.List;
import java.util.Map;

import product.productVO.ProductVO;
import product.recordVO.RecordVO;
import db.DBclass;

public class IProductDaoImpl implements IProductDao {

	private static IProductDao dao = null;
	private DBclass db = null;
	
	IProductDaoImpl(){
		db = DBclass.getInstance();
	}
	
	public static IProductDao getInstance() {
		if(dao == null){
			dao = new IProductDaoImpl();
		}
		return dao;
	}

	@Override
	public boolean productOrder(Map<String, String> productorder) {
		return db.productOrder(productorder);
	}

	@Override
	public List<ProductVO> productCheckNum(int num) {
		return db.productCheckNum(num);
	}

	@Override
	public List<ProductVO> showProduct() {
		return db.showProduct();
	}

	@Override
	public List<ProductVO> productRead() {
		return db.productRead();
	}

	@Override
	public boolean productAdd(Map<String, String> productAdd) {
		return db.productAdd(productAdd);
	}

	@Override
	public boolean productCheckId(String productId) {
		return db.productCheckId(productId);
	}

	@Override
	public boolean productCheckName(String productName) {
		return db.productCheckName(productName);
	}

	@Override
	public int productCheckIndex(String productId) {
		return db.productCheckIndex(productId);
	}

	@Override
	public boolean productCreate(ProductVO newProduct) {
		return db.productCreate(newProduct);
	}

	@Override
	public boolean productDelete(String productId) {
		return db.productDelete(productId);
	}

	@Override
	public boolean recordAdd(RecordVO newRecord) {
		return db.redcordAdd(newRecord);
	}

	@Override
	public List<RecordVO> recordSale() {
		return db.recordSale();
	}

}
