package product.dao;

import java.util.List;
import java.util.Map;

import product.productVO.ProductVO;
import product.recordVO.RecordVO;

public interface IProductDao {

	   /**
	    * 상품 아이디와 수량을 Map 형태의 값으로 저장하여
	    * 매개변수로 받은 뒤 구매이벤트 발생 시
	    * 현재 productList에서 차감해준다.
	    * @return true(구매성공), false(구매실패)
	    */
	   public boolean productOrder(Map<String, String> productorder);
	   
	   /**
	    * 1보다 적은 부족한 물품의 리스트들을 반환받는다. 
	    * @return List
	    */
	   public List<ProductVO> productCheckNum(int num);
	   
	   /**
	    * 현재 DB에 있는 productVO의 List를 반환해주어
	    * View클래스에서 출력할 수 있도록 한다.
	    * @return
	    */
	   public List<ProductVO> showProduct();

	   // 관리자
	   // 재고관리
	   /**
	    * 전체 상품, 상품재고 출력, 부족한 재고 알림
	    */
	   public List<ProductVO> productRead();

	   /**
	    * 상품 재고의 추가 / ProductVO temp를 통해서 교환할 것임.
	    * 
	    * @param productAdd
	    * @return true(정상추가), false(추가 안됨)
	    */
	   public boolean productAdd(Map<String, String> productAdd);
	   
	   /**
	    * productCreate 시 추가되는 product의 id가 중복되는 값이 있는지
	    * 확인해주는 작업을 한다.
	    * 중복되는 값이 있을 경우 true 값, 중복되는 값이 없을 경우 false 값 리턴
	    * @param productId
	    * @return boolean
	    */
	   public boolean productCheckId(String productId);
	   
	   /**
	    * productCreate 시 추가되는 product의 name가 중복되는 값이 있는지
	    * 확인해주는 작업을 한다.
	    * 중복되는 값이 있을 경우 true 값, 중복되는 값이 없을 경우 false 값 리턴
	    * @param productName
	    * @return boolean
	    */
	   public boolean productCheckName(String productName);
	   
	   /**
	    * productId에 해당하는 인덱스 값을 넘겨받는다.
	    * 일치하는 값이 없을 경우 -1을 넘겨받는다.
	    * @param productId
	    * @return
	    */
	   public int productCheckIndex(String productId);

	   /**
	    * 메뉴에 신상품 등록
	    * view에서 입력받은 값들을 vo로 가져와서 매개변수로 받은 뒤 product_id와 product_name을 비교하여 똑같으면
	    * false 다르다면 true값을 반환하고 맞는 값을 list에 추가해준다.
	    * 
	    * @param createMenu
	    * @return boolean
	    */
	   public boolean productCreate(ProductVO newProduct);
	   
	   /**
	    * 메뉴에서 상품 삭제
	    * 
	    * @param productId
	    * @return boolean
	    */
	   public boolean productDelete(String productId);

	   /*
	    * 매출관리 recordAdd() : 판매내역추가 recordSale() : 누적 판매 리스트 출력 recordMenu() : 상품별
	    * 누적 판매량
	    */
	   /**
	    * record에 판매내역을 추가(상품명과 판매된수량을 매개변수로 입력) //데이터베이스 클래스 안에서 연산을 통해서 출력을 해준다.
	    * 
	    * @param goods
	    * @param count
	    * @return boolean
	    */
	   public boolean recordAdd(RecordVO newRecord);

	   /**
	    * 디비에 있는 recordList Record 리스트를 출력한다.
	    * view에서 받은 리스트를 통해
	    * 상품별 누적 판매량, 매출액등을 구분 출력할 수 있도록한다.
	    * @return List
	    */
	   public List<RecordVO> recordSale();
	   
}
