package product.service;

import java.util.List;
import java.util.Map;
import common.*;
import product.dao.IProductDao;
import product.dao.IProductDaoImpl;
import product.productVO.ProductVO;
import product.recordVO.RecordVO;


public class IProductServiceImpl implements IProductService {

	private static IProductService service = null;
	private IProductDao dao = null;
	Utill ut = new Utill();
	public IProductServiceImpl() {
		dao = IProductDaoImpl.getInstance();
	}
	
	public static IProductService getInstance() {
		if(service==null){
			service = new IProductServiceImpl();
		}
		return service;
	}

	@Override
	public boolean productOrder(Map<String, String> productorder) {
		return dao.productOrder(productorder);
	}

	@Override
	public List<ProductVO> productCheckNum(int num) {
		return dao.productCheckNum(num);
	}

	@Override
	public List<ProductVO> showProduct() {
		return dao.showProduct();
	}

	@Override
	public List<ProductVO> productRead() {
		return dao.productRead();
	}

	@Override
	public boolean productAdd(Map<String, String> productAdd) {
		return dao.productAdd(productAdd);
	}

	@Override
	public boolean productCheckId(String productId) {
		return dao.productCheckId(productId);
	}

	@Override
	public boolean productCheckName(String productName) {
		return dao.productCheckName(productName);
	}

	@Override
	public int productCheckIndex(String productId) {
		return dao.productCheckIndex(productId);
	}

	@Override
	public boolean productCreate(ProductVO newProduct) {
		return dao.productCreate(newProduct);
	}

	@Override
	public boolean productDelete(String productId) {
		return dao.productDelete(productId);
	}

	@Override
	public boolean recordAdd(RecordVO newRecord) {
		return dao.recordAdd(newRecord);
	}

	@Override
	public List<RecordVO> recordSale() {
		return dao.recordSale();
	}
	
	@Override
	public boolean getProductExcel(){
		return ut.productListExcel(dao.productRead());
	}

}
