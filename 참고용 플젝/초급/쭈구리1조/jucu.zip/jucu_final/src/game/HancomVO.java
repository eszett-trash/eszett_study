package game;

public class HancomVO {
	private long hanScore;
	private String hanMemId;
	
	
	public long getHanScore() {
		return hanScore;
	}
	public void setHanScore(long score) {
		this.hanScore = score;
	}
	public String getHanMemId() {
		return hanMemId;
	}
	public void setHanMemId(String hanMemId) {
		this.hanMemId = hanMemId;
	}
	@Override
	public String toString() {
		return "\n게임사용자 =" + hanMemId + "  |  게임점수=" + hanScore;
	}
	
	

}
