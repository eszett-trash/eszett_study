package game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;

public class HangManPlay {

	private Properties p;
	private InputStream fis = null;
	
	Scanner input = new Scanner(System.in);
	String[] alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m",
						"n","o","p","q","r","s","t","u","v","w","x","y","z"};
	
	
	public HangManPlay() {
		p = new Properties();
	}
	
	public Properties getP() {
		return p;
	}

	public void loadWord(String filePath){
		fis = getClass().getResourceAsStream(filePath);
		try {
			p.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public void play(){
		while(true){
			HangManPlay hm = new HangManPlay();
			String filePath = "hangManwords.properties";	//경로를 주면서 파일로드
			hm.loadWord(filePath);
			p = hm.getP();
			List<String> answerList = new ArrayList<String>();
			String[] tmp = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p",
					"q","r","s","t","u","v","w","x","y","z"};
			
			String player;
			int index = (int)(Math.random()*51);
			int count = 0;
			int myScore = 0;
			
			String answer = p.getProperty(Integer.toString(index));
			
			System.out.println("게임 시작!!");
			
			scene();//초기화면 보여주기
			
			for(int i=0; i<answer.length(); i++){	//뽑아낸 단어의 길이만큼 _를 채움
				answerList.add("_");
				System.out.print("_ ");
			}
			System.out.println();
			
			
			while(true){
				if(!answerList.contains("_")){
					System.out.println("★축하합니다! 맞췄습니다!!★");
					System.out.println("정답: " + answer);
					myScore = 100 - (count*10);
					System.out.println("내 점수: " + myScore);
					alphabet = tmp;
					break;
				}
				
				player = writeLetters();	//입력받기
				
				if(answer.contains(player)){
					for(int i=0; i<answer.length(); i++){
						if(answer.charAt(i) == player.charAt(0)){
							answerList.set(i, player);
						}
					}
					showLetters(answerList);
				} else{
					System.out.println("해당 알파벳이 들어있지 않습니다.");
					System.out.println();
					count++;
					switch(count){
						case 1:
							scene1();
							break;
						case 2:
							scene2();
							break;
						case 3:
							scene3();
							break;
						case 4:
							scene4();
							break;
						case 5:
							scene5();
							break;
						case 6:
							scene6();
							break;
						default:
							break;
					}
					showLetters(answerList);
				}
				
				removeAlphabet(player);
				
				if(count == 6){	//6번 틀리면...
					System.out.println("게임오버!!@!@!!~!~!~ 영어 공부좀 하세요!!!!!");
					System.out.println("정답: " + answer);
					alphabet = tmp;
					break;
				}
			}
			
			System.out.println("한 판 더? y/n");
			System.out.print(">>");
			if(input.next().equals("y")){
				continue;
			}else{
				System.out.println("Bye~~!~");
				System.out.println();
				break;
			}
		}
	}


	private void removeAlphabet(String player) {	//사용한 알파벳 지우기
		for(int i=0; i<26; i++){
			if(alphabet[i].equals(player)){
				alphabet[i] = "*";
			}
		}
	}

	private String writeLetters() {	//알파벳 입력하기
		String player;
		while(true){
			System.out.print("알파벳 소문자를 입력하세요>>");
			player = input.next();
			
			if(player.length() > 1){
				System.out.println("한 글자만 입력하세요");
				continue;
			}else if(!Arrays.asList(alphabet).contains(player)){
				System.out.println("이미 사용했거나 올바르지 않는 입력입니다..");
				continue;
			}else{
				break;
			}
		}	
		return player;
	}

	
	private void showLetters(List<String> answerList){	//맞춰야 하는 글자의 현황 보여주기
		for(int i=0; i<answerList.size(); i++){
			System.out.print(answerList.get(i)+" ");
		}
		System.out.println();
	}
	
	private void scene(){
		System.out.println("      @@@@@@@@@@@@@@@@@@@@@");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @ ");
		System.out.println("      @@                 @ ");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@@");
		System.out.println("      @@ @ ");
		System.out.println("      @@ =#");
		System.out.println("      @@  @ ");
		System.out.println("      @@   @");
		System.out.println("      @@   -@ ");
		System.out.println("   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println();
		System.out.println();
	}
	
	private void scene1(){
		System.out.println("      @@@@@@@@@@@@@@@@@@@@@");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                $@,   ");
		System.out.println("      @@               @@@@@    ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@              @@@@@@@");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@@");
		System.out.println("      @@ @ ");
		System.out.println("      @@ =#");
		System.out.println("      @@  @ ");
		System.out.println("      @@   @");
		System.out.println("      @@   -@ ");
		System.out.println("   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println();
		System.out.println();
	}
	
	private void scene2(){
		System.out.println("      @@@@@@@@@@@@@@@@@@@@@");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                $@,   ");
		System.out.println("      @@               @@@@@    ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@              @@@@@@@");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@                .@~ ");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@             @@@@@@@@   ");
		System.out.println("      @@              @@@@@@. ");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@@");
		System.out.println("      @@ @ ");
		System.out.println("      @@ =#");
		System.out.println("      @@  @ ");
		System.out.println("      @@   @");
		System.out.println("      @@   -@ ");
		System.out.println("   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println();
		System.out.println();
	}
	
	private void scene3(){
		System.out.println("      @@@@@@@@@@@@@@@@@@@@@");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                $@,   ");
		System.out.println("      @@               @@@@@    ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@              @@@@@@@");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@                .@@ ");
		System.out.println("      @@               @@@@@@");
		System.out.println("      @@             @@@@@@@@@");
		System.out.println("      @@            @ @@@@@@@@");
		System.out.println("      @@           @  @@@@@@@@");
		System.out.println("      @@          @   @@@@@@@@  ");
		System.out.println("      @@         @    @@@@@@@@ ");
		System.out.println("      @@        @      @@@@@@. ");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@@");
		System.out.println("      @@ @ ");
		System.out.println("      @@ =#");
		System.out.println("      @@  @ ");
		System.out.println("      @@   @");
		System.out.println("      @@   -@ ");
		System.out.println("   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println();
		System.out.println();
	}
	
	private void scene4(){
		System.out.println("      @@@@@@@@@@@@@@@@@@@@@");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                $@,   ");
		System.out.println("      @@               @@@@@    ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@              @@@@@@@");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@                .@@ ");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@              @@@@@@@@");
		System.out.println("      @@             @@@@@@@@@@");
		System.out.println("      @@            @ @@@@@@@@ @ ");
		System.out.println("      @@           @  @@@@@@@@  @");
		System.out.println("      @@          @   @@@@@@@@   @");
		System.out.println("      @@         @    @@@@@@@@    @");
		System.out.println("      @@        @      @@@@@@.     @");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@");
		System.out.println("      @@@");
		System.out.println("      @@ @ ");
		System.out.println("      @@ =#");
		System.out.println("      @@  @ ");
		System.out.println("      @@   @");
		System.out.println("      @@   -@ ");
		System.out.println("   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println();
		System.out.println();
	}
	
	private void scene5(){
		System.out.println("      @@@@@@@@@@@@@@@@@@@@@");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                $@,   ");
		System.out.println("      @@               @@@@@    ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@ ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@               @@@@@ ");
		System.out.println("      @@                .@@ ");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@             @@@@@@@@@");
		System.out.println("      @@             @@@@@@@@@@");
		System.out.println("      @@            @ @@@@@@@@ @,");
		System.out.println("      @@           @  @@@@@@@@  @");
		System.out.println("      @@          @   @@@@@@@@   @");
		System.out.println("      @@         @    @@@@@@@@    @");
		System.out.println("      @@        @     @@@@@@@.     @");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@              @@");
		System.out.println("      @@");
		System.out.println("      @@@");
		System.out.println("      @@ @ ");
		System.out.println("      @@ =#");
		System.out.println("      @@  @ ");
		System.out.println("      @@   @");
		System.out.println("      @@   -@ ");
		System.out.println("   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println();
		System.out.println();
	}
	
	private void scene6(){
		System.out.println("      @@@@@@@@@@@@@@@@@@@@@");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                 @");
		System.out.println("      @@                $@,   ");
		System.out.println("      @@               @@@@@    ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@              @@@@@@@ ");
		System.out.println("      @@               @@@@@  ");
		System.out.println("      @@                .@@ ");
		System.out.println("      @@               @@@@@@ ");
		System.out.println("      @@              @@@@@@@@");
		System.out.println("      @@             @@@@@@@@@@");
		System.out.println("      @@            @ @@@@@@@@ @,");
		System.out.println("      @@           @  @@@@@@@@  @");
		System.out.println("      @@          @   @@@@@@@@   @");
		System.out.println("      @@         @    @@@@@@@@    @");
		System.out.println("      @@        @     @@@@@@@@     @");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@              @@    @@");
		System.out.println("      @@");
		System.out.println("      @@@");
		System.out.println("      @@ @ ");
		System.out.println("      @@ =#");
		System.out.println("      @@  @ ");
		System.out.println("      @@   @");
		System.out.println("      @@   -@ ");
		System.out.println("   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println();
		System.out.println();
	}
	
}
