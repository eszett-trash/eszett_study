package game;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HancomPlay {
   List<String> hancomwords = new ArrayList<String>();
   List<Integer> num = new ArrayList<Integer>();
   public HancomPlay() {
      num.add(4);
      num.add(9);
      num.add(14);
      num.add(19);
      num.add(24);
      num.add(29);
      num.add(34);
      num.add(39);
      num.add(44);
      num.add(49);
      num.add(54);
      num.add(59);
      num.add(64);
      num.add(69);
      num.add(74);
      num.add(79);
      num.add(84);
      num.add(89);
      num.add(94);
      num.add(99);
      //1
      hancomwords.add("The Selfish Giant");
      hancomwords.add("Every afternoon, as they were coming from school, the children used");
      hancomwords.add("to go and play in the Giant's garden.");
      hancomwords.add("It was a large lovely garden, with soft green grass. Here and there");
      hancomwords.add("over the grass stook beautiful flowers like stars, and there were");
      //2
      hancomwords.add("twelve peachtrees that in the springtime broke out into delicate blos-");
      hancomwords.add("soms of pink and pearl, and in the autumn bore rich fruit. The birds");
      hancomwords.add("sat in the trees and sang so sweetly that the children used to stop");
      hancomwords.add("their games in order to listen to them. How happy we are here! they");
      hancomwords.add("cried to each other.");
      //3
      hancomwords.add("One day the Giant came back. He had been to visit his friend the");
      hancomwords.add("Cornish ogre, and had stayed with him for seven years. After the seven");
      hancomwords.add("years were over he had said all that he had to say, for his conversa-");
      hancomwords.add("tion was limited, and he determined to return to his own castle. When");
      hancomwords.add("he arrived he saw the children playing in the garden.");
      //4
      hancomwords.add("What are you doing here? he cried in a very gruff voice, and the");
      hancomwords.add("children ran away.");
      hancomwords.add("My own garden is my own garden, said the Giant; anyone can under-");
      hancomwords.add("stand that, and I will allow nobody to play in it but myself. So he");
      hancomwords.add("built a high wall all round it, and put up a notice-board.");
      //5
      hancomwords.add("TRESPASSERS WILL BE PROSECUTED");
      hancomwords.add("He was a very selfish Giant.");
      hancomwords.add("The poor children had now nowhere to play. They tried to play in the");
      hancomwords.add("road was very dusty and full of hard stones, and they did not like it.");
      hancomwords.add("They used to wander round the high wall when their lessons were over,");
      //6
      hancomwords.add("and talk about the beautiful garden inside. How happy we were there!");
      hancomwords.add("they said to each other.");
      hancomwords.add("Then the Spring came, and all over the country there were little blos-");
      hancomwords.add("soms and little birds. Only in the garden of the Selfish Giant it was");
      hancomwords.add("still winter. The birds did not care to sing in it as there were no");
      //7
      hancomwords.add("children, and the trees forgot to blossom. Once a beautiful flower put");
      hancomwords.add("its head out from the grass but when it saw the notice-board it was so");
      hancomwords.add("sorry for the children that it slipped back into the ground again, and");
      hancomwords.add("went off to sleep. The only people who were pleased were the Snow and");
      hancomwords.add("the Frost. Spring has forgotten this garden, they cried, so we will");
      //8
      hancomwords.add("live here all the year round. The Snow covered up the grass with her");
      hancomwords.add("great white cloak, and the Frost painted all the trees silver. Then");
      hancomwords.add("they invited the North Wind to stay with them, and he came. He was");
      hancomwords.add("wrapped in furs, and he roared all day about the garden, and blew the");
      hancomwords.add("chimney-pots down. This is a delightful spot, he said, we must ask");
      //9
      hancomwords.add("the Hail in a visit. So the Hail came. Every day for three hours he");
      hancomwords.add("rattled on the roof of the castle till he borke most of the slates, and");
      hancomwords.add("then he ran round and round the garden as fast as he could go. He was");
      hancomwords.add("dressed in grey, and his breath was like ice.");
      hancomwords.add("I cannot understand why the Spring is so late in coming, said the");
      //10
      hancomwords.add("Selfish Giant, as he sat at the window and looked out at his cold white");
      hancomwords.add("garden; I hope there will be a change in the weather.");
      hancomwords.add("But the Spring never came, nor the Summer. The Autumn gave golden");
      hancomwords.add("fruit to every garden, but to the Giant's garden she gave none. He is");
      hancomwords.add("too selfish, she said. So it was always Winter there, and the North");
      //11
      hancomwords.add("Wind and the Hail, and the Frost, and the Snow danced about through the");
      hancomwords.add("trees.");
      hancomwords.add("One morning the Giant was lying awake in bed when he heard some lovely");
      hancomwords.add("music. It sounded so sweet to his ears that he thought it must be the");
      hancomwords.add("King's musicians passing by. It was really only a little linnet sing-");
      //12
      hancomwords.add("ing outside his window, but it was so long since he had heard a bird");
      hancomwords.add("sing in his garden that it seemed to him to be the most beautiful music");
      hancomwords.add("in the world. Then the Hail stopped dancing over his head, and the ");
      hancomwords.add("North Wind ceased roaring, and a delicious perfume came to him through");
      hancomwords.add("the open casement. I believe the Spring has come at last, said the");
      //13
      hancomwords.add("Giant; and he jumped out of bed and looked out.");
      hancomwords.add("What did he see?");
      hancomwords.add("He saw a most wonderful sight. Through a little hole in the wall the");
      hancomwords.add("children had crept in, and they were sitting in the branches of the");
      hancomwords.add("trees. In every tree that he could see there was a little child. And");
      //14
      hancomwords.add("the trees were so glad to have the children back again that they had");
      hancomwords.add("covered themselves with blossoms, and were waving their arms gently");
      hancomwords.add("above the children's heads. The birds were flying about and twittering");
      hancomwords.add("with delight, and the flowers were looking up through the green grass");
      hancomwords.add("and laughing. It was a lovely scene, only in one corner it was still");
      //15
      hancomwords.add("winter. It was the farthest corner of the garden and in it was stand-");
      hancomwords.add("ing a little boy. He was so small that he could not reach up to the");
      hancomwords.add("branches of the tree, and he was wandering all round it, crying bitter-");
      hancomwords.add("ly. The poor tree was still quite covered with frost and snow, and the");
      hancomwords.add("North Wind was blowing and roaring above it. Climb up! little boy,");
      //16
      hancomwords.add("said the Tree, and it bent its branches down as low as it could; but");
      hancomwords.add("the boy was too tiny.");
      hancomwords.add("And the Giant's heart melted as he looked out. How selfish I have");
      hancomwords.add("been! he said; now I know why the Spring would not come here. I will");
      hancomwords.add("put that poor little boy on the top the tree, and then I will knock");
      //17
      hancomwords.add("down the wall, and my garden shall be the children's playground for");
      hancomwords.add("ever and ever. He was really very sorry for what the he had done.");
      hancomwords.add("So he crept downstairs and opened the front door quite softly, and");
      hancomwords.add("went out into the garden. But when the children saw him they were so");
      hancomwords.add("frightened that they all ran away, and the garden became winter again.");
      //18
      hancomwords.add("Only the little boy did not run, for his eyes were so full of tears");
      hancomwords.add("that he did not see the Giant coming. And the Giant stole up behind");
      hancomwords.add("him and tool him gently in his hand, and put him up into the tree. And");
      hancomwords.add("the tree broke at once into blossom, and the birds came and sang on it,");
      hancomwords.add("and the little boy stretched out his two arms and flung them round the");
      //19
      hancomwords.add("Giant's neck, and kissed him. And the other children, when they saw");
      hancomwords.add("that the Giant was not wicked any longer, came running back, and with");
      hancomwords.add("them came the Spring. It is your garden now, little children, said");
      hancomwords.add("the Giant, and he took a great axe and knocked down the wall. And when");
      hancomwords.add("the people were going to market at twelve o'clock they found the Giant");
      //20
      hancomwords.add("playing with the children in the most beautiful garden they had ever");
      hancomwords.add("seen. -The Selfish Giant Every afternoon, as they were coming from school,");
      hancomwords.add("the children used to go and play in the Giant's garden.");
      hancomwords.add("It was a large lovely garden, with soft green grass. Here and there");
      hancomwords.add("over the grass stook beautiful flowers like stars, and there were");
   }

   public HancomVO gameStart(String memberId) {
      NumberFormat nf = NumberFormat.getInstance();
      Scanner sc = new Scanner(System.in);
      int ver = num.get((int) (Math.random() * num.size()));
      long time = 0L;
      String inputHancom = "";
      String compare = "";
      int count = 0;// 비교해야하는 총갯수
      int countinput = 0;// 입력한 갯수
      int diff = 0;
      String check = "";
      // 게임 결과 정보 ---------------------
      HancomVO memberInfo = new HancomVO();
      int score = 0;
      // -------------------------------
      // 게임시작--------------------------
      // 시작시간
      System.out.println("게임을 시작하시려면 'A'또는 'a'를 입력해주세요.");
      try {
         check = sc.next();
         sc.nextLine();
         if (check.equals("A") || check.equals("a")) {
            for (int i = ver - 4; i <= ver; i++) {
               System.out.println(hancomwords.get(i));
               compare = hancomwords.get(i).trim();
               count += compare.length();
               // 시작하는 시간
               long start = System.currentTimeMillis();
               System.out.println(">>");
               inputHancom = sc.nextLine();
               // 끝나는 시간
               long end = System.currentTimeMillis();

               inputHancom = inputHancom.trim();
               // 비교해야 해서 배열 갯수 맞춰줌.
               countinput += inputHancom.length();
               try {
                  for (int j = 0; j < compare.length(); j++) {
                     if (compare.charAt(j) != inputHancom.charAt(j)) {
                        diff++;
                     }
                  }
               } catch (Exception e) {
                  diff += compare.length() - inputHancom.length();
               }
               // 시간계산
               time += end - start;
            }

            System.out.println("\n\n=========결과==========\n");
            System.out.println("게임사용자 : " + memberId);
            System.out.println();
            // 오타율계산
            double x = Math.round((double) diff / count * 100);
            System.out.println("오타율 : " + (int) x);
            System.out.println();

            // 오타율 소숫점 자리, 타자수 표시 계산

            // 점수대입
            if(count<countinput){ //총갯수가 입력받은 갯수보다 작으면
               double scoreR = (((double)count/time)*70000);//순수 타수
               score = (int) (scoreR-(x*0.01)*scoreR);
            }else{
               double scoreR = (((double)countinput/time)*70000);//순수 타수
               score = (int) (scoreR-(x*0.01)*scoreR);
            }
            System.out.println("타수 : " + score);
            System.out.println("\n게임이 끝났습니다.\n\n");
            // 게임끝-----------------
            memberInfo.setHanMemId(memberId);
            memberInfo.setHanScore(score);
         } else {
            System.out.println("다시 게임을 들어와 주세요.\n");
         }
      } catch (Exception e) {
         System.out.println("다시 게임을 들어와 주세요.\n");
      }
      return memberInfo;
   }
   
   
}