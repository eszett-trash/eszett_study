package jucu_Main;

import java.util.Map;
import java.util.List;

import jucu_DB.DBClass;
import jucu_VO.MemberVO;
import jucu_VO.ProductVO;
import jucu_VO.RecordVO;

public class ServiceImplement implements ServiceInter{
	
	DBClass db = new DBClass();

	// 회원가입, 전화번호체크
	public boolean memberCreate(MemberVO newMember) {
		return db.memberCreate(newMember);
	}// memberCheck들을 호출
	
	public boolean memberCheckNum(String memberTel) {
		return db.memberCheckNum(memberTel);
	}

	public MemberVO loginCheck(Map<String, String> loginInfo) {
		return db.loginCheck(loginInfo);
	}

	/*
	 * loginCheck(HashMap<String, String> loginInfo)
	 * 
	 * view 해쉬맵으로 모아서 logincheck로 보내줌 key : Tel전화번호 value : Name이름
	 * 
	 * 구현부 DB에서 key값을 검색한 멤버VO가 반환되면 여기서 반환을 해주면 됨.
	 * 
	 * DB 멤버리스트에서 tel과 매개변수 해쉬맵의 key값이 동일한걸 비교하기 위해
	 * DB에서 멤버리스트를 불러와 전화번호를 검색해서
	 * 반환을 객체로 해주는 메서드를 만들어야함.
	 */

	public boolean loginAdmin(Map<String, String> loginAdmininfo) {
		return db.loginAdmin(loginAdmininfo);
	}

	@Override
	public boolean productOrder(Map<String, String> productorder){
		return db.productOrder(productorder);
	}
	
	@Override
	public boolean memberSummaryVO(Map<String, ProductVO> summary) {
		return db.memberSummaryVO(summary);
	}
	
	@Override
	public int allSum(String memberNumber){
		return db.allSum(memberNumber);
	}

	
	@Override	
//	public Map<String, List<ProductVO>> memberGetSummary(String memberNumber){
	public List<ProductVO> memberGetSummary(String memberNumber){
		return db.memberGetSummary(memberNumber);
	}
	
	@Override
	public List<ProductVO> productCheckNum() {
		return db.productCheckNum();
	}

	// @@kjy
	@Override
	public boolean memberUpdate(Map<String, String> changeMyInfo) {
		return db.memberUpdate(changeMyInfo);
	}
	
	// 회원정보수정(관리자) , implement
	public boolean updateMemberInfo(Map<String, String> updateSend) {
		return db.updateMemberInfo(updateSend);
	}

	@Override
	public List<ProductVO> showProduct() {
		return db.showProduct();
	}

	@Override
	public ProductVO productRceipt(String product_Id){
		return db.productRceipt(product_Id);
	}

	public List<MemberVO> searchMemberInfo0(String memberNumber){
        return db.searchMemberInfo0(memberNumber);
     }
	
	public MemberVO searchMemberInfo(String memberNumber){
		return db.searchMemberInfo(memberNumber);
	}

	@Override
	public List<MemberVO> memberAll() {
		return db.memberAll();
	}


	@Override
	public MemberVO memberSearchNum(String memberNum) {
		return db.memberSearchNum(memberNum);
	}
	
	// 회원삭제 implement
	public boolean deleteMember(String memberNumber) {
		return db.deleteMember(memberNumber);
	}

	@Override
	public List<ProductVO> productRead() {
		return db.productRead();
	}

	@Override
	public boolean productAdd(Map<String, String> productAdd) {
		return db.productAdd(productAdd);
	}

	@Override
	public boolean productCheckId(String productId) {
		return db.productCheckId(productId);
	}

	@Override
	public boolean productCheckName(String productName) {
		return db.productCheckName(productName);
	}

	@Override
	public boolean productCreate(ProductVO newProduct) {
		return db.productCreate(newProduct);
	}

	@Override
	public boolean productDelete(String productId) {
		return db.productDelete(productId);
	}

	@Override
	public boolean recordAdd(RecordVO newRecord) {
		return db.redcordAdd(newRecord);
	}

	@Override
	public List<RecordVO> recordSale() {
		return db.recordSale();
	}

	@Override
	public int productCheckIndex(String productId) {
		return db.productCheckIndex(productId);
	}
}
