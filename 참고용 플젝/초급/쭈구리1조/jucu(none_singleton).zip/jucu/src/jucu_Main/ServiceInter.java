package jucu_Main;

import java.util.Map;
import java.util.List;

import jucu_VO.MemberVO;
import jucu_VO.ProductVO;
import jucu_VO.RecordVO;

/**
 * @Class serviceInterface
 * @Description 쥬스 판매 서비스 클래스
 * @author 쥬스판매자
 * @since 2017-08-28
 * @version 0.1
 * @see
 * <pre>
 *   수정일             수정자               수정내용      
 *   -------         -------     -------------------            
 *  2017.08.28                           최초생성      
 *  2017.08.29                  ServiceInterface 생성
 *  2017.08.30                  DBclass 생성
 *  2017.08.31                      ServiceInterface 수정(by. 영만쌤)
 * </pre>      
 * <pre>
 *  해야할것
 *    : 정확한 인터페이스 구현 / 매개변수 및 리턴타입 명확하게
 * </pre>
 */

public interface ServiceInter {
   // 고객
   /*
    * 회원가입 memberCreate() : 회원가입 - 입력받은 값을 Check들을 불러확인하는 작업 - memberCheck() :
    * 중복아이디확인(전화번호), 맞는form인지
    */

   /**
    * memberList에 있는 리스트들을 갖고와서 회원가입 시 Number 중복 체크를 한다.
    * 성공적으로 수행 시 true 값 리턴
    * 회원들의 정보를 hash맵에 저장한 뒤 최종적으로 List에 적재시키는 역할을 수행한다.
    * 
    * @param MemberVO
    *            newMember
    * @return boolean true(가입성공) / false(가입실패)
    */
   public boolean memberCreate(MemberVO newMember);// memberCheck들을 호출

   /**
    * 입력되는 전화번호가 올바른 form인지 확인 후 값이 맞을경우 true값 리턴 matchpattern
    * 
    * @param memberTel
    * @return boolean (중복이면 1, 중복값이 없으면 0)
    */
   public boolean memberCheckNum(String memberTel);
   
   //@@kjy
   /**
    * 개인 회원의 회원정보 수정
    * @param changeMyInfo
    * @return
    */
   public boolean memberUpdate(Map<String, String> changeMyInfo);

   
 //회원정보수정(관리자) , interface
   /**
    * 회원정보 수정 메뉴 String 형태의 키 값을 갖고 사용자가 원하는 정보를 수정해줌.
    * @param updateSend
    * @return
    */
   public boolean updateMemberInfo(Map<String, String> updateSend);

   /*
    * 회원모드(주문) login() : login하는것 loginCheck() : ID, PW 체크 productOrder() :
    * 주문상품확인, 재고확인, 금액반환,StampCheck productRceipt() : 영수증출력
    */

   /**
    * 매서드 내에서 member객체에 저장되어있는 login, pw 값 대조 후, 없다면 관리자 id, pw와 일치하는지 확인.
    * login 후 view에 로그인 한 사람의 정보를 저장한 뒤 지속적으로 접근 가능하도록 반환타입은 MemberVO
    * 
    * @param loginInfo
    * @return MemberVO
    */
   public MemberVO loginCheck(Map<String, String> loginInfo);

   /**
    * id와 pw를 Map에 저장된 키, value값과 비교하여 
    * 같을 경우 true 리턴, 다를 경우 false 리턴
    * @param loginInfo
    * @return 
    */
   public boolean loginAdmin(Map<String, String> loginInfo);
   
   /**
    * 회원리스트에있는 전화번호와 대조하여 일치하는 경우
    * 해당 VO를 넘겨받는 메서드
    * @param memberNumber
    * @return
    */
   public List<MemberVO> searchMemberInfo0(String memberNumber);
   
   public MemberVO searchMemberInfo(String memberNumber);
   
   //회원삭제 implement
   /**
    * 회원 삭제 시 member의 Number를 입력받아 해당 내용을 삭제해준다.
    * list에 있는 값이 삭제 시 true, 삭제 불가 시 false 리턴
    * @param memberNumber
    * @return
    */
   public boolean deleteMember(String memberNumber);


   /**
    * 상품 아이디와 수량을 Map 형태의 값으로 저장하여
    * 매개변수로 받은 뒤 구매이벤트 발생 시
    * 현재 productList에서 차감해준다.
    * @return true(구매성공), false(구매실패)
    */
   public boolean productOrder(Map<String, String> productorder);
   
   /**
    * Member의 summary를 받아서 Member의 구매내역에 저장한다.
    * @return 
    */
	public boolean memberSummaryVO(Map<String, ProductVO> summary);

	/**
	 * 회원의 전화번호를 입력받아 영수증의 총 합을 반환함
	 * @param memeberNumber
	 * @return int
	 */
	public int allSum(String memberNumber);
	
	/**
	 * 해당 member의 영수증을 반환해준다.
	 * @param memberNumber
	 * @return member summary List
	 */
	public List<ProductVO> memberGetSummary(String memberNumber);

   /**
    * 1보다 적은 부족한 물품의 리스트들을 반환받는다. 
    * @return List
    */
   public List<ProductVO> productCheckNum();
   
   /**
    * 현재 DB에 있는 productVO의 List를 반환해주어
    * View클래스에서 출력할 수 있도록 한다.
    * @return
    */
   public List<ProductVO> showProduct();

   /**
    * productOrder를 성공적으로 실행했을 경우에만 호출한다.
    * 매서드 내에서 Map<Stirng, Integer>를
    * 선언하고 키값에 product_id, 값에 수량을 넣어준 뒤, 출력해준다.
    * @param product_Id
    */
   public ProductVO productRceipt(String product_Id);

   // 관리자
   /*
    * 로그인 login(), loginCheck() : 관리자 ID, PW확인하는 메서드 //중복임
    */
   /*
    * 회원관리 memberAll() : 전체 회원 출력 memberRead() : 특정 회원정보확인 memberUpdate() : 특정
    * 회원정보수정 memberDelete() : 특정 회원탈퇴
    */

   /**
    * DB클래스에서 회원 리스트를 뽑아준다.
    */
   public List<MemberVO> memberAll();
   
   /**
    * 특정 회원의 전화번호를 통해 회원의 정보를 출력해준다.
    * @param memberNum
    * @return MemberVO
    */
   public MemberVO memberSearchNum(String memberNum);

   // public void memberRead(MemberVO member);
   // public void memberUpdate(MemberVO member);
   // public void memberDelete(MemberVO member);

   // 재고관리
   /**
    * 전체 상품, 상품재고 출력, 부족한 재고 알림
    */
   public List<ProductVO> productRead();

   /**
    * 상품 재고의 추가 / ProductVO temp를 통해서 교환할 것임.
    * 
    * @param productAdd
    * @return true(정상추가), false(추가 안됨)
    */
   public boolean productAdd(Map<String, String> productAdd);
   
   /**
    * productCreate 시 추가되는 product의 id가 중복되는 값이 있는지
    * 확인해주는 작업을 한다.
    * 중복되는 값이 있을 경우 true 값, 중복되는 값이 없을 경우 false 값 리턴
    * @param productId
    * @return boolean
    */
   public boolean productCheckId(String productId);
   
   /**
    * productCreate 시 추가되는 product의 name가 중복되는 값이 있는지
    * 확인해주는 작업을 한다.
    * 중복되는 값이 있을 경우 true 값, 중복되는 값이 없을 경우 false 값 리턴
    * @param productName
    * @return boolean
    */
   public boolean productCheckName(String productName);
   
   /**
    * productId에 해당하는 인덱스 값을 넘겨받는다.
    * 일치하는 값이 없을 경우 -1을 넘겨받는다.
    * @param productId
    * @return
    */
   public int productCheckIndex(String productId);

   /**
    * 메뉴에 신상품 등록
    * view에서 입력받은 값들을 vo로 가져와서 매개변수로 받은 뒤 product_id와 product_name을 비교하여 똑같으면
    * false 다르다면 true값을 반환하고 맞는 값을 list에 추가해준다.
    * 
    * @param createMenu
    * @return boolean
    */
   public boolean productCreate(ProductVO newProduct);
   
   

   /**
    * 메뉴에서 상품 삭제
    * 
    * @param productId
    * @return boolean
    */
   public boolean productDelete(String productId);

   /*
    * 매출관리 recordAdd() : 판매내역추가 recordSale() : 누적 판매 리스트 출력 recordMenu() : 상품별
    * 누적 판매량
    */
   /**
    * record에 판매내역을 추가(상품명과 판매된수량을 매개변수로 입력) //데이터베이스 클래스 안에서 연산을 통해서 출력을 해준다.
    * 
    * @param goods
    * @param count
    * @return boolean
    */
   public boolean recordAdd(RecordVO newRecord);

   /**
    * 디비에 있는 recordList Record 리스트를 출력한다.
    * view에서 받은 리스트를 통해
    * 상품별 누적 판매량, 매출액등을 구분 출력할 수 있도록한다.
    * @return List
    */
   public List<RecordVO> recordSale();
   
}