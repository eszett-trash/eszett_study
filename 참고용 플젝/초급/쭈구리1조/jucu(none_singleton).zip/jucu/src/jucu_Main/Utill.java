package jucu_Main;

import java.util.regex.Pattern;

public class Utill {
	
	public boolean telFormCheck(String tel){
		return Pattern.matches("01[016789]-[0-9]{3,4}-[0-9]{4}", tel);
	}
	
	public boolean emailFormCheck(String email) {
		return Pattern.matches("^[_a-zA-Z0-9-\\.]+@[\\.a-zA-Z0-9-]+\\.[a-zA-Z]+$",email);
	}
	
	public boolean amountFormCheck(String amount){
		return Pattern.matches("[1-9][0-9]{0,2}", amount);
	}
	
	public boolean productIdFormCheck(String productId){
		return Pattern.matches("[a-zA-Z]{2,12}", productId);
	}
	
	public boolean productNameFormCheck(String productName){
		return Pattern.matches("^[ㄱ-ㅎ가-힣]*$", productName);
	}
	
	public boolean productPriceFormCheck(String productPrice){
		return Pattern.matches("^[1-9]{1,2}[0-9][0]{2}$", productPrice);
	}
}
