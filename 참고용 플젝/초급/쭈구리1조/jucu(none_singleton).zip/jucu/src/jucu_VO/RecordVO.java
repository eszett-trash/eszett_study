package jucu_VO;

public class RecordVO {
	private String goods; // 판매 물품 이름
	private int count; // 판매 수량
	private int income; // 수입
	private int totalIncome; // 총 수입

	public int getTotalincome() {
		return totalIncome;
	}

	public void setTotalincome(int totalincome) {
		this.totalIncome = totalincome;
	}

	public String getGoods() {
		return goods;
	}

	public void setGoods(String goods) {
		this.goods = goods;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getIncome() {
		return income;
	}

	public void setIncome(int income) {
		this.income = income;
	}

	@Override
	public String toString() {
		return "RecordVO [goods=" + goods + ", count=" + count + ", income="
				+ income + ", totalincome=" + totalIncome + "]";
	}
}