package jucu_VO;

import java.util.ArrayList;
import java.util.List;

public class MemberVO {
	private String memberNumber; // 아이디기능의 전화번호
	private String memberName; // pw기능의 이름
	private String memberEmail; // 회원 이메일
	private int memberStamp; // 스탬프 //주스 한개 살때마다 특수문자 하나 추가됨 ♥
	 // 멤버의 product 구매 내역을 저장하는 List
	private List<ProductVO> summary = new ArrayList<ProductVO>();

	public String getMemberNumber() {
		return memberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberEmail() {
		return memberEmail;
	}

	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}

	public int getMemberStamp() {
		return memberStamp;
	}

	public void setMemberStamp(int memberStamp) {
		this.memberStamp = memberStamp;
	}

	public List<ProductVO> getSummary() {
		return summary;
	}

	public void setSummary(List<ProductVO> summary) {
		this.summary = summary;
	}

}