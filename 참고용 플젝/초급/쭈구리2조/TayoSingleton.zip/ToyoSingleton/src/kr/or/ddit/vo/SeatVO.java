package kr.or.ddit.vo;

public class SeatVO {
	
	private int index;		//구분을 위한 번호인 동시에 좌석번호

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
}
