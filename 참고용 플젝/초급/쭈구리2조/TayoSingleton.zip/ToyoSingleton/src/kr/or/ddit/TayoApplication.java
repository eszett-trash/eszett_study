package kr.or.ddit;

import java.util.Scanner;

public class TayoApplication {
	public static void main(String[] args) {
		ViewClass vc = new ViewClass();
		vc.startMenu();
	}

}
