package basicproject;

import basicprojectVO.*;

public interface JavaBugerInterFace {
	
	

	
	
	
	
	
//////////////////////////////////////////////관리자///////////////////////////////////////	
	/**
	 * 
	 * @param masterKey
	 * @return 관리자 확인 결과
	 */
	boolean masterCheck(String masterKey);
////////////////////////////////////////////관리자//////////////////////////////////////////////
	

	
	
	
//////////////////////////////////////////////정보 추가 Add()//////////////////////////////////////////	

	/**
	 * 회원 가입
	 * @param MemberVO 타입의 memberInfo
	 * @return 회원가입 성공여부
	 */
	boolean memberAdd(MemberVO mVO);
	
	
	/**
	 * 
	 * @param JuiceVO 타입의 juiceInfo
	 * @return 쥬스 정보 등록 성공여부
	 */
	boolean juiceAdd(JuiceVO juiceInfo);
	
	
	/**
	 * 
	 * @param SideVO타입의 sideInfo
	 * @return 사이드메뉴 정보 등록의 성공 여부
	 */
	boolean sideAdd(SideVO sideInfo);
	
	/**
	 * 
	 * @param Condiment타입의 condiInfo
	 * @return 컨티먼트종류 정보 등록의 성공 여부
	 */
	boolean condiAdd(CondimentVO condiInfo);
	
	
////////////////////////////////////////////정보 추가 Add()//////////////////////////////////////////	
	
	
	
	
	
	
	
////////////////////////////////////////////정보 삭제 Delete()//////////////////////////////////////////	
	/**
	 * 
	 * @param String 타입의 memberTel (memberList에서 key로 memberTel)
	 * @return 회원삭제 성공여부
	 */
	boolean memberDel(String memberTel);
	
	
	/**
	 * 
	 * @param String 타입의 juiceName  ( juiceList에서 key로 juiceName)
	 * @return 쥬스정보 삭제 성공 여부
	 */
	boolean juiceDel(String juiceName);
	
	
	/**
	 * 
	 * @param String타입의 sideName ( sideList에서 key로 sideName)
	 * @return 사이드메뉴 정보 삭제의 성공여부
	 */
	boolean sideDel(String sideName);
	
	/**
	 * 
	 * @param String 타입의 condiInfo( condiList에서 key로 condiName)
	 * @return 컨티먼트종류 정보 삭제의 성공여부
	 */
	boolean condiDel(String condiName);
////////////////////////////////////////////정보 삭제 Delete()//////////////////////////////////////////
	


	
////////////////////////////////////////////정보 수정 Update()//////////////////////////////////////////\
	/**
	 * 
	 * @param String타입의 memberTel
	 * @return 회원수정 성공 여부
	 */
	boolean memberUpdate(String memberTel,MemberVO newMemberVO);	
	
	/**
	 * 
	 * @param String 타입의 juiceName  ( juiceList에서 key로 juiceName)
	 * @return 쥬스정보 수정 성공 여부
	 */
	boolean juiceUpdate(String juiceName,JuiceVO newJuice);
	
	
	/**
	 * 
	 * @param String타입의 sideName ( sideList에서 key로 sideName)
	 * @return 사이드메뉴 정보 수정의 성공여부
	 */
	boolean sideUpdate(String sideName,SideVO newSide);
	
	/**
	 * 
	 * @param String 타입의 condiInfo( condiList에서 key로 condiName)
	 * @return 컨티먼트종류 정보 수정의 성공여부
	 */
	boolean condiUpdate(String condiName,CondimentVO newCondi);	

	
	/**
	 * 회원의 포인트 정보를 업데이트 시켜준다.
	 * @param memberTel 회원검색을위한 번호
	 * @param point 더해질 포인트 값
	 * @return
	 */
	boolean memberPointUpdate(String memberTel,int point);
	
	/**
	 * 현재 회원의 포인트 정보를 불러온다.
	 * @param memberTel 검색할 회원 정보
	 * @return
	 */
	int getMemberPoint(String memberTel);
	
	/**
	 * 현재 회원의 포인트 사용 가능여부를 판단한다.
	 * @param memberTel 검색할 회원정보
	 * @param point  사용할 포인트
	 * @return
	 */
	boolean memberUsingPointCheck(String memberTel, int point);
	
////////////////////////////////////////////정보 수정 Update()//////////////////////////////////////////
	
	
	
	
	
	
	
	
	
//////////////////////////////////////////정보 검색 Search()//////////////////////////////////////////
	/**
	 * 
	 * @param String 타입의 memberTel (memberList에서 key로 memberTel)
	 * @return 회원정보 검색 성공 여부 (중복여부)
	 */
	boolean memberSearch(String memberTel);	
	
	/**
	 *  고객 정보찾기 --보류
	 * @param MemberVO타입의 v
	 * @return 검색한 고객의 정보 반환.
	 */
	String memberInfo(String memberTel);	
	
	/**
	 * 
	 * @param String 타입의 juiceName  ( juiceList에서 key로 juiceName)
	 * @return 쥬스정보 검색 성공 여부
	 */
	boolean juiceSearch(String juiceName);
	
	
	/**
	 * 
	 * @param String타입의 sideName ( sideList에서 key로 sideName)
	 * @return 사이드메뉴 정보 검색의 검색여부
	 */
	boolean sideSearch(String sideName);
	
	/**
	 * 
	 * @param String 타입의 condiInfo( condiList에서 key로 condiName)
	 * @return 컨티먼트종류 정보 검색의 성공여부
	 */
	boolean condiSearch(String condiName);	
	
	
	
	
////////////////////////////////////////정보 검색 Search()//////////////////////////////////////////

	
	
	///////////////////영수증//////////////////////
	
	/**
	 * 
	 * @param key 가져올 영수증의 key
	 * @return 입력받은 key의 영수증만 출력 key=>고객이름  (회원 or 비회원)
	 */
	String getSummary(String key);
	
	/**
	 * 전체 영수증을 출력한다
	 * @return 전체 영수증 정보
	 */
	String getSummaryAll();
	
	/**
	 *	영수증 정보를 등록한다. 
	 */
	boolean summaryAdd(String cosName,SummaryVO sVO);
	boolean summaryKeyCheck(String key);
	boolean summaryEmptyCheck();
	
	//////////////////////영수증 끝/////////////////
	
	
	
	
	
	
	
	
	/**
	 * 고객 전체정보조회
	 */
	String memberList();

	/**
	 * 가게 메뉴 정보
	 */
	String menuList();
	
	
	////////////////////////////////////메뉴 별 View 메서드////////////////////////////////// 
	public String condiView();
	public String juiceView();
	public String sideView();
	////////////////////////////////////////////////////////////////////////////////////
	
	
	
	///////////////////////////////////////메뉴별 가격 search 메서드///////////////////////
	public int getCondiPrice(String condiName);
	public int getJuicePrice(String juiceName);
	public int getSidePrice(String sideName);
	///////////////////////////////////////메뉴별 가격 search 메서드///////////////////////
	
	
	
	
	
	
	/////////////////////////////////////메뉴별 재고량 Search 메서드///////////////////////////
	public int getCondiStock(String condiName);
	public int getJuiceStock(String juiceName);
	public int getSideStock(String sideName);

	/////////////////////////////////////메뉴별 재고량 Search 메서드///////////////////////////
	
	
	//회원 이름 가져오기
	public String getMemberName(String memberTel);
	
	
	
	//돈보여주기
	public int setPlusMoney(int totalPrice);
	public int getMoney();
	
	public void getExcelSummary();
	
	
	
	public String getRecordAll();
	public void recordAdd(String name,int count);
	public void basicBread();
	
	
	public String getCondiIndex(int i);
	public int getCondiIndexToInt(String condiName);
	
	
	
	public String getJuiceIndexToName(int i);
	
}
