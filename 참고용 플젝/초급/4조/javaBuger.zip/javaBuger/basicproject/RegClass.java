package basicproject;
import java.util.regex.Pattern;

public class RegClass {
	public boolean telRegCheck(String memberTel){
		return Pattern.matches("(^01[01(6-9)][0-9]{7,8})", memberTel);
	//3 252
	}
	
	public boolean nameRegCheck(String name){
		return Pattern.matches("(^[가-힣]{2,5})", name);
	}
	
	public boolean memberNameRegCheck(String membername){
		return Pattern.matches("(^[가-힣]{2,5})", membername);
	}


}
