package basicprojectVO;

public class SummaryVO {
	private String costomerName;	//고객이름
	private String summary="";		//영수증 내용
	private int totalPrice;			//구매 가격
	

	public String getCostomerName() {
		return costomerName;
	}
	public void setCostomerName(String costomerName) {
		this.costomerName = costomerName;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary += summary;
	}
	public void setSummaryN(){
		this.summary = "";
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	public String checkToString() {
		return summary+"\n" + "결제예정금액 : " + totalPrice+" 원\n";
	}
	public String summaryToString() {
		return costomerName+" 님\n" + summary+"\n" + "결제금액 : " + totalPrice+" 원\n";
	}
	
	
	
	
	
	//보류
	
}
