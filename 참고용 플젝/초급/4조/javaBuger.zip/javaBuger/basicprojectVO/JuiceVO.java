package basicprojectVO;

public class JuiceVO {
	private String juiceName;	//쥬스이름
	private String juiceSize;	//쥬스 재고
	private int juicePrice;		//쥬스 가격
	private int juiceVolume;	//쥬스양 (M , L)
	private int juiceIndex;		//쥬스 인덱스번호
	
	//기본생성자로 이름,가격,재고,인덱스 번호를 필요로한다.
	public JuiceVO(String juiceName, int juicePrice,int juiceVolume,int juiceIndex){
		this.juiceName = juiceName;
		this.juicePrice = juicePrice;
		this.juiceVolume = juiceVolume;
		this.juiceIndex = juiceIndex;
	}
	public int getJuicePrice() {
		return juicePrice;
	}
	public void setJuicePrice(int juicePrice) {
		this.juicePrice = juicePrice;
	}
	public String getJuiceName() {
		return juiceName;
	}
	public void setJuiceName(String juiceName) {
		this.juiceName = juiceName;
	}
	public int getJuiceVolume() {
		return juiceVolume;
	}
	public void setJuiceVolume(int juiceVolume) {
		this.juiceVolume = juiceVolume;
	}
	
	public int getJuiceIndex() {
		return juiceIndex;
	}
	public void setJuiceIndex(int juiceIndex) {
		this.juiceIndex = juiceIndex;
	}
	public String toSummary(){
		return "쥬스 : " + juiceName+"  ("+juiceSize+") \n";
	}
	
	public String toList(){
		return juiceName + "\t\t" + juicePrice + "원\t\t" + juiceVolume+"개\n";
	}
	@Override
	public String toString() {
		return juiceIndex+"\t\t" + juiceName + "\t\t" + juicePrice + "\t\t" + juiceVolume+"\n";
	}
	
	
	
	
	
	
	
	

	
	
	
}
