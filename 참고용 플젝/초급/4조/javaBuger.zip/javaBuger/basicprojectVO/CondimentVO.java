package basicprojectVO;

public class CondimentVO {
	private String condiName;	//컨디먼트 이름
	private int condiPrice;		//컨디먼트 가격
	private int condiStock;		//컨디먼트 재고
	private int condiCount;		//컨디먼트 구입시 재고소모량
	private int condiIndex;		//컨디먼트 인덱스번호
	
	//기본생성자로 이름,가격,재고,인덱스 번호를 요구한다.
	public CondimentVO(String condiName, int condiPrice,int condiStock,int condiIndex) {
		this.condiName = condiName;
		this.condiPrice = condiPrice;
		this.condiStock = condiStock;
		this.condiIndex = condiIndex;
	}
	

	public String getCondiName() {
		return condiName;
	}


	public void setCondiName(String condiName) {
		this.condiName = condiName;
	}


	public int getCondiPrice() {
		return condiPrice;
	}


	public void setCondiPrice(int condiPrice) {
		this.condiPrice = condiPrice;
	}


	public int getCondiStock() {
		return condiStock;
	}


	public void setCondiStock(int condiStock) {
		this.condiStock = condiStock;
	}


	public int getCondiCount() {
		return condiCount;
	}


	public void setCondiCount(int condiCount) {
		this.condiCount = condiCount;
	}
	

	public int getCondiIndex() {
		return condiIndex;
	}


	public void setCondiIndex(int condiIndex) {
		this.condiIndex = condiIndex;
	}
	public String toList(){
		return condiName + "\t\t" + condiPrice + "원\t\t" + condiStock+"개\n";
	}

	public String toSummry(){
		return "컨디먼트 : " + condiName+"  "+condiCount+" 개\n";
	}
	@Override
	public String toString() {
		return condiIndex+"\t\t" + condiName + "\t\t" + condiPrice + "\t\t" + condiStock+"\n";
	}

	
	
	
	
	
}
