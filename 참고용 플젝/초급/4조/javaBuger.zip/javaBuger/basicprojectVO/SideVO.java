package basicprojectVO;

public class SideVO {
	//사이드메뉴 이름 가격
	private String sideName;
	private int sidePrice;
	private int sideStock;
	private int sideCount;
	private int sideIndex;
	
	
	public SideVO(String sideName,int sidePrice, int sideStock,int sideIndex){
		this.sideName = sideName;
		this.sidePrice = sidePrice;
		this.sideStock = sideStock;
		this.sideIndex = sideIndex;
	}
	
	public int getSideCount() {
		return sideCount;
	}

	public void setSideCount(int sideCount) {
		this.sideCount = sideCount;
	}

	public int getSideIndex() {
		return sideIndex;
	}

	public void setSideIndex(int sideIndex) {
		this.sideIndex = sideIndex;
	}

	public String getSideName() {
		return sideName;
	}
	public void setSideName(String sideName) {
		this.sideName = sideName;
	}
	public int getSidePrice() {
		return sidePrice;
	}
	public void setSidePrice(int sidePrice) {
		this.sidePrice = sidePrice;
	}
	public int getSideStock() {
		return sideStock;
	}
	public void setSideStock(int sideStock) {
		this.sideStock = sideStock;
	}
	public String toSummry() {
		return "사이드메뉴 : " + sideName+"  "+sideCount+" 개\n";
	}
	
	public String toList(){
		return sideName + "\t" + sidePrice + "원\t\t" + sideStock+"개\n";
	}
	@Override
	public String toString() {
		return sideIndex+"\t\t" + sideName + "\t" + sidePrice + "\t\t" + sideStock+"\n";
	}
	
	
	
	
	
	
}
