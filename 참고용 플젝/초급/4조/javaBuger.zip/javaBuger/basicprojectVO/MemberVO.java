package basicprojectVO;

public class MemberVO {
	private String memberName;       //회원이름  
	private String memberTel;		//회원번호
	private int memberPoint=0;		//회원생성시 시작 포인트

	//기본생성자로 이름과 회원번호를 요구한다.
	public MemberVO(String memberName,String memberTel){
		this.memberName = memberName;
		this.memberTel = memberTel;
	}
	public MemberVO(int memberPoint){
		
	}
	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberTel() {
		return memberTel;
	}

	public void setMemberTel(String memberTel) {
		this.memberTel = memberTel;
	}

	public int getMemberPoint() {
		return memberPoint;
	}

	public void setMemberPoint(int memberPoint) {
		this.memberPoint = memberPoint;
	}

	public String toString() {
		return "이 름 : " + memberName +"\t전화번호 : "+ memberTel+"\t현재 포인트 : "+ memberPoint+"P\n";
	}

	
}
