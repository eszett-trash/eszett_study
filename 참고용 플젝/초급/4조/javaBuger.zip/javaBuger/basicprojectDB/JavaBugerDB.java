package basicprojectDB;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.poi.hssf.dev.RecordLister;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import basicprojectVO.CondimentVO;
import basicprojectVO.JuiceVO;
import basicprojectVO.MemberVO;
import basicprojectVO.RecordVO;
import basicprojectVO.SummaryVO;
import basicprojectVO.SideVO;

public class JavaBugerDB {
	
	//회원 List
	private List<MemberVO> memberList = new ArrayList<MemberVO>();
	
	//컨디먼트 List
	private List<CondimentVO> condiList = new ArrayList<CondimentVO>();
	
	//쥬스 List
	private List<JuiceVO> juiceList = new ArrayList<JuiceVO>();
	
	//사이드메뉴 List
	private List<SideVO> sideList = new ArrayList<SideVO>();
	
	
	//마스터키 =>java
	private String masterKey = "1";
	
	//초기 가게 자금
	private final int MONEY = 1000000;	//백만원시작
	int money = MONEY;
	
	//영수증 정보 Map
	private HashMap<String, SummaryVO> summaryHash = new HashMap<String, SummaryVO>();
	
	//판매량List
	private List<RecordVO> recordList = new ArrayList<RecordVO>(); 
	
	//현재시간
	private Date now = new Date();
	SimpleDateFormat formatDate = new SimpleDateFormat("yyyyMMdd_mmss");
	
	
	
	
	
	
	public JavaBugerDB() {
		CondimentVO c00 = new CondimentVO("기본생성빵( )", 0, 0,0);
		RecordVO r0 = new RecordVO(c00.getCondiName(),0);
		recordList.add(r0);
		MemberVO m1 = new MemberVO("문정길","01094740724");
		MemberVO m2 = new MemberVO("오혁준","01012345678");
		MemberVO m3 = new MemberVO("김미진","01013467946");
		MemberVO m4 = new MemberVO("홍희경","01012312312");
		memberList.add(m1);
		memberList.add(m2);
		memberList.add(m3);
		memberList.add(m4);		
		
		CondimentVO c1 = new CondimentVO("콩자반", 300, 100,1);
		CondimentVO c2 = new CondimentVO("둥글게", 200, 70,2);
		CondimentVO c3 = new CondimentVO("녹두", 500, 100,3);
		CondimentVO c4 = new CondimentVO("노란콩", 800, 100,4);
		CondimentVO c5 = new CondimentVO("양파", 200, 100,5);
		condiList.add(c1);
		RecordVO r1 = new RecordVO(c1.getCondiName(),0);
		RecordVO r2 = new RecordVO(c2.getCondiName(),0);
		RecordVO r3 = new RecordVO(c3.getCondiName(),0);
		RecordVO r4 = new RecordVO(c4.getCondiName(),0);
		RecordVO r5 = new RecordVO(c5.getCondiName(),0);
		
		condiList.add(c2);
		condiList.add(c3);
		condiList.add(c4);
		condiList.add(c5);
		
		JuiceVO j1 = new JuiceVO("포도당", 500, 200,1);
		JuiceVO j2 = new JuiceVO("사이다", 500, 100,2);
		JuiceVO j3 = new JuiceVO("참이슬", 500, 80,3);
		RecordVO r6 = new RecordVO(j1.getJuiceName(),0);
		RecordVO r7 = new RecordVO(j2.getJuiceName(),0);
		RecordVO r8 = new RecordVO(j3.getJuiceName(),0);
		juiceList.add(j1);
		juiceList.add(j2);
		juiceList.add(j3);

		SideVO s1 = new SideVO("소라과자", 1000, 300,1);
		SideVO s2 = new SideVO("알루미늄", 1200, 100,2);
		SideVO s3 = new SideVO("토마토죽", 1500, 80,3);
		SideVO s4 = new SideVO("이상해풀", 2000, 70,4);
		SideVO s5 = new SideVO("치즈스틱", 500, 35,5);
		RecordVO r9 = new RecordVO(s1.getSideName(),0);
		RecordVO r10 = new RecordVO(s2.getSideName(),0);
		RecordVO r11 = new RecordVO(s3.getSideName(),0);
		RecordVO r12 = new RecordVO(s4.getSideName(),0);
		RecordVO r13 = new RecordVO(s5.getSideName(),0);
		recordList.add(r1);
		recordList.add(r2);
		recordList.add(r3);
		recordList.add(r4);
		recordList.add(r5);
		recordList.add(r6);
		recordList.add(r7);
		recordList.add(r8);
		recordList.add(r9);
		recordList.add(r10);
		recordList.add(r11);
		recordList.add(r12);
		recordList.add(r13);
		sideList.add(s1);
		sideList.add(s2);
		sideList.add(s3);
		sideList.add(s4);
		sideList.add(s5);		
		
	}

	//회원 정보 부를때 멤버리스트 toString 부른다.
	public List<MemberVO> getMemberList() {
		
		return memberList;
	}

	//쥬스 정보 부를때 주스리스트 toString 부른다.
	public List<JuiceVO> getJuiceList() {
		return juiceList;
	}

	//사이드메뉴 정보 부를때 사이드메뉴리스트 toString 부른다.
	public List<SideVO> getSideList() {
		return sideList;
	}

	
	//컨디먼트 정보 부를때 컨디먼트리스트 toString 부른다.
	public List<CondimentVO> getCondiList() {
		return condiList;
	}
	//마스터키 확인
	public boolean masterCheck(String masterKey){
		if(masterKey.equals(this.masterKey)){
			return true;
		}else{
			return false;
		}
	}

/////////////////////////////////////회원 정보 DB 메서드 시작////////////////////////////////////
	
	//회원번호 중복여부 확인
	public boolean getMemberSearch(String memberTel){
		for(int i=0; i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
				return true; 
			}			
		}
		return false;
	}
	
	//검색한 회원1명의 정보를 불러온다.
	public String getMemberInfoView(String memberTel){
		for(int i=0; i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
				return memberList.get(i).toString(); 
			}			
		}
		return null;
	}
	
	//검색한 회원1명의 정보를 삭제한다.
	public boolean getMemberInfoRemove(String memberTel){
		for(int i=0; i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
				memberList.remove(i);
				return true; 
			}			
		}
		return false;
	}	
	
	//검색한 회원1명의 정보를 수정한다.
	public boolean getMemberInfoUpdate(String memberTel,MemberVO newInfo){
		for(int i=0; i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
				memberList.set(i,null);
				memberList.set(i,newInfo);
				return true;
			}			
		}
		return false;
	}
	
	//전체 회원 정보 가져오기
	public String getMemberInfoAll(){
		String result = "";
		for(int i=0; i<memberList.size();i++){
			result += memberList.get(i).toString();			
		}
		return result;
	}
	
	public boolean memberAdd(MemberVO mVO){
		
		return memberList.add(mVO);
	}
	
	
	/**
	 * 회원 포인트 정보 업데이트 메서드
	 * @return 
	 */
	
	public boolean memberPointUpdate(String memberTel, int memberPoint){
		int oldMemberPoint = 0;
		for(int i=0; i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
			oldMemberPoint = memberList.get(i).getMemberPoint(); 
			memberList.get(i).setMemberPoint(oldMemberPoint + memberPoint);
			return true;
			}
		}
		return false;
	}
///////////////////////////////////////회원 정보 DB 메서드 끝////////////////////////////////////	



	
	
	
/////////////////////////////////////재고 관리 DB 메서드 시작////////////////////////////////////
	
	//전체 메뉴 조회
	public String getStockInfoView(){
		String result="";
		result +=("================컨디먼트===============\n");
		for(int i=0;i<condiList.size();i++){
			result+= condiList.get(i).toList();
		}
		result +=("==================쥬스==================\n");
		
		for(int i=0;i<juiceList.size();i++){
			result+= juiceList.get(i).toList();
		}
		result +=("=================사이드메뉴=================\n");
		for(int i=0;i<sideList.size();i++){
			result+= sideList.get(i).toList();
		}
		return result;
	}
	
	
	//컨디먼트 상품명 중복검사
	public boolean getCondiSearch(String name){
		for(int i=0; i<condiList.size();i++){
			if(condiList.get(i).getCondiName().equals(name)){
				return true;
			}
		}
		return false;
	}
	//쥬스 상품명 중복검사
	public boolean getJuiceSearch(String name){
		for(int i=0;  i<juiceList.size();i++){
			if(juiceList.get(i).getJuiceName().equals(name)){
				return true;
			}
		}
		return false;
	}
	//사이드메뉴 상품명 중복검사
	public boolean getSideSearch(String name){
		for(int i=0;  i<sideList.size();i++){
			if(sideList.get(i).getSideName().equals(name)){
				return true;
			}
		}
		return false;
	}
	
	//컨디먼트 상품 추가
	public boolean getCondiAdd(CondimentVO newCondiVO){		
		condiList.add(newCondiVO);
		RecordVO r = new RecordVO(newCondiVO.getCondiName(), 0);
		recordList.add(r);
		return true;
	}
	//쥬스 상품 추가
	public boolean getJuiceAdd(JuiceVO newJuiceVO){
		juiceList.add(newJuiceVO);
		RecordVO r = new RecordVO(newJuiceVO.getJuiceName(), 0);
		recordList.add(r);
		return true;
	}
	//사이드메뉴 상품 추가
	public boolean getSideAdd(SideVO newSideVO){
		RecordVO r = new RecordVO(newSideVO.getSideName(), 0);
		recordList.add(r);
		sideList.add(newSideVO);
		return true;
	}
	
	//컨디먼트 상품 제거
	public boolean getCondiDel(String condiName){
		for(int i=0; i<condiList.size();i++){
			if(condiList.get(i).getCondiName().equals(condiName)){
				condiList.remove(i);
				return true; 
			}			
		}
		return false;
	}
	
	//쥬스 상품 제거
	public boolean getJuiceDel(String juiceName){
		for(int i=0; i<juiceList.size();i++){
			if(juiceList.get(i).getJuiceName().equals(juiceName)){
				juiceList.remove(i);
				return true; 
			}			
		}
		return false;
	}
	
	//사이드메뉴 상품 제거
	public boolean getSideDel(String sideName){
		for(int i=0; i<condiList.size();i++){
			if(sideList.get(i).getSideName().equals(sideName)){
				sideList.remove(i);
				return true; 
			}			
		}
		return false;
	}
	
	//컨디먼트 상품 수정
	public boolean getCondiUpdate(String oldCondiName, CondimentVO newCondiVO){
		for(int i=0; i<condiList.size();i++){
			if(condiList.get(i).getCondiName().equals(oldCondiName)){
				condiList.set(i, null);
				condiList.set(i, newCondiVO);
				condiList.set(i, new CondimentVO(newCondiVO.getCondiName(), newCondiVO.getCondiPrice(), newCondiVO.getCondiStock(), condiList.get(i).getCondiIndex()));
				return true; 
			}			
		}
		return false;
	}
	
	//쥬스 상품 수정
	public boolean getJuiceUpdate(String oldJuiceName, JuiceVO newJuiceVO){
		for(int i=0; i<juiceList.size();i++){
			if(juiceList.get(i).getJuiceName().equals(oldJuiceName)){
				juiceList.set(i, null);
				juiceList.set(i, newJuiceVO);
				juiceList.set(i, new JuiceVO(newJuiceVO.getJuiceName(), newJuiceVO.getJuicePrice(), newJuiceVO.getJuiceVolume(),juiceList.get(i).getJuiceIndex()));
				return true; 
			}			
		}
		return false;
	}
	
	//사이드메뉴 상품 수정
	public boolean getSideUpdate(String oldSideName, SideVO newSide){
		for(int i=0; i<sideList.size();i++){
			if(sideList.get(i).getSideName().equals(oldSideName)){
				sideList.set(i, null);
				sideList.set(i, newSide);
				sideList.set(i, new SideVO(newSide.getSideName(), newSide.getSidePrice(), newSide.getSideStock(), sideList.get(i).getSideIndex()));
				return true; 
			}			
		}
		return false;
	}
	
/////////////////////////////////////재고 관리 DB 메서드 끝////////////////////////////////////	

			

	
	///////////////////////////////////////// 메뉴별 View 메서드/ ////////////////////////////////
	
	
	public String getCondiView() {
		String result = "";
		for(int i=0; i<condiList.size();i++){
			result += condiList.get(i).toString();
		}
		return result;
	}
	public String getJuiceView() {
		String result = "";
		for(int i=0; i<juiceList.size();i++){
			result += juiceList.get(i).toString();
		}
		return result;
	}
	public String getSideView() {
		String result = "";
		for(int i=0; i<sideList.size();i++){
			result += sideList.get(i).toString();
		}
		return result;
	}
	
	
	///////////////////////////////////메뉴별 getPrice 메서드/////////////////////////////////
	public int getCondiPrice(String condiName){
		for(int i=0; i<condiList.size();i++){
			if(condiList.get(i).getCondiName().equals(condiName)){
				return condiList.get(i).getCondiPrice();
			}
		}
		return 0;
	}
	public int getJuicePrice(String juiceName){
		for(int i=0; i<juiceList.size();i++){
			if(juiceList.get(i).getJuiceName().equals(juiceName)){
				return juiceList.get(i).getJuicePrice();
			}
		}
		return 0;
	}
	public int getSidePrice(String sideName){
		for(int i=0; i<condiList.size();i++){
			if(sideList.get(i).getSideName().equals(sideName)){
				return sideList.get(i).getSidePrice();
			}
		}
		return 0;
	}
	///////////////////////////////////메뉴별 getPrice 메서드/////////////////////////////////
	
	
	
	
	/////////////////////////////////메뉴별 getStock 메서드/////////////////////
	public int getCondiStock(String condiName){
		for(int i=0; i<condiList.size();i++){
			if(condiList.get(i).getCondiName().equals(condiName)){
				return condiList.get(i).getCondiStock();
			}
		}
		return 0;
	}
	
	public int getJuiceStock(String juiceName){
		for(int i=0; i<juiceList.size();i++){
			if(juiceList.get(i).getJuiceName().equals(juiceName)){
				return juiceList.get(i).getJuiceVolume();
			}
		}
		return 0;
	}
	public int getSideStock(String sideName){
		for(int i=0; i<sideList.size();i++){
			if(sideList.get(i).getSideName().equals(sideName)){
				return sideList.get(i).getSideStock();
			}
		}
		return 0;
	}
	/////////////////////////////////메뉴별 setStock 재고관리 메서드/////////////////////
	
	
	
	
	
	
	
	//////////////영수증 전용메서드/////////////////
	/**
	 * 영수증을 더해주는 메서드
	 * @param cosName(Key)은 구매자이름에 1씩증가하는 숫자를 가진다. 
	 * @param sVo에는 해당 구매자의 영수증이 담겨있다. 
	 * @return (구매자가 중복일 경우 맵에서 없어지기 때문에 이름중복안되게 넣는다.)
	 */
	public boolean summaryAdd(String cosName,SummaryVO sVO){
		summaryHash.put(cosName, sVO);
		return true;
	}
	
	/**
	 * 입력받은 key값의 사람이름의 영수증만 리턴하는 메서드
	 * @param key값은 보고싶은 사람의 영수증만 찾는 사람의 이름이다.
	 * @return	key이름을 가진 사람이 구매한 영수증만 리턴
	 */
	public String getSummary(String key){
		String result ="";
		Object[] s = summaryHash.values().toArray();
		
		SummaryVO[] sVO = new SummaryVO[s.length];
		for(int i=0; i<sVO.length;i++){
			sVO[i] = (SummaryVO)s[i];
		}
		for(int i=0;i<sVO.length;i++){
			if(sVO[i].getCostomerName().equals(key)){
				result += sVO[i].summaryToString();
			}
		}
		return result;
	}
	
	/**
	 * 전체 영수증 출력
	 * @return 저장된 모든 영수증 정보
	 */
	public String getSummaryAll(){
		String result ="";
		Object[] s = summaryHash.values().toArray();	
		
		SummaryVO[] sVO = new SummaryVO[s.length];
		for(int i=0; i<sVO.length;i++){
			sVO[i] = (SummaryVO)s[i];
		}
		for(int i=0;i<sVO.length;i++){
			result += sVO[i].summaryToString();
		}
		return result;
	}
	
	/**
	 * 그동안 판매된 상품들의 누적 판매량을 리턴한다.
	 * @return
	 */
	public String getRecordAll(){
		String result = "";
		for (int i = 0; i < recordList.size(); i++) {
			result += recordList.get(i).toString();
		}
		return result;
	}
	
	//key값이 있는지 확인
	public boolean summaryKeyCheck(String key){
		String result ="";
		Object[] s = summaryHash.values().toArray();	
		
		SummaryVO[] sVO = new SummaryVO[s.length];
		for(int i=0; i<sVO.length;i++){
			sVO[i] = (SummaryVO)s[i];
		}
		for(int i=0;i<sVO.length;i++){
			if(sVO[i].getCostomerName().equals(key)){
				return true;
			}
		}
		return false;
	}
	
	public boolean summaryEmptyCheck(){
		return summaryHash.isEmpty();
	} 
	
	//회원 이름 가져오기
	public String getMemberName(String memberTel) {
		String result = "";
		for(int i=0; i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
				return memberList.get(i).getMemberName();
			}
		}
		return null;
	}

	
	
	//가게 매출 업데이트
	public int setPlusMoney(int totalPrice){
		this.money +=totalPrice;
		return this.money+totalPrice;
	}
	
	//현재 가게 매출 보여주기
	public int getMoney(){
		return money-MONEY;
	}
	
	
	
	
	/**
	 * 영수증 엑셀파일 만드는 메서드
	 */
	public void getExcelSummary(){
		Workbook xlsxWb = new HSSFWorkbook();
		 
        // *** Sheet-------------------------------------------------
        // Sheet 생성
        Sheet sheet1 = xlsxWb.createSheet("firstSheet"); 
        // 컬럼 너비 설정
        
        for(int i=0; i<=summaryHash.size();i++){
        	sheet1.setColumnWidth(i, 6666);
        }
        
        // ----------------------------------------------------------
         
        // *** Style--------------------------------------------------
        // Cell 스타일 생성
        CellStyle cellStyle = xlsxWb.createCellStyle();
        
        
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN); //테두리 두껍게 
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);

        // 줄 바꿈
        cellStyle.setWrapText(true);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        

        // Cell 색깔, 무늬 채우기
         
        Row row = null;
        Cell cell = null;
        //----------------------------------------------------------
         
        
		String name ="";
		String summary ="";
		Object[] s = summaryHash.values().toArray();	
		
		SummaryVO[] sVO = new SummaryVO[s.length];
		for(int i=0; i<sVO.length;i++){
			sVO[i] = (SummaryVO)s[i];
		}		
        // 첫 번째 줄
        row = sheet1.createRow(0);
        cell = row.createCell(0);
        cell.setCellValue("\n회원\n이름\n");
        cell.setCellStyle(cellStyle);        
        
        // 첫 번째 줄에 Cell 설정하기-------------
        for(int i=1; i<summaryHash.size()+1;i++){
        	name = sVO[i-1].getCostomerName();
        	cell = row.createCell(i);    // 첫번째쭐 i 번째에
        	cell.setCellValue(name+"\n\n");	//이름쓰기
        	cell.setCellStyle(cellStyle); // 셀 스타일 적용
        }

        //---------------------------------
         
        // 두 번째 줄
        row = sheet1.createRow(1);         
        cell = row.createCell(0);		//2번째줄0번째에
        cell.setCellValue("\n영수증\n목록\n");
        cell.setCellStyle(cellStyle);
        // 두 번째 줄에 Cell 설정하기-------------
        for(int i=1; i<summaryHash.size()+1;i++){
        	cell = row.createCell(i);		//2번째줄i번째에
        	cell.setCellValue(sVO[i-1].getSummary());		//영수증쓰기
        	cell.setCellStyle(cellStyle); // 셀 스타일 적용        	
        }
        
        row = sheet1.createRow(3);
        cell = row.createCell(0);
        cell.setCellValue("오늘의 이득 : ");
        cell = row.createCell(1);
        cell.setCellValue(money-MONEY + " 원");
        //---------------------------------
 
        // excel 파일 저장
        try {
            File xlsxFile = new File("D:/Summary"+formatDate.format(now)+".xls");
            FileOutputStream fileOut = new FileOutputStream(xlsxFile);
            xlsxWb.write(fileOut);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
         
    }
	
	
	/**
	 * record에 저장해줌
	 * @param name을 찾아서
	 * @param count 를 더해준다.
	 * @return
	 */
	public void recordAdd(String name, int count) {
		int oldCount = 0;
		for(int i=0;i<recordList.size();i++){
			if(recordList.get(i).getRecordName().equals(name)){
				oldCount = recordList.get(i).getRecordCount();
				recordList.set(i, null);
				recordList.set(i, new RecordVO(name, oldCount+count));
			}
		}
	}
	
	/**
	 * 주문시작시에 기본으로 구입하는 빵 더하기
	 */
	public void basicBread() {
		int oldCount = recordList.get(0).getRecordCount();
		recordList.get(0).setRecordCount(oldCount+1);
	}

	/**
	 * 현재 회원의 포인트 정보를 불러온다.
	 * @param memberTel 검색할 회원정보
	 * @return
	 */
	public int getMemberPoint(String memberTel) {		
		for(int i=0; i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
				return memberList.get(i).getMemberPoint();
			}
		}
		return 0;
	}
	
	/**
	 * 회원이 포인트 사용시에 0보다 크면 true로 포인트차감
	 * @param memberTel	검색할 회원번호
	 * @param point     차감시킬 포인트값
	 * @return
	 */
	public boolean memberUsingPointCheck(String memberTel, int point) {
		int oldPoint = 0;
		for(int i=0;i<memberList.size();i++){
			if(memberList.get(i).getMemberTel().equals(memberTel)){
				oldPoint = memberList.get(i).getMemberPoint()-point;
				if(oldPoint>0){
					return true;
				}
			}		
		}
		return false;
		
	}
	
	public String getCondiIndex(int i) {
		for (int j = 0; j < condiList.size(); j++) {
			if(condiList.get(j).getCondiIndex()==i){
				return condiList.get(j).getCondiName();
			}
		}
		return "";
	}

	public int getCondiIndexToInt(String condiName) {
			for (int i = 0; i < condiList.size(); i++) {
				if(condiList.get(i).getCondiName().equals(condiName)){
					return condiList.get(i).getCondiIndex();
				}
			}
		return 0;
	}

	public String getJuiceIndexToName(int juiceIndex) {
		for (int j = 0; j < juiceList.size(); j++) {
			if(juiceList.get(j).getJuiceIndex()==juiceIndex){
				return juiceList.get(j).getJuiceName();
			}
		}
		return null;
	}

	public String getSideIndexToName(int sideIndex) {
		for (int j = 0; j < sideList.size(); j++) {
			if(sideList.get(j).getSideIndex()==sideIndex){
				return sideList.get(j).getSideName();
			}
		}
		// TODO Auto-generated method stub
		return null;
	}

	public int getJuiceIndexToInt(String juiceName) {
		for (int i = 0; i < juiceList.size(); i++) {
			if(juiceList.get(i).getJuiceName().equals(juiceName)){
				return juiceList.get(i).getJuiceIndex();
			}
		}
		return 0;
	}
	
	public int getSideIndexToInt(String sideName) {
		for (int i = 0; i < sideList.size(); i++) {
			if(sideList.get(i).getSideName().equals(sideName)){
				return sideList.get(i).getSideIndex();
			}
		}
		return 0;
	}
	
	
}
