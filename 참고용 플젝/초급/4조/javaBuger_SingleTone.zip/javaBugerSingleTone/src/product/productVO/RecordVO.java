package product.productVO;

public class RecordVO {
	private String recordName;	//재고의 이름
	private int recordCount;	//재고 갯수
	
	//기본생성자로 재고의 이름과 갯수를 요구한다.
	public RecordVO(String recordName,int recordCount){
		this.recordName = recordName;
		this.recordCount = recordCount;
	}
	public String getRecordName() {
		return recordName;
	}
	public void setRecordName(String recordName) {
		this.recordName = recordName;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	@Override
	public String toString() {
		return "상품명 : "+recordName +"   \t판매량 : "+recordCount+" 개\n";
	}
	
	
	
}
