package product.productDAO;


import member.memberDAO.MemberDAO;
import product.productVO.CondimentVO;
import product.productVO.JuiceVO;
import product.productVO.SideVO;
import product.productVO.SummaryVO;
import db.JavaBugerDB;

public class ProductDAO implements ProductDAOInterFace {
	private static ProductDAO dao = null;
	private JavaBugerDB d = null;
	
	private ProductDAO(){
		d = JavaBugerDB.getInstance();
	}
	
	public static ProductDAO getInstance() {
		if(dao == null){
			dao = new ProductDAO();
		}
		return dao;
	}

	/**
	 * DB클래스에서 새로운 음료를 추가하는 메서드
	 */
	@Override
	public boolean juiceAdd(JuiceVO juiceInfo) {
		
		return d.getJuiceAdd(juiceInfo);
	}
	
	
	/**
	 * DB클래스에서 새로운 사이드를 추가하는 메서드
	 */
	@Override
	public boolean sideAdd(SideVO sideInfo) {
		
		return d.getSideAdd(sideInfo);
	}
	
	
	/**
	 * DB클래스에서 새로운 컨디먼트를 추가하는 메서드
	 */	
	@Override
	public boolean condiAdd(CondimentVO condiInfo) {
		d.getCondiAdd(condiInfo);
		return true;
	}
	/**
	 * DB클래스에서 List<juiceVO>의 juiceList에서 juiceName를 검색후
	 * JuiceVO객체의 해당Index번호 Remove하는 메서드
	 */
	@Override
	public boolean juiceDel(String juiceName) {
		
		return d.getJuiceDel(juiceName);
	}

	/**
	 * DB클래스의 List<sideVO>의 sideList에서 sideName를 검색후
	 * SideVO객체의 해당Index번호 Remove하는 메서드
	 */
	@Override
	public boolean sideDel(String sideName) {
		
		return d.getSideDel(sideName);
	}

	/**
	 * DB클래스의 List<condiVO>의 condiList에서 condiName를 검색후
	 * CondiVO객체의 해당Index번호 Remove하는 메서드
	 */
	@Override
	public boolean condiDel(String condiName) {
		d.getCondiDel(condiName);
		return true;
	}
	/**
	 * DB클래스의 List<CondiVO>의 condiList에서 condiName을 검색후
	 * CondiVO객체의 해당Index번호에
	 * CondiVO객체타입의 newCondiVO를 set하는 메서드 
	 */
	@Override
	public boolean condiUpdate(String condiName,CondimentVO newCondi) {
		d.getCondiUpdate(condiName, newCondi);
		return true;
	}
	
	/**
	 * DB클래스의 List<JuiceVO>의 juiceList에서 juiceName을 검색후
	 * JuiceVO객체의 해당Index번호에
	 * JuiceVO객체타입의 newJuiceVO를 set하는 메서드 
	 */
	@Override
	public boolean juiceUpdate(String juiceName,JuiceVO newJuice) {
		
		return d.getJuiceUpdate(juiceName, newJuice);
	}

	
	/**
	 * DB클래스의 List<SideVO>의 sideList에서 sideName을 검색후
	 * SideVO객체의 해당Index번호에
	 * SideVO객체타입의 newSideVO를 set하는 메서드 
	 */
	@Override
	public boolean sideUpdate(String sideName,SideVO newSide) {
		// TODO Auto-generated method stub
		return d.getSideUpdate(sideName,newSide);
	}
	/**
	 * DB클래스의 List<CondiVO>의 condiList에서 condiName을 검색후
	 * 있으면 true  없으면 false 반환.
	 */
	@Override
	public boolean condiSearch(String condiName) {
		return d.getCondiSearch(condiName);
	}
	
	/**
	 * DB클래스의 List<JuiceVO>의 juiceList에서 juiceName을 검색후
	 * 있으면 true  없으면 false 반환.
	 */
	@Override
	public boolean juiceSearch(String juiceName) {
		return d.getJuiceSearch(juiceName);
	}

	/**
	 * DB클래스의 List<SideVO>의 sideList에서 sideName을 검색후
	 * 있으면 true  없으면 false 반환.
	 */
	@Override
	public boolean sideSearch(String sideName) {
		return d.getSideSearch(sideName);
	}
	/**
	 *전체 멤버List String형태로 리턴
	 */

	/**
	 *전체 메뉴List String형태로 리턴
	 */
	@Override
	public String menuList() {
		// TODO Auto-generated method stub
		return d.getStockInfoView();		
	}
	/**
	 * 전체 영수증 출력
	 */
	@Override
	public String getSummaryAll() {
		return d.getSummaryAll();
	}

	
	/**
	 * 회원 영수증 출력
	 */
	@Override
	public String getSummary(String key) {		
		return d.getSummary(key);
	}

	
	
	
	/**
	 * 컨디먼트의 정보를 출력한다.
	 */
	@Override
	public String condiView() {
		
		return d.getCondiView();
	}
	
	/**
	 * 쥬스의 정보를 출력한다.
	 */
	@Override
	public String juiceView() {
		// TODO Auto-generated method stub
		return d.getJuiceView();
	}

	/**
	 * 사이드메뉴의 정보를 출력한다.
	 */
	@Override
	public String sideView() {
		// TODO Auto-generated method stub
		return d.getSideView();
	}

	
	
	
	
	
	/**
	 * 컨디먼트의 가격정보를 리턴 받는다.
	 */
	@Override
	public int getCondiPrice(String condiName) {
		
		return d.getCondiPrice(condiName);
	}

	/**
	 * 쥬스의 가격정보를 리턴 받는다.
	 */
	@Override
	public int getJuicePrice(String juiceName) {
		// TODO Auto-generated method stub
		return d.getJuicePrice(juiceName);
	}

	/**
	 * 사이드메뉴의 가격정보를 리턴 받는다.
	 */
	@Override
	public int getSidePrice(String sideName) {
		
		return d.getSidePrice(sideName);
	}


	/**
	 * 컨디먼트의 재고량을 구해온다.
	 */
	@Override
	public int getCondiStock(String condiName) {
		// TODO Auto-generated method stub
		return d.getCondiStock(condiName);
	}

	/**
	 * 쥬스의 재고량을 구해온다.
	 */
	@Override
	public int getJuiceStock(String juiceName) {
		// TODO Auto-generated method stub
		return d.getJuiceStock(juiceName);
	}

	/**
	 * 사이드메뉴의 재고량을 구해온다.
	 */
	@Override
	public int getSideStock(String sideName) {
		// TODO Auto-generated method stub
		return d.getSideStock(sideName);
	}

	
	
	
	
	
	/**
	 * 영수증을 맵에 저장한다. 키값은 이름
	 */
	@Override
	public boolean summaryAdd(String cosName, SummaryVO sVO) {
		
		return d.summaryAdd(cosName,sVO);
	}

	/**
	 * 맵에 영수증이 있는지 확인한다.
	 */
	
	@Override
	public boolean summaryKeyCheck(String key) {
		
		return d.summaryKeyCheck(key);
	}
	
	/**
	 * 영수증이 비어있는지 확인한다.
	 */
	@Override
	public boolean summaryEmptyCheck(){
		
		return d.summaryEmptyCheck();
	}
	/**
	 * 가게의 money에 판매가격을 더해준다.
	 */
	@Override
	public int setPlusMoney(int totalPrice) {
		return d.setPlusMoney(totalPrice);
	}
	
	
	/**
	 * 현재 까지의 가게의 매출액을 보여준다.	 
	 * 
	 */
	@Override
	public int getMoney(){
		return d.getMoney();
	}


//	/**
//	 * 현재까지의 영수증 전체를 xls파일로 변환
//	 */
//	@Override
//	public void getExcelSummary() {
//		d.getExcelSummary();
//		
//	}

	/**
	 * 현재까지의 누적 판매량 출력 메서드
	 */
	@Override
	public String getRecordAll() {
		return d.getRecordAll();
	}
	/**
	 * 누적 판매량 갱신 메서드
	 */
	@Override
	public void recordAdd(String name, int count) {
		// TODO Auto-generated method stub
		d.recordAdd(name,count);
	}
	/**
	 * 주문 들어가면 기본빵 1개 들어간다.
	 */
	@Override
	public void basicBread() {
		d.basicBread();
	}

	@Override
	public String getCondiIndex(int i) {
		return d.getCondiIndex(i);
	}

	@Override
	public int getCondiIndexToInt(String condiName) {
		return d.getCondiIndexToInt(condiName);
	}

	@Override
	public String getCondiIndexToName(int i) {
		return d.getCondiIndex(i);
	}

	@Override
	public String getJuiceIndex(int i) {
		return null;
	}

	@Override
	public int getJuiceIndexToInt(String JuiceName) {
		// TODO Auto-generated method stub
		return d.getJuiceIndexToInt(JuiceName);
	}

	@Override
	public String getJuiceIndexToName(int i) {
		return d.getJuiceIndexToName(i);
	}

	@Override
	public String getSideIndex(int i) {
		return null;
	}

	@Override
	public int getSideIndexToInt(String SideName) {
		return d.getSideIndexToInt(SideName);
	}

	@Override
	public String getSideIndexToName(int i) {
		return d.getSideIndexToName(i);
	}
	
	
	

}
