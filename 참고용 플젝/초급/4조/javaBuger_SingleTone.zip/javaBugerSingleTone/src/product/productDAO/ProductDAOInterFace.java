package product.productDAO;


import product.productVO.CondimentVO;
import product.productVO.JuiceVO;
import product.productVO.SideVO;
import product.productVO.SummaryVO;


public interface ProductDAOInterFace {
	/**
	 * 
	 * @param JuiceVO 타입의 juiceInfo
	 * @return 쥬스 정보 등록 성공여부
	 */
	boolean juiceAdd(JuiceVO juiceInfo);
	
	
	/**
	 * 
	 * @param SideVO타입의 sideInfo
	 * @return 사이드메뉴 정보 등록의 성공 여부
	 */
	boolean sideAdd(SideVO sideInfo);
	
	/**
	 * 
	 * @param Condiment타입의 condiInfo
	 * @return 컨티먼트종류 정보 등록의 성공 여부
	 */
	boolean condiAdd(CondimentVO condiInfo);
	
	/**
	 * 
	 * @param String 타입의 juiceName  ( juiceList에서 key로 juiceName)
	 * @return 쥬스정보 삭제 성공 여부
	 */
	boolean juiceDel(String juiceName);
	
	
	/**
	 * 
	 * @param String타입의 sideName ( sideList에서 key로 sideName)
	 * @return 사이드메뉴 정보 삭제의 성공여부
	 */
	boolean sideDel(String sideName);
	
	/**
	 * 
	 * @param String 타입의 condiInfo( condiList에서 key로 condiName)
	 * @return 컨티먼트종류 정보 삭제의 성공여부
	 */
	boolean condiDel(String condiName);
	/**
	 * 
	 * @param String 타입의 juiceName  ( juiceList에서 key로 juiceName)
	 * @return 쥬스정보 수정 성공 여부
	 */
	boolean juiceUpdate(String juiceName,JuiceVO newJuice);
	
	
	/**
	 * 
	 * @param String타입의 sideName ( sideList에서 key로 sideName)
	 * @return 사이드메뉴 정보 수정의 성공여부
	 */
	boolean sideUpdate(String sideName,SideVO newSide);
	
	/**
	 * 
	 * @param String 타입의 condiInfo( condiList에서 key로 condiName)
	 * @return 컨티먼트종류 정보 수정의 성공여부
	 */
	boolean condiUpdate(String condiName,CondimentVO newCondi);	
	/**
	 * 
	 * @param String 타입의 juiceName  ( juiceList에서 key로 juiceName)
	 * @return 쥬스정보 검색 성공 여부
	 */
	boolean juiceSearch(String juiceName);
	
	
	/**
	 * 
	 * @param String타입의 sideName ( sideList에서 key로 sideName)
	 * @return 사이드메뉴 정보 검색의 검색여부
	 */
	boolean sideSearch(String sideName);
	
	/**
	 * 
	 * @param String 타입의 condiInfo( condiList에서 key로 condiName)
	 * @return 컨티먼트종류 정보 검색의 성공여부
	 */
	boolean condiSearch(String condiName);
	/**
	 * 
	 * @param key 가져올 영수증의 key
	 * @return 입력받은 key의 영수증만 출력 key=>고객이름  (회원 or 비회원)
	 */
	String getSummary(String key);
	
	/**
	 * 전체 영수증을 출력한다
	 * @return 전체 영수증 정보
	 */
	String getSummaryAll();
	
	/**
	 *	영수증 정보를 등록한다. 
	 */
	boolean summaryAdd(String cosName,SummaryVO sVO);
	boolean summaryKeyCheck(String key);
	boolean summaryEmptyCheck();

	/**
	 * 가게 메뉴 정보
	 */
	String menuList();
	
	
	////////////////////////////////////메뉴 별 View 메서드////////////////////////////////// 
	public String condiView();
	public String juiceView();
	public String sideView();
	////////////////////////////////////////////////////////////////////////////////////
	
	
	
	///////////////////////////////////////메뉴별 가격 search 메서드///////////////////////
	public int getCondiPrice(String condiName);
	public int getJuicePrice(String juiceName);
	public int getSidePrice(String sideName);
	///////////////////////////////////////메뉴별 가격 search 메서드///////////////////////
	
	
	
	
	
	
	/////////////////////////////////////메뉴별 재고량 Search 메서드///////////////////////////
	public int getCondiStock(String condiName);
	public int getJuiceStock(String juiceName);
	public int getSideStock(String sideName);

	/////////////////////////////////////메뉴별 재고량 Search 메서드///////////////////////////
	
	//돈보여주기
	public int setPlusMoney(int totalPrice);
	public int getMoney();
	
//	public void getExcelSummary();
	
	
	
	public String getRecordAll();
	public void recordAdd(String name,int count);
	public void basicBread();
	
	
	public String getCondiIndex(int i);
	public int getCondiIndexToInt(String condiName);	
	public String getCondiIndexToName(int i);
	
	public String getJuiceIndex(int i);
	public int getJuiceIndexToInt(String JuiceName);	
	public String getJuiceIndexToName(int i);
	
	public String getSideIndex(int i);
	public int getSideIndexToInt(String SideName);	
	public String getSideIndexToName(int i);
}
