package member.memberDAO;

import java.util.HashMap;

import product.productVO.SummaryVO;
import db.JavaBugerDB;
import member.memberVO.MemberVO;

public class MemberDAO implements MemberDAOInterFace{
	private static MemberDAO dao = null;
	private JavaBugerDB d = null;
	
	private MemberDAO(){
		d = JavaBugerDB.getInstance();
	}
	
	public static MemberDAO getInstance() {
		if(dao == null){
			dao = new MemberDAO();
		}
		return dao;
	}
	
	
	/**
	 * db클래스에서 masterKey 검사하는 메서드 
	 */
	@Override
	public boolean masterCheck(String masterKey) {		
		return d.masterCheck(masterKey);
	}
	/**
	 * 회원 가입시 회원의 정보를 DB에 넣어주는 메서드
	 */
	@Override
	public boolean memberAdd(MemberVO mVO) {
		return d.memberAdd(mVO);
	}
	
	/**
	 * 회원의 포인트를 업데이트 해주는 메서드
	 */
	@Override
	public boolean memberPointUpdate(String memberTel, int point) {
		return d.memberPointUpdate(memberTel, point);
	}
	/**
	 * DB클래스에서 List<MemberVO>의 memberList에서 memberTel을 검색후
	 * MemberVO객체의 해당Index번호 Remove하는 메서드
	 */
	@Override
	public boolean memberDel(String memberTel) {
		// TODO Auto-generated method stub
		
		return d.getMemberInfoRemove(memberTel);
	}
	/**
	 * DB클래스의 List<MemberVO>의 memberList에서 memberTel를 검색후
	 * MemberVO객체의 해당Index번호에
	 * MemberVO객체타입의 newMemberVO를 set하는 메서드 
	 */
	@Override
	public boolean memberUpdate(String memberTel,MemberVO newMemberVO) {
		
		return d.getMemberInfoUpdate(memberTel, newMemberVO);
	}
	/**
	 * DB클래스의 List<MemberVO>의 memberList에서 memberTel을 검색후
	 * 있으면 true  없으면 false 반환.
	 */
	@Override
	public boolean memberSearch(String memberTel) {
		return d.getMemberSearch(memberTel);
	}
	@Override
	public String memberList() {
		// TODO Auto-generated method stub
		return d.getMemberInfoAll();
	}
	/**
	 * List<MemberVO>의 memberList에서
	 * memberTel을 가진사람 1명을 String형태로 리턴
	 */
	@Override
	public String memberInfo(String memberTel) {
		
		return d.getMemberInfoView(memberTel);
		
	}
	/**
	 * 회원 이름 가져오기
	 */
	@Override
	public String getMemberName(String memberTel) {
		// 
		return d.getMemberName(memberTel);
	}
	/**
	 * 회원의 포인트 정보를 가져온다.
	 */
	@Override
	public int getMemberPoint(String memberTel) {
		return d.getMemberPoint(memberTel);
	}



	
	/**
	 * 현재 회원의 포인트 사용 가능여부를 판단한다.
	 * @param memberTel 검색할 회원정보
	 * @param point  사용할 포인트
	 * @return
	 */
	@Override
	public boolean memberUsingPointCheck(String memberTel, int point) {
		return d.memberUsingPointCheck(memberTel,point);
	}

	@Override
	public HashMap<String, SummaryVO> getSummaryHash() {
		return d.getSummaryHash();
	}
}
