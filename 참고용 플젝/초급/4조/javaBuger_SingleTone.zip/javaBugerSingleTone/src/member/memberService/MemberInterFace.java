package member.memberService;

import java.util.HashMap;

import product.productVO.SummaryVO;
import member.memberVO.MemberVO;

//import basicprojectVO.MemberVO;

public interface MemberInterFace {
	/**
	* 
	* @param masterKey
	* @return 관리자 확인 결과
	*/
	boolean masterCheck(String masterKey);

	/**
	* 회원 가입
	* @param MemberVO 타입의 memberInfo
	* @return 회원가입 성공여부
	*/
	boolean memberAdd(MemberVO mVO);
	
	/**
	 * 
	 * @param String 타입의 memberTel (memberList에서 key로 memberTel)
	 * @return 회원삭제 성공여부
	 */
	boolean memberDel(String memberTel);
	
	/**
	 * 
	 * @param String타입의 memberTel
	 * @return 회원수정 성공 여부
	 */
	boolean memberUpdate(String memberTel,MemberVO newMemberVO);	
	/**
	 * 회원의 포인트 정보를 업데이트 시켜준다.
	 * @param memberTel 회원검색을위한 번호
	 * @param point 더해질 포인트 값
	 * @return
	 */
	boolean memberPointUpdate(String memberTel,int point);
	
	/**
	 * 현재 회원의 포인트 정보를 불러온다.
	 * @param memberTel 검색할 회원 정보
	 * @return
	 */
	int getMemberPoint(String memberTel);
	
	/**
	 * 현재 회원의 포인트 사용 가능여부를 판단한다.
	 * @param memberTel 검색할 회원정보
	 * @param point  사용할 포인트
	 * @return
	 */
	boolean memberUsingPointCheck(String memberTel, int point);
	/**
	 * 
	 * @param String 타입의 memberTel (memberList에서 key로 memberTel)
	 * @return 회원정보 검색 성공 여부 (중복여부)
	 */
	boolean memberSearch(String memberTel);	
	
	/**
	 *  고객 정보찾기 --보류
	 * @param MemberVO타입의 v
	 * @return 검색한 고객의 정보 반환.
	 */
	String memberInfo(String memberTel);
	/**
	 * 고객 전체정보조회
	 */
	String memberList();
	//회원 이름 가져오기
	String getMemberName(String memberTel);


	HashMap<String, SummaryVO> getSummaryHash();
}
