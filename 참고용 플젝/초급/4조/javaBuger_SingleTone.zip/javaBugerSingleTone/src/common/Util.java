package common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;















import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import product.productVO.SummaryVO;


public class Util {
	private Date now = new Date();
	SimpleDateFormat formatDate = new SimpleDateFormat("yyMMdd_kkmm");
	
	/**
	 * 영수증 엑셀파일 만드는 메서드
	 */
	public boolean getExcelSummary(HashMap<String,SummaryVO> summaryHash){
		Workbook xlsxWb = new HSSFWorkbook();
		 
        // *** Sheet-------------------------------------------------
        // Sheet 생성
        Sheet sheet1 = xlsxWb.createSheet("firstSheet"); 
        // 컬럼 너비 설정
        
        for(int i=0; i<=summaryHash.size();i++){
        	sheet1.setColumnWidth(i, 6666);
        }
        
        // ----------------------------------------------------------
         
        // *** Style--------------------------------------------------
        // Cell 스타일 생성
        CellStyle cellStyle = xlsxWb.createCellStyle();
        
        
        cellStyle.setBorderBottom(CellStyle.BORDER_THIN); //테두리 두껍게 
        cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        cellStyle.setBorderRight(CellStyle.BORDER_THIN);
        cellStyle.setBorderTop(CellStyle.BORDER_THIN);

        // 줄 바꿈
        cellStyle.setWrapText(true);
        cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        

        // Cell 색깔, 무늬 채우기
         
        Row row = null;
        Cell cell = null;
        //----------------------------------------------------------
         
        
		String name ="";
		String summary ="";
		Object[] s = summaryHash.values().toArray();	
		
		SummaryVO[] sVO = new SummaryVO[s.length];
		for(int i=0; i<sVO.length;i++){
			sVO[i] = (SummaryVO)s[i];
		}		
        // 첫 번째 줄
        row = sheet1.createRow(0);
        cell = row.createCell(0);
        cell.setCellValue("\n회원\n이름\n");
        cell.setCellStyle(cellStyle);        
        
        // 첫 번째 줄에 Cell 설정하기-------------
        for(int i=1; i<summaryHash.size()+1;i++){
        	name = sVO[i-1].getCostomerName();
        	cell = row.createCell(i);    // 첫번째쭐 i 번째에
        	cell.setCellValue(name+"\n\n");	//이름쓰기
        	cell.setCellStyle(cellStyle); // 셀 스타일 적용
        }

        //---------------------------------
         
        // 두 번째 줄
        row = sheet1.createRow(1);         
        cell = row.createCell(0);		//2번째줄0번째에
        cell.setCellValue("\n영수증\n목록\n");
        cell.setCellStyle(cellStyle);
        // 두 번째 줄에 Cell 설정하기-------------
        for(int i=1; i<summaryHash.size()+1;i++){
        	cell = row.createCell(i);		//2번째줄i번째에
        	cell.setCellValue(sVO[i-1].getSummary());		//영수증쓰기
        	cell.setCellStyle(cellStyle); // 셀 스타일 적용        	
        }
        //---------------------------------
 
        // excel 파일 저장
        try {
            File xlsxFile = new File("D:/Summary"+formatDate.format(now)+".xls");
            FileOutputStream fileOut = new FileOutputStream(xlsxFile);
            xlsxWb.write(fileOut);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
	
	

}
