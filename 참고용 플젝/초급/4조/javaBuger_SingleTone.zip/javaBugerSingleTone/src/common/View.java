package common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import member.memberDAO.MemberDAO;
import member.memberService.MemberInterFace;
import member.memberService.MemberService;
import member.memberVO.MemberVO;
import product.productService.ProductInterFace;
import product.productService.ProductService;
import product.productVO.CondimentVO;
import product.productVO.JuiceVO;
import product.productVO.SideVO;
import product.productVO.SummaryVO;



public class View {
	private static MemberInterFace mService = MemberService.getInstance();
	private static ProductInterFace pService = ProductService.getInstance();
	
	
	RegClass rc = new RegClass(); 
	Scanner sc = new Scanner(System.in);
	SummaryVO orderSummary = new SummaryVO();
	Util u = new Util();
	int totalPrice = 0;
	int noneMemberCnt = 1;

	
	
	int condiIndex = 6;
	int juiceIndex = 4;
	int sideIndex = 6;
	/**
	 * 메인 시작 시작 View
	 */
	void mainMenu(){

		while(true){
			orderSummary.setSummaryN();
			totalPrice = 0;
			int menuNum = 0;
			System.out.println("\n\t✿✿Java Burger✿✿✿");
			System.out.println("\t╰( ͡° ͜ʖ ͡° )つ──☆*:・ﾟ ");
			System.out.println("\t┌┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┐");
			System.out.println("\t│1.메뉴 선택\t	│");
			System.out.println("\t│2.관리자 로그인\t│");
			System.out.println("\t│3.시스템 종료\t	│");
			System.out.println("\t└┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┘");
			System.out.println("\t원하는 항목을  입력 하세요 : ");

			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~3)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch (menuNum) {
			case 1:
				// 메뉴선택 메서드
				customerMenu();
				break;
			case 2:
				masterCheck();
				break;
			case 3:
				System.out.println("\t┌───────────────────────┐");
				System.out.println("\t│\t(ʘ言ʘ╬)		│");
				System.out.println("\t│\tJava Burger	│");
				System.out.println("\t│시스템을 종료합니다.	│");
				System.out.println("\t└───────────────────────┘");
				System.exit(0);
				break;

			default:
				System.out.println("※ 숫자(1~3)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
			}
		}
	}



	//////////////////////////////////////////관리자View 시작//////////////////////////////
	/**
	 * 관리자 메뉴 View
	 */

	public void masterMenu(){
		while(true){	
			System.out.println("\n\t  ✿관리자 메뉴✿");
			System.out.println("\t┌──────────────────┐");
			System.out.println("\t│  1.매출 관리     │");
			System.out.println("\t│  2.재고 관리     │");
			System.out.println("\t│  3.회원 관리     │");			
			System.out.println("\t│  4.뒤로 가기     │");			
			System.out.println("\t└──────────────────┘");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				masterMenuTotalSalesManageMent();
				break;
			case 2:
				masterMenuStockManagement();
				break;
			case 3:
				masterMenuMemberManagement();
				break;
			case 4:
				return;
			default:
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}

	/**
	 * 관리자메뉴에서 매출관리 들어왔을때 View
	 */
	public void masterMenuTotalSalesManageMent(){
		while(true){	
			System.out.println("\t✿매출 관리✿");
			System.out.println("╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊");
			System.out.println("\t1.전체 매출 검색		");
			System.out.println("\t2.재고별 누적 판매량	");
			System.out.println("\t3.전체 영수증 출력	");
			System.out.println("\t4.회원 영수증 출력	");
			System.out.println("\t5.가게 정보			");
			System.out.println("\t6.전체 영수증 Excel파일 받기 ");
			System.out.println("\t7.뒤로 가기");			
			System.out.println("╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~7)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				System.out.println("순이익  :" + pService.getMoney());
				break;
			case 2:
				getRecordAll();
				break;
			case 3:
				summaryAll();
				break;
			case 4:
				summary();
				break;
			case 5:
				javaBuger();
				break;
			case 6:
				u.getExcelSummary(mService.getSummaryHash());
				System.out.println("( ͡~ ͜ʖ ͡°)──────────success────────── ( ͡~ ͜ʖ ͡°)");
				System.out.println("Summary(현재시간).xls D드라이브에 저장 완료.");
				break;
			case 7:
				return;
			default:
				System.out.println("※ 숫자(1~7)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}


	//////////////////////영수증 메서드///////////////////
	public void summaryAll(){
		while(true){
			if(pService.summaryEmptyCheck()){
				System.out.println("※영수증이 하나도 없습니다.※");
				break;
			}
			System.out.println(pService.getSummaryAll());
			break;
		}
	}

	public void summary(){
		while(true){
			if(pService.summaryEmptyCheck()){
				System.out.println("※영수증이 하나도 없습니다.※");
				break;
			}
			System.out.println("─────────회원 영수증 찾기─────────────");
			System.out.println("고객님의 이름을 입력해주세요.");
			System.out.println("비회원일경우 '비회원'이라 써라");
			String key = "";
			key = sc.nextLine();
			if(pService.summaryKeyCheck(key)){
				System.out.println("=============="+key+" 님의 영수증 정보 ==================");
				System.out.println(pService.getSummary(key));
				return;
			}
			else if(pService.summaryKeyCheck("비회원")){
					System.out.println("=============="+key+" 영수증 정보 ==================");
					System.out.println(pService.getSummary(key));
					return;
			}else{
				System.out.println("( ͡~ ͜ʖ ͡°)───────FAIL─────── ( ͡~ ͜ʖ ͡°)");
				System.out.println("<"+key + "> 영수증 정보가 없습니다.");
				break;
			}
		}

	}
	///////////////////////////영수증메서드//////////////////

	/**
	 * 관리자 메뉴에서 재고관리 메뉴로 넘어왔을때 View
	 */
	public void masterMenuStockManagement(){
		while(true){	
			System.out.println("\n\t✿재고 관리✿");
			System.out.println("=============================");
			System.out.println("\t1.전체 재고 검색");
			System.out.println("\t2.재고 추가 ");	
			System.out.println("\t3.재고 삭제 ");	
			System.out.println("\t4.재고 수정 ");	
			System.out.println("\t5.뒤로 가기");			
			System.out.println("==============================");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~5)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				stockInfoAll();
				break;
			case 2:
				masterMenuStockManagementStockAdd();
				break;
			case 3:
				masterMenuStockManagementStockDel();
				break;
			case 4:
				masterMenuStockManagementStockUpdate();
				break;
			case 5:
				return;
			default:
				System.out.println("※ 숫자(1~5)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}

	/**
	 * 관리자메뉴=> 재고관리=> 재고추가 들어왔을때 View
	 */

	public void masterMenuStockManagementStockAdd(){
		while(true){	
			System.out.println("\n\t✿재고추가✿");
			System.out.println("=============================");
			System.out.println("\t1.컨디먼트 추가");
			System.out.println("\t2.음료 추가");
			System.out.println("\t3.사이드 메뉴 추가");	
			System.out.println("\t4.뒤로 가기");			
			System.out.println("==============================");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				stockAddCondi();
				break;
			case 2:
				stockAddJuice();
				break;
			case 3:
				stockAddSide();
				break;
			case 4:
				return;
			default:
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}

	/**
	 * 관리자메뉴==> 재고관리==> 재고삭제로왔을때 View
	 */
	public void masterMenuStockManagementStockDel(){
		while(true){	
			System.out.println("\n\t✿재고삭제✿");
			System.out.println("=============================");
			System.out.println("\t1.컨디먼트 삭제");
			System.out.println("\t2.음료 삭제");	
			System.out.println("\t3.사이드 메뉴 삭제");
			System.out.println("\t4.뒤로 가기");			
			System.out.println("==============================");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				stockCondiDel();
				break;
			case 2:
				stockJuiceDel();
				break;
			case 3:
				stockSideDel();
				break;
			case 4:
				return;
			default:
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}

	/**
	 * 관리자메뉴==> 재고관리==> 재고수정으로왔을때 View
	 */
	public void masterMenuStockManagementStockUpdate(){
		while(true){	
			System.out.println("\n\t✿재고추가✿");
			System.out.println("=============================");
			System.out.println("\t1.컨디먼트 수정");
			System.out.println("\t2.음료 수정");
			System.out.println("\t3.사이드 메뉴 수정");	
			System.out.println("\t4.뒤로 가기");			
			System.out.println("==============================");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				stockCondiUpdate();
				break;
			case 2:
				stockJuiceUpdate();
				break;
			case 3:
				stockSideUpdate();
				break;
			case 4:
				return;
			default:
				System.out.println("※ 숫자(1~4)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}
	/**
	 * 관리자 메뉴==> 회원관리 메뉴로 넘어왔을때 View
	 */
	public void masterMenuMemberManagement(){
		while(true){	
			System.out.println("\n\t✿회원 관리✿");
			System.out.println("╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊");
			System.out.println("\t1.회원 정보 조회");//완료
			System.out.println("\t2.회원 정보 수정");
			System.out.println("\t3.회원 정보 삭제");	
			System.out.println("\t4.회원 전체 정보 조회");	
			System.out.println("\t5.뒤로 가기");			
			System.out.println("╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~5)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				memberInfoSearch();
				break;
			case 2:
				memberInfoUpdate();
				break;
			case 3:
				memberInfoRemove();
				break;
			case 4:
				memberInfoAll();
				break;
			case 5:
				return;
			default:
				System.out.println("※ 숫자(1~5)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}

	////////////////////////////////////////////관리자View끝////////////////////////////////////////






	////////////////////////////////////////////관리자Method시작//////////////////////////////////

	/**
	 * 관리자 확인 메서드
	 */
	public void masterCheck(){
		String chk="";
		for(int i=0; i<3;i++){
			System.out.println("MasterKey를 입력해주세요.");
			try {
				Scanner sc = new Scanner(System.in);
				chk=sc.nextLine();					
			} catch (Exception e) {
				System.out.println("\t┌─────────────────────────┐");
				System.out.println("\t│올바른 입력값이 아닙니다.│");
				System.out.println("\t└─────────────────────────┘");
				continue;
			}
			if(mService.masterCheck(chk)){
				System.out.println("관리자 로그인에 성공하셨습니다.");
				masterMenu();
				break;
			}else{
				if(i==2){
					System.out.println("관리자가 아닙니다. 시스템을 종료합니다.");
					System.exit(0);
				}
				System.out.println("관리자 로그인에 실패하셨습니다.");
				System.out.println(3-1-i+"/3"+"회 남았습니다.");
			}
		}	
	}


	/**
	 * 회원 정보 검색 메서드
	 */
	public void memberInfoSearch(){
		System.out.println("검색하실 회원의 전화번호를 입력해주세요.");
		while(true){
			String memberTel = sc.nextLine();
			if (!rc.telRegCheck(memberTel)) {
				System.out.println("※ 휴대전화 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
				System.out.println("EX) 01012341234 ('-' 제외)");
				return;
			}

			if(mService.memberSearch(memberTel)){
				System.out.println("-=-=-=-=검색하신 회원 정보입니다.-=-=-=-=");
				System.out.println(mService.memberInfo(memberTel));
				return;
			}else{
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 회원정보가 없습니다( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				return;
			}
		}
	}

	/**
	 * 회원 정보 수정 메서드
	 */
	public void memberInfoUpdate(){
		String memberTel = "";
		String tel = "";
		String name = "";
		while(true){
			System.out.println("수정하실 회원의 전화번호를 입력해주세요.");
			memberTel=sc.nextLine();
			if(!mService.memberSearch(memberTel)){
				System.out.println("※ 회원 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
				return;
			}
			if(rc.telRegCheck(memberTel)){
				break;
			}
			System.out.println("※ 휴대전화 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
			System.out.println("EX) 01012341234 ('-' 제외)");
		}
		while(true){
			System.out.println("수정하실 이름을 입력해주세요.");
			name = sc.nextLine();
			if(rc.memberNameRegCheck(name)){
				break;
			}
			System.out.println("※ 이름 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
			System.out.println("EX) 한글 2~5글자");
		}
		while(true){
			System.out.println("수정하실 번호를 입력해주세요.");
			tel = sc.nextLine();
			if(rc.telRegCheck(tel)){
				MemberVO newMemberVO = new MemberVO(name, tel);
				mService.memberUpdate(memberTel,newMemberVO);
				System.out.println("회원정보 Update 완료");
				return;
			}
			System.out.println("※ 휴대전화 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
			System.out.println("EX) 01012341234 ('-' 제외)");
		}
	}

	/**
	 * 회원 정보 삭제 메서드
	 */
	public void memberInfoRemove(){
		System.out.println("삭제하실 회원의 전화번호를 입력해주세요.");
		while(true){
			String memberTel = sc.nextLine();
			if (!rc.telRegCheck(memberTel)) {
				System.out.println("※ 휴대전화 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
				System.out.println("EX) 01012341234 ('-' 제외)");
				return;
			}
			if(mService.memberSearch(memberTel)){
				mService.memberDel(memberTel);
				System.out.println("※ 삭제가 완료되었습니다. ( ͡~ ͜ʖ ͡°)");
				return;
			}else{
				System.out.println("※ 회원 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
			}
		}
	}

	/**
	 * 전체 회원정보 출력 메서드
	 */
	public void memberInfoAll(){
		System.out.println("===========회원 목록==============");
		System.out.println(mService.memberList());
	}
	///////////////////////////////////////관리자 Method 끝////////////////////////////////////	







	///////////////////////////////////재고 관리 Method 시작////////////////////////////////////

	/**
	 * 전체 상품 목록 출력 메서드
	 */
	public void stockInfoAll(){
		System.out.println("=================전체 재고목록=================");
		System.out.println("상품명\t\t가격\t\t재고");
		System.out.println(pService.menuList());		
	}



	/**
	 * 재고관리==> 재고추가==> 컨디먼트추가메서드
	 */
	public void stockAddCondi(){
		while(true){
			System.out.println("상품명을 입력해주세요.");
			String name=sc.nextLine();
			if(name.length()>7){
				System.out.println("상품명은 6글자 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}
			int price=0;
			System.out.println("가격을 입력해주세요.");
			try {
				price = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────1~20000의 정수만 입력 가능합니다.────");
				break;
			}
			if(price>20001){
				System.out.println("20000원 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}else if(price<0){
				System.out.println("음수는 안됩니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}
			int stock=0;

			System.out.println("재고량을 입력해주세요.");
			try {
				stock = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────1~299의 정수만 입력 가능합니다.────");
				break;
			}
			if(stock>300){
				System.out.println("300개이상 재고를 채울 수 없습니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}else if(stock<0){
				System.out.println("음수는 안됩니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}

			CondimentVO newCondi = new CondimentVO(name, price, stock,condiIndex);
			if(pService.condiSearch(name)){
				System.out.println("동일한 제품명이 존재합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}			
			pService.condiAdd(newCondi);
			condiIndex++;
			System.out.println("등록이 완료 되었습니다.");
			break;
		}
	}

	/**
	 * 재고관리==> 재고추가==> 쥬스추가메서드
	 */
	public void stockAddJuice(){
		while(true){
			System.out.println("상품명을 입력해주세요.");
			String name=sc.nextLine();
			if(name.length()>7){
				System.out.println("상품명은 6글자 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}
			int price=0;
			System.out.println("가격을 입력해주세요.");
			try {
				price = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────1~20000의 정수만 입력 가능합니다.────");
				break;
			}
			if(price>20001){
				System.out.println("20000원 이하만 가능합니다.");
				System.out.println("다시 시도해주세요");
				break;
			}else if(price<0){
				System.out.println("음수는 안됩니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}
			int stock=0;

			System.out.println("재고량을 입력해주세요.");
			try {
				stock = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────1~299의 정수만 입력 가능합니다.────");
				break;
			}
			if(stock>300){
				System.out.println("300개이상 재고를 채울 수 없습니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}else if(stock<0){
				System.out.println("음수는 안됩니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}

			JuiceVO newJuice = new JuiceVO(name, price, stock,juiceIndex);
			if(pService.juiceSearch(name)){
				System.out.println("동일한 제품명이 존재합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}			
			pService.juiceAdd(newJuice);
			System.out.println("등록이 완료 되었습니다.");
			break;
		}
	}


	/**
	 * 재고관리==> 재고추가==> 사이드메뉴 추가메서드
	 */
	public void stockAddSide(){
		while(true){
			System.out.println("상품명을 입력해주세요.");
			String name=sc.nextLine();
			if(name.length()>7){
				System.out.println("상품명은 6글자 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}
			int price=0;
			System.out.println("가격을 입력해주세요.");
			try {
				price = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────1~20000의 정수만 입력 가능합니다.────");
				break;
			}
			if(price>20001){
				System.out.println("20000원 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}else if(price<0){
				System.out.println("음수는 안됩니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}
			int stock=0;

			System.out.println("재고량을 입력해주세요.");
			try {
				stock = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────1~299의 정수만 입력 가능합니다.────");
				break;
			}
			if(stock>300){
				System.out.println("300개이상 재고를 채울 수 없습니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}else if(stock<0){
				System.out.println("음수는 안됩니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}

			SideVO newSide = new SideVO(name, price, stock,sideIndex);
			if(pService.sideSearch(name)){
				System.out.println("동일한 제품명이 존재합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				break;
			}			
			pService.sideAdd(newSide);
			System.out.println("등록이 완료 되었습니다.");
			break;
		}
	}


	/**
	 * 재고관리==> 재고삭제==> 컨디먼트 삭제 메서드
	 */
	public void stockCondiDel(){
		System.out.println("삭제할 상품명을 입력해주세요.");
		String condiName = sc.nextLine();
		if(pService.condiSearch(condiName)){
			pService.condiDel(condiName);
			System.out.println("※"+condiName +"의 삭제가 완료되었습니다. ( ͡~ ͜ʖ ͡°)");
		}else{
			System.out.println("※ 상품 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
		}
	}


	/**
	 * 재고관리==> 재고삭제==> 쥬스 삭제 메서드
	 */
	public void stockJuiceDel(){
		System.out.println("삭제할 상품명을 입력해주세요.");
		String juiceName = sc.nextLine();
		if(pService.juiceSearch(juiceName)){
			pService.juiceDel(juiceName);
			System.out.println("※"+juiceName +"의 삭제가 완료되었습니다. ( ͡~ ͜ʖ ͡°)");
		}else{
			System.out.println("※ 상품 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
		}
	}

	/**1
	 * 재고관리==> 재고삭제==> 사이드메뉴 삭제 메서드
	 */
	public void stockSideDel(){
		System.out.println("삭제할 상품명을 입력해주세요.");
		String sideName = sc.nextLine();
		if(pService.sideSearch(sideName)){
			pService.sideDel(sideName);
			System.out.println("※"+sideName +"의 삭제가 완료되었습니다. ( ͡~ ͜ʖ ͡°)");
		}else{
			System.out.println("※ 상품 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
		}
	}


	/**
	 * 재고관리==> 재고수정==> 컨디먼트 수정 메서드
	 */
	public void stockCondiUpdate(){
		System.out.println("수정할 상품명을 입력하세요.");
		String condiName = sc.nextLine();
		if(pService.condiSearch(condiName)){
			System.out.println("수정을 시작합니다.");
			System.out.println("상품명을 입력하세요.");
			String name = sc.nextLine();
			if(name.length()>6 ||name==null){
				System.out.println("상품명은 1~6글자만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				return;
			}
			System.out.println("가격을 입력하세요.");
			int price = 0;
			try {
				price = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("가격은 20000원 이하만 가능합니다.");
				return;
			}
			if(price<0){
				System.out.println("가격은 20000원 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				return;
			}
			System.out.println("재고량을 입력하세요.");
			int stock = 0;
			try {
				stock = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("재고량은 299개 이하만 가능합니다.");
				return;
			}
			if(stock>300){
				System.out.println("재고량은 299개 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				return;
			}
			CondimentVO newCondi = new CondimentVO(name,price,stock,condiIndex);
			pService.condiUpdate(condiName,newCondi);
		}else{
			System.out.println("※ 상품 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
		}
	}


	/**
	 * 재고관리==> 재고수정==> 쥬스 수정 메서드
	 */
	public void stockJuiceUpdate(){
		System.out.println("수정할 상품명을 입력하세요.");
		String juiceName = sc.nextLine();
		if(pService.juiceSearch(juiceName)){
			System.out.println("수정을 시작합니다.");
			System.out.println("상품명을 입력하세요.");
			if(juiceName.length()>6 ||juiceName==null){
				System.out.println("상품명은 1~6글자만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				return;
			}
			String name = sc.nextLine();
			System.out.println("가격을 입력하세요.");
			int price = 0;
			try {
				price = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("가격은 20000원 이하만 가능합니다.");
				return;
			}
			if(price<0 || price>20000){
				System.out.println("가격은 20000원 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				return;
			}
			System.out.println("재고량을 입력하세요.");
			int stock = 0;
			try {
				stock = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("재고량은 299개 이하만 가능합니다.");
				return;
			}
			if(stock>300 || stock<0){
				System.out.println("재고량은 299개 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
				return;
			}

			JuiceVO newJuice = new JuiceVO(name,price,stock,juiceIndex);
			pService.juiceUpdate(juiceName,newJuice);
		}else{
			System.out.println("※ 상품 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
		}
	}


	/**
	 * 재고관리==> 재고수정==> 사이드메뉴 수정 메서드
	 */
	public void stockSideUpdate(){
		System.out.println("수정할 상품명을 입력하세요.");
		String sideName = sc.nextLine();
		if(pService.sideSearch(sideName)){
			System.out.println("수정을 시작합니다.");
			System.out.println("상품명을 입력하세요.");
			String name = sc.nextLine();
			if(name.length()>7){
				System.out.println("상품명은 6글자 이하만 가능합니다.");
				return;
			}
			System.out.println("가격을 입력하세요.");
			int price = 0;
			try {
				price = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("가격은 20000원 이하만 가능합니다.");
				return;
			}
			if(price>20000 || price<0){
				System.out.println("가격은 20000원 이하만 가능합니다.");
				return;
			}
			System.out.println("재고량을 입력하세요.");
			int stock = 0;
			try {
				stock = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("재고량은 299개 이하만 가능합니다.");
				return;
			}
			if(stock>300 || stock<0){
				System.out.println("재고량은 299개 이하만 가능합니다.");
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("│( ͡~ ͜ʖ ͡°) 다시 시도해주세요. ( ͡~ ͜ʖ ͡°)│");
				System.out.println("└────────────────────────────────────┘");
			}
			SideVO newSide = new SideVO(name,price,stock,sideIndex);
			pService.sideUpdate(sideName,newSide);
		}else{
			System.out.println("※ 상품 정보가 존재하지 않습니다. ( ͡~ ͜ʖ ͡°)");
		}
	}

	/////////////////////////////////////재고 관리 메서드 끝//////////////////////////////////////









	////////////////////////////////메뉴 선택 메서드/////////////////////////////////////   
	/**
	 * 메뉴선택 => 버거주문 View
	 */
	public void customerMenu(){
		while(true){   
			System.out.println("\t✿버거 주문✿");
			System.out.println("───────────────────────────────────────────");
			System.out.println("\t1.주문 시작");
			System.out.println("\t2.뒤로 가기");         
			System.out.println("───────────────────────────────────────────");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~2)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
			switch(menuNum){
			case 1:
				order();
				customerMemberCheck();
				return;
			case 2:
				return;
			default:
				System.out.println("※ 숫자(1~2)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}

	/**
	 * 메뉴선택 => 버거주문 ==> 회원or비회원 확인 , 회원가입 View
	 * 1. 회원 => 정보확인 후 return
	 * 2. 비회원 => 바로 영수증출력 후 메인
	 * 3. 회원가입 => 회원가입하고 return;
	 */
	public void customerMemberCheck(){
		while(true){   
			System.out.println("\n\t✿회원 결제 / 비회원 결제 / 회원 가입✿");
			System.out.println("╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊");
			System.out.println("\t1.회원으로 결제");
			System.out.println("\t2.비회원으로 결제");         
			System.out.println("\t3.회원 가입");         
			System.out.println("╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊╊");
			System.out.println("기능을 선택해 주세요 : ");

			int menuNum = 0;
			try {
				menuNum = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("※ 숫자(1~3)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}

			switch(menuNum){
			case 1:
				customerMemberCheckMember();
				return;
			case 2:
				noneMemberEnd();
				return;
			case 3:
				memberJoin();
				break;
			default:
				System.out.println("※ 숫자(1~3)만 입력해주세요. ( ͡~ ͜ʖ ͡°)");
				continue;
			}
		}
	}


	/**
	 * 비회원일때 처리하는 메서드
	 */
	public void noneMemberEnd(){
		SummaryVO end = new SummaryVO();
		System.out.println("============비회원 전용 영수증=================");
		end.setCostomerName("비회원");
		end.setSummary(orderSummary.getSummary());
		end.setTotalPrice(totalPrice);
		Date now = new Date();
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyy년MM월dd일 kk:mm:ss");
		end.setSummary("구매시간 : " + formatDate.format(now));
		System.out.println(end.summaryToString());		
		System.out.println("비회원님 자바 버거를 이용해 주셔서 감사합니다.");
		pService.summaryAdd("비회원"+noneMemberCnt,end);
		noneMemberCnt++;
		pService.setPlusMoney(totalPrice);
		return;

	}



	/**
	 * 회원 정보 검색 메서드
	 */
	public void customerMemberCheckMember(){
		System.out.println("──────────────회원 확인──────────────");
		String memberTel="";
		while(true){
			while(true){
				memberTel = sc.nextLine();
				System.out.println("회원 확인을 위해 전화번호를 입력해주세요");
				if (rc.telRegCheck(memberTel)) {
					break;
				}else{
					System.out.println("※ 휴대전화 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
					System.out.println("EX) 01012341234 ('-' 제외)");					
				}
			}
			while(true){
				if(mService.memberSearch(memberTel)){
					System.out.println("┌────────────────────────────────────┐");
					System.out.println("  ( ͡~ ͜ʖ ͡°)  회원 인증 성공. ( ͡~ ͜ʖ ͡°)");
					System.out.println("└────────────────────────────────────┘");
		
					int usingPoint = pointUsingWhether(memberTel);
					SummaryVO end = new SummaryVO();
					System.out.println("============회원 전용 영수증=================");
					end.setCostomerName(mService.getMemberName(memberTel));
					end.setSummary(orderSummary.getSummary());
					end.setTotalPrice(totalPrice-usingPoint);
					end.setSummary("사용 포인트 : " + usingPoint+"P");
					end.setSummary("\n적립 후 포인트 : "+ (((mService.getMemberPoint(memberTel))-usingPoint)+totalPrice/10)+"P\n");
					Date now = new Date();
					SimpleDateFormat formatDate = new SimpleDateFormat("yyyy년MM월dd일 kk:mm:ss");
					end.setSummary("구매시간 : " + formatDate.format(now));
					System.out.println(end.summaryToString());
					mService.memberPointUpdate(memberTel, -usingPoint);
					System.out.println(mService.getMemberName(memberTel)+" 님 자바 버거를 이용해 주셔서 감사합니다.");
					mService.memberPointUpdate(memberTel, totalPrice/10);
					totalPrice -= usingPoint;
					pService.summaryAdd("<"+noneMemberCnt+">"+end.getCostomerName(),end);
					noneMemberCnt++;
					pService.setPlusMoney(totalPrice);
					return;
				}
				System.out.println("※ 회원 정보가 없습니다.다시 시도해주세요 ( ͡~ ͜ʖ ͡°)");
				System.out.println("회원 확인을 위해 전화번호를 입력해주세요");
				break;
			}
		}
			
	}
	

	/**
	 * 회원가입메서드
	 */

	//정규식 입니다.
	public void memberJoin(){
		System.out.println("============회원 가입=================");
		System.out.println("가입할 전화번호를 입력하세요.");
		String memberTel ="";
		String memberName ="";
		while(true){
			memberTel = sc.next();
			if(rc.telRegCheck(memberTel)){
				break;
			}else{
				System.out.println("※ 휴대전화 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
				System.out.println("EX) 01012341234 ('-' 제외)");
			}
			
		}
		if(mService.memberSearch(memberTel)){
			System.out.println("※ 이미 존재하는 번호입니다. ( ͡~ ͜ʖ ͡°)");
			return;
		}
		
		while(true){
			
			System.out.println("가입할 이름을 입력하세요");
			memberName = sc.nextLine();
			if(rc.memberNameRegCheck(memberName)){
				MemberVO mVO = new MemberVO(memberName, memberTel);
				mService.memberAdd(mVO);
				System.out.println("┌────────────────────────────────────┐");
				System.out.println("	( ͡~ ͜ʖ ͡°) 회원가입 성공!( ͡~ ͜ʖ ͡°)");
				System.out.println("└────────────────────────────────────┘");
				return;
			}
			System.out.println("※ 이름 양식에 맞춰주세요. ( ͡~ ͜ʖ ͡°)");
			System.out.println("EX) 한글 2~5글자");
		}
		
	}

	/**
	 * 포인트 사용 여부 메서드
	 */
	public int pointUsingWhether(String memberTel){
		while(true){
			System.out.println("포인트를 사용 하시겠습니까?   Y / N");
			int usingPoint = 0;
			String check = sc.nextLine();
			if(check.length()>5){
				System.out.println("※  'y' 또는 'n'을 입력해주세요( ͡~ ͜ʖ ͡°)");
			}else if(check.equals("y")||check.equals("Y")){
				System.out.println("현재 고객님의 포인트는 :"+mService.getMemberPoint(memberTel)+"P 입니다.");
				if(!mService.memberUsingPointCheck(memberTel, 1)){
					System.out.println("※ 포인트가 0P 입니다. 그냥 계산합니다.( ͡~ ͜ʖ ͡°)");
					return 0;
				}
				System.out.println("포인트를 얼마만큼 사용하시겠습니까?");
				try {
					usingPoint = Integer.parseInt(sc.nextLine());
					if(usingPoint<0){
						System.out.println("※ 올바른 정수의 포인트 값을 입력해주세요.( ͡~ ͜ʖ ͡°)");
						continue;						
					}else if(usingPoint==0){
						System.out.println("※ 0포인트를 사용하셨습니다.( ͡~ ͜ʖ ͡°)");
						return 0;
					}
				} catch (Exception e) {
					System.out.println("※ 올바른 정수의 포인트 값을 입력해주세요.( ͡~ ͜ʖ ͡°)");
					continue;
				}
				if(mService.memberUsingPointCheck(memberTel,usingPoint)){
					System.out.println("포인트를 " + usingPoint + "P 만큼 사용하셨습니다.");
					System.out.println("현재 고객님의 포인트는 :"+(mService.getMemberPoint(memberTel)-usingPoint)+" 입니다.");
					return usingPoint;
				}else{
					System.out.println("※ 회원님의 포인트가 부족합니다.( ͡~ ͜ʖ ͡°)");
				}
			}else if(check.equals("n")||check.equals("N")){
				System.out.println("※ 포인트를 사용하지 않으셨습니다.( ͡~ ͜ʖ ͡°)");
				break;
			}else{
				System.out.println("※  'y' 또는 'n'을 입력해주세요( ͡~ ͜ʖ ͡°)");
			}
		}
		return 0;
	}






	/**
	 * 주문하는 메서드
	 */

	public void order(){
		pService.basicBread();
		System.out.println("───────────────────────────────────────────");
		System.out.println("\t메뉴 선택을 시작합니다.");
		System.out.println("\t빵은 기본 1000원 입니다.");
		System.out.println("───────────────────────────────────────────");
		System.out.println("───────────────────Condiment List────────────────────");
		System.out.println("상품번호\t상품명\t\t가격\t\t재고");
		System.out.println("───────────────────Condiment List────────────────────");
		SummaryVO summary = new SummaryVO();
		summary.setSummary("기본빵" + "\t"+1+" 개 \t" + (1000)+" 원\n");
		totalPrice += 1000;

		while(true){
			System.out.println(pService.condiView());
			if(!yesOrNo1()){
				break;
			}
			String condiName = orderCondiSelect();
			int condiCount = orderCondiCount();
			int price = pService.getCondiPrice(condiName);			
			totalPrice += (price*condiCount);
			int oldStock = pService.getCondiStock(condiName);
			if(oldStock-condiCount<0){
				System.out.println("※  구매하려는 상품의 재고가 부족합니다.( ͡~ ͜ʖ ͡°)");
				System.out.println("※  다시 시도해주세요.( ͡~ ͜ʖ ͡°)");
				condiCount =0;
			}else if(oldStock-condiCount<10){
				System.out.println("※ 재고가 10개 미만입니다. 참고하세요.( ͡~ ͜ʖ ͡°)");
			}
			int condiIndex1 = pService.getCondiIndexToInt(condiName);
			CondimentVO cVO = new CondimentVO(condiName, price, oldStock-condiCount,condiIndex1);
			summary.setSummary(condiName + " \t"+condiCount+" 개 \t" + (price*condiCount)+" 원\n");
			pService.recordAdd(condiName,condiCount);
			pService.condiUpdate(condiName, cVO);
			if(!yesOrNo()){		//그만 사려고할때 while나옴		
				break;
			}
		}


		while(true){
			System.out.println("───────────────────Juice List────────────────────");
			System.out.println("상품번호\t상품명\t\t가격\t\t재고");
			System.out.println("───────────────────Juice List────────────────────");
			System.out.println(pService.juiceView());
			if(!yesOrNo1()){
				break;
			}
			String juiceName = orderJuiceSelect();		
			int juiceSize = orderjuiceCount();
			int price = pService.getJuicePrice(juiceName);
			String size="";
			if(juiceSize==1){
				size="M";
			}else{
				size="L";
				price=1000;
			}

			totalPrice += price;
			int oldStock = pService.getJuiceStock(juiceName);
			if(oldStock-juiceSize<0){
				System.out.println("※  구매하려는 상품의 재고가 부족합니다.( ͡~ ͜ʖ ͡°)");
				System.out.println("※  다시 시도해주세요.( ͡~ ͜ʖ ͡°)");
				juiceSize =0;
			}else if(oldStock-juiceSize<10){
				System.out.println("※ 재고가 10개 미만입니다. 참고하세요.( ͡~ ͜ʖ ͡°)");
			}
			pService.recordAdd(juiceName,juiceSize);
			int juiceIndex1 = pService.getJuiceIndexToInt(juiceName);
			JuiceVO jVO = new JuiceVO(juiceName, price, oldStock-juiceSize,juiceIndex1);
			summary.setSummary(juiceName+" \t"+"("+size+")"+" \t"+(price)+" 원\n");
			pService.juiceUpdate(juiceName, jVO);
			if(!yesOrNo()){
				break;
			}
		}
		while(true){
			while(true){
				System.out.println("───────────────────SideMenu List────────────────────");
				System.out.println("상품번호\t상품명\t\t가격\t\t재고");
				System.out.println("───────────────────SideMenu List────────────────────");
				System.out.println(pService.sideView());
				if(!yesOrNo1()){
					break;
				}
				String sideName = orderSideSelect();
				int sideCount = orderSideCount();
				int price = pService.getSidePrice(sideName);			
				totalPrice += (price*sideCount);
				int oldStock = pService.getSideStock(sideName);
				if(oldStock-sideCount<0){
					System.out.println("※  구매하려는 상품의 재고가 부족합니다.( ͡~ ͜ʖ ͡°)");
					System.out.println("※  다시 시도해주세요.( ͡~ ͜ʖ ͡°)");
					break;
				}else if(oldStock-sideCount<10){
					System.out.println("※ 재고가 10개 미만입니다. 참고하세요.( ͡~ ͜ʖ ͡°)");
				}
				pService.recordAdd(sideName,sideCount);
				int sideIndex1 = pService.getSideIndexToInt(sideName);
				SideVO cVO = new SideVO(sideName, price, oldStock-sideCount,sideIndex1);
				summary.setSummary(sideName + " \t"+sideCount+" 개\t" + (price*sideCount)+" 원\n");
				pService.sideUpdate(sideName, cVO);
				break;
			}
			if(!yesOrNo()){		//그만 사려고할때 while나옴		
				break;
			}
		}

		System.out.println("───────────────버거제작 완료────────────────");
		summary.setTotalPrice(totalPrice);
		System.out.println(summary.checkToString());	
		this.orderSummary.setSummary(summary.getSummary());
		return;
	}  //order() 끝






	////////////////////////////////orderSelect or count 컨디먼트 ///////////////////////////////////////////

	/**
	 * 컨디먼트 고르는 메서드
	 * @return 컨디먼트 이름
	 */

	public String orderCondiSelect(){
		while(true){	
			System.out.println("컨디먼트의 상품 번호를 입력해주세요.");
			int condiIndex = 0;
			condiIndex = Integer.parseInt(sc.nextLine());
			String condiName = pService.getCondiIndex(condiIndex);
			if(condiIndex<0 || condiIndex>1000){
				System.out.println("───상품번호를 정확히 입력해주세요 ───");
				continue;
			}else if(pService.condiSearch(condiName)){
				return condiName;
			}else{
				System.out.println("──────상품이 존재하지 않습니다.─────");
			}
		}

	}

	public int orderCondiCount(){
		while(true){
			System.out.println("몇개 구매 하시겠습니까?(최대2개)");
			int condiCount = 0;
			try {
				condiCount = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────────개수를 정확히 입력해주세요────────");
				continue;
			}
			if(condiCount>2){
				System.out.println("────최대 2개까지 구입 가능합니다.───");
				continue;
			}else if(condiCount<1){
				System.out.println("────최소 1개부터 구입 가능합니다.───");
				continue;
			}
			return condiCount;
		}

	}


	////////////////////////////////orderSelect or count 컨디먼트 끝///////////////////////////////////////////




	////////////////////////////////orderSelect or count 쥬스 시작 ///////////////////////////////////////////
	/**
	 * 쥬스 고르는 메서드
	 * @return 쥬스 이름
	 */
	public String orderJuiceSelect(){
		while(true){	
			System.out.println("쥬스의 상품 번호를 입력해주세요.");
			int juiceIndex = 0;
			try {
				juiceIndex = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("───상품의 번호를 정확히 입력해주세요. ───");
				continue;
			}
			String juiceName = pService.getJuiceIndexToName(juiceIndex);
			if(juiceIndex<0 || juiceIndex>1000){
				System.out.println("───상품의 번호를 정확히 입력해주세요. ───");
			}else if(pService.juiceSearch(juiceName)){
				return juiceName;
			}else{
				System.out.println("──────상품이 존재하지 않습니다.─────");
			}
		}

	}

	public int orderjuiceCount(){
		while(true){
			System.out.println("사이즈를 입력해주세요.(m,M or l,L)");
			String size = sc.nextLine();
			if(size.equals("m")|| size.equals("M")){
				return 1;
			}else if (size.equals("l")||size.equals("L")){
				return 2;
			}else{
				System.out.println("────────M / L 만 입력해주세요.──────");
			}
		}
	}



	////////////////////////////////orderSelect or count 쥬스 끝 ///////////////////////////////////////////



	//////////////////////////////////orderSelect or Count 사이드메뉴 시작/////////////////////////////////////
	/**
	 * 사이드메뉴 고르는 메서드
	 * @return 사이드메뉴이름
	 */
	public String orderSideSelect(){
		while(true){	
			System.out.println("사이드 메뉴를 골라주세요.");
			int sideIndex = 0;
			sideIndex = Integer.parseInt(sc.nextLine());
			String sideName = pService.getSideIndexToName(sideIndex);
			if(sideIndex<0 || sideIndex>1000){
				System.out.println("───개수를 정확히 입력해주세요 ───");
			}else if(pService.sideSearch(sideName)){
				return sideName;
			}else{
				System.out.println("──────상품이 존재하지 않습니다.─────");
			}
		}
	}

	/**
	 * 사이드메뉴의 구매갯수를 리턴받는 메서드
	 * @return  사이드메뉴의 구매개수
	 */
	public int orderSideCount(){
		while(true){
			System.out.println("몇개 구매 하시겠습니까?");
			int sideCount = 0;
			try {
				sideCount = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("─────────개수를 정확히 입력해주세요────────");
				continue;
			}
			if(sideCount>30){
				System.out.println("────최대 30개까지 구입 가능합니다.───");
				continue;
			}else if(sideCount<1){
				System.out.println("────최소 1개부터 구입 가능합니다.───");
				continue;
			}
			return sideCount;
		}

	}	

	/**
	 * 번외 가게정보
	 */

	public void javaBuger(){
		System.out.println("───────────자바버거 가게정보────────────\n");
		System.out.println("오픈날짜 :\t2017년 9월 4일\n");
		System.out.println("초기자금 : \t1,000,000원 (금일백만원)\n");
		System.out.println("손익분기점 : \t1,000,010원 (금일백만원)\n");
		System.out.println("창업자 : \t문정길 / 오혁준 / 김미진\n");
		System.out.println("체인 문의 :\t010 - 1234 -5678\n");
		System.out.println("Feat.(이영만 교수님)\n");
		System.out.println("─────────자바버거 가게정보 끝────────────\n");
	}






	/**
	 * 상품 별 누적 판매량 출력 메서드
	 */

	public void getRecordAll(){
		System.out.println("( ͡~ ͜ʖ ͡°)───────누적 판매량─────── ( ͡~ ͜ʖ ͡°)");
		System.out.println(pService.getRecordAll());
	}
	//////////////////////////////////orderSelect or Count 사이드메뉴 시작/////////////////////////////////////
	/**
	 * Y or N 메서드
	 */
	boolean yesOrNo1(){
		while(true){
			System.out.println("──Y / N────상품을 구매 하시겠습니까?─Y / N──");
			String answer ="";
			answer=sc.nextLine();
			if(answer.length()>5){
				System.out.println("───Y / N────Y / N 만 입력해주세요─Y  / N─────");
			}else if(answer.equals("y") || answer.equals("Y")){
				return true;
			}else if (answer.equals("n") || answer.equals("N")){
				return false;
			}else{
				System.out.println("───Y / N────Y / N 만 입력해주세요───Y / N───");
			}
		}
	}

	boolean yesOrNo(){
		while(true){
			System.out.println("──Y /  N───상품을 더 구매 하시겠습니까?──Y / N──");
			String answer ="";
			answer=sc.nextLine();
			if(answer.length()>5){
				System.out.println("────────Y / N 만 입력해주세요───────");
			}else if(answer.equals("y") || answer.equals("Y")){
				return true;
			}else if (answer.equals("n") || answer.equals("N")){
				return false;
			}else{
				System.out.println("───Y / N────Y / N 만 입력해주세요───Y / N───");
			}
		}
	}

}

