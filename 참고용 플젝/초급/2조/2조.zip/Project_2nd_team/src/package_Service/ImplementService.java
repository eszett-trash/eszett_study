package package_Service;

import java.util.List;
import java.util.Map;

import package_DataBase.DataBase;
import package_Vo.DesignerStatusVo;
import package_Vo.SalesListVo;
import package_Vo.DesignerVo;
import package_Vo.MemberVo;
import package_Vo.ReservationVo;
import package_Vo.StyleVo;

/**
 * interface에서 선언만 해놓은 메서드들을 여기에서 구현한다.
 * @author PC23
 *
 */
public class ImplementService implements InterfaceService{
	
	DataBase db = new DataBase();
	patternUtil pu = new patternUtil();

	@Override
	/**
	 * 멤버 전화번호 정규식 검사
	 */
	//문제 없을때 0, 중복일때 1, 정규식 만족못할때 2 , 예외 3 
	public int memberPhoneCheck(String memberPhone) {
		int flag = 0;										//별도로 사용할 플레그
		boolean result = db.memberPhoneCheck(memberPhone);	//폰 넘버를 가지고 db에가서. 중복값이 있는지 없는지 
															//true가 나오면 중복 / false가 오면 중복아님
		//폰번호 유효성 검사, 유효하면 true , 형식에 맞지 않으면 false 
		boolean numberValidation = pu.phoneNumberCheck(memberPhone);
		try {
			if(result==true){// 기존에 등록 되어진 번호일때
				flag = 1; //중복
			}else{
				if(numberValidation==false){ //폰번호 정규식 검사 결과가 문제있을때
					flag = 2;	//정규식 비적합
				}
			}
		} catch (Exception e) {
			flag = 3;	//예외
		}
		return flag;
	}


	@Override
	/**
	 * 멤버 네임
	 */
	public String memberName(String memberName) {
		return db.memberName(memberName);
	}

	@Override
	/**
	 * 비밀번호 정규식 검사
	 */
	// true이면 정규식 통과
	public boolean memberPasswordCheck(String memberPw) {
		return pu.memberPasswordCheck(memberPw);
	}


	@Override
	/**
	 * 회원 가입 메서드
	 */
	public boolean memberJoin(Map<String, String> join) {
		return db.memberJoin(join);
	}
		
	@Override
	/**
	 * 회원 보기(목록) 메서드
	 */
	public List<MemberVo> memberList() {
		return db.memberList();
	}


	@Override
	/**
	 * 로그인 메서드
	 */
	public int logIn(MemberVo mv) {
		return  db.logIn(mv);
		
	}





	@Override
	/**
	 * 회원정보 수정
	 */
	public int infoModify(Map<String, String> modify) {
		return db.infoModify(modify);
	}


	
	@Override
	/**
	 * 회원 삭제 - 관리자용
	 */
	public int deleteMember(MemberVo phoneCheck) {
		return db.deleteMember(phoneCheck);
	}


	@Override
	public MemberVo showInfo(String memberPhone) {
		
		return db.showInfo(memberPhone);
		
		
	}


	@Override
	public boolean phoneCheck(MemberVo phoneCheck) {
		return db.phoneCheck(phoneCheck);
	}


	@Override
	public int addStyle(StyleVo sv) {
		return db.addStyle(sv);
	}


	@Override
	public List<StyleVo> styleList() {
		return db.styleList();
	}


	@Override
	public int deleteStyle(String styleName) {
		return db.deleteStyle(styleName);
	}


	@Override
	public int hireDesigner(String designerName) {
		return db.hireDesigner(designerName);
	}


	@Override
	public int fireDesigner(String designerName) {
		return db.fireDesigner(designerName);
	}


	


	@Override
	public boolean designerNameCheck(String designerSel) {
		return db.designerNameCheck(designerSel);
	}


	@Override
	public StyleVo styleCheck(StyleVo vo) {
		return db.styleCheck(vo);
	}


	@Override
	public MemberVo getSession(MemberVo sessionVo) {
		return db.getSession(sessionVo);
	}


	@Override
	public boolean reserve(ReservationVo r) {
		return db.reserve(r);
	}


	@Override
	public List<ReservationVo> showReserve() {
		return db.showReserve();
	}

/*안써
	@Override
	public boolean reserveDateCheck(DesignerVo rDC) {
		return db.reserveDateCheck(rDC);
	}
*/





	@Override
	public boolean reserveCheck(String memberPhone) {
		return db.reserveCheck(memberPhone);
	}


	@Override
	public String preReserveCheck(String memberPhone) {
		return db.preReserveCheck(memberPhone);
	}


	@Override
	public String reserveCancel(String inputName, int inputIndex) {
		return db.reserveCancel(inputName, inputIndex);
	}


	@Override
	public ReservationVo payInfoVo(ReservationVo payInfoVo) {
		return db.payInfoVo(payInfoVo);
		
	}


	@Override
	public boolean salesListAdd(ReservationVo payInfoVo) {
		return db.salesListAdd(payInfoVo);
	}


	@Override
	public List<SalesListVo> getSalesList() {
		return db.getSalesList();
	}


	@Override
	public boolean salesList(String designerName) {
		return db.salesList(designerName);
	}


	@Override
	public String statusDesigner() {
		return db.getStatusDesigner();
	}


	@Override
	public boolean DesignerStatusUpdate(DesignerStatusVo dsVo) {
		return db.DesignerStatusUpdate(dsVo);
		
	}


	@Override
	public String ReserveDateCheck(String memberPhone) {
		return db.ReserveDateCheck(memberPhone);
	}


	@Override
	public boolean designerStatusInit(DesignerStatusVo designerStatusInit) {
		return db.designerStatusInit(designerStatusInit);
	}


	@Override
	public boolean fireNameIsTrue(String designerName) {
		return db.fireNameIsTrue(designerName);
	}


	@Override
	public boolean fireDesignerReserveCheck(String designerName) {
		return db.fireDesignerReserveCheck(designerName);
	}


	@Override
	public List<DesignerStatusVo> statusDesignerList() {
		return db.statusDesignerList();
	}


	@Override
	public List<DesignerVo> designerList() {
		return db.designerList();
	}


	@Override
	public List<ReservationVo> reservationList() {
		return db.reservationList();
	}


	@Override
	public String reserveCancelAdmin(int inputIndex) {
		return db.reserveCancelAdmin(inputIndex);
	}


	@Override
	public boolean reserveCancel(int index) {
		return db.reserveCancel(index);
	}


	@Override
	public boolean DesignerStatusUpdate(int index) {
		return db.DesignerStatusUpdate(index);
	}


	@Override
	public boolean memberNameCheck(String memberName) {
		return pu.memberNameCheck(memberName);
	}


	@Override
	public boolean memberAgeCheck(String memberAge) {
		return pu.memberAgeCheck(memberAge);
	}


	@Override
	public boolean memberGenderCheck(String memberGender) {
		return pu.memberGenderCheck(memberGender);
	}


	@Override
	public boolean dateCheck(String textDate) {
		return pu.dateCheck(textDate);
	}



	
}
