package package_Service;

import java.util.regex.Pattern;

public class patternUtil {

   /**
    * 폰번호 검사 정규식
    * @param PhoneNumber
    * @return
    */
   public boolean phoneNumberCheck(String PhoneNumber){
      return Pattern.matches("01[016789]-[0-9]{3,4}-[0-9]{4}", PhoneNumber);
 //     return Pattern.matches("[a-zA-Z0-9]{1,15}", PhoneNumber);
   }
   
   /**
    * 비밀번호 검사 정규식
    * @param memberPw
    * @return
    */
   public boolean memberPasswordCheck(String memberPw ){
//	"(^[a-zA-Z0-9]*([!@#$%^&*()])+([a-zA-Z0-9]|[!@#$%^&*()])+$)"  
	   return Pattern.matches("^[a-zA-Z0-9]*[!@#$%^&*()]+[a-zA-Z0-9]*[!@#$%^&*()]+[a-zA-Z0-9!@#$%^&*()]*$", memberPw);
 //     return Pattern.matches("[a-zA-Z0-9]{1,20}", memberPw);
   }
   
   /**
    * 이름 검사 정규식
    * @param memberPw
    * @return
    */
   public boolean memberNameCheck(String memberName) {
      return Pattern.matches("([가-힣]{2,6}|[a-zA-Z]{4,12})", memberName);
   }
   
   /**
    * 나이 검사 정규식
    * @param memberPw
    * @return
    */
   public boolean memberAgeCheck(String memberAge) {
      return Pattern.matches("[0-9]{1,2}", memberAge);
   }

   /**
    * 성별 검사 정규식
    * @param memberPw
    * @return
    */
   public boolean memberGenderCheck(String memberGender) {
      return Pattern.matches("[남|여]자", memberGender);
   }
   
   
//   /**
//    * Date 검사 정규식  \d 0~9   {2}
//    */
   public boolean dateCheck(String textDate){
//	   return Pattern.matches(" (19[7-9][0-9]|20\d{2})-(0[0-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])" , textDate);
	   return Pattern.matches("(19[7-9][0-9]|20[0-9][0-9])-(0[0-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])" , textDate);
   }
   
}