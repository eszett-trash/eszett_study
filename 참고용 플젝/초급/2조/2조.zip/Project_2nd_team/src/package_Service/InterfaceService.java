package package_Service;

import java.util.List;
import java.util.Map;

import package_Vo.DesignerStatusVo;
import package_Vo.SalesListVo;
import package_Vo.DesignerVo;
import package_Vo.MemberVo;
import package_Vo.ReservationVo;
import package_Vo.StyleVo;

/**
 * 각각의 Vo에서 선언한 놈들,, 필요한 메서드의 이름만 일단 지정해준다.
 * @author PC23
 *
 */
public interface InterfaceService{
	
	String memberName(String memberName);
	
	/**
	 * 폰번호 체크를 위한 메서드
	 * @param memberPhone
	 * @return
	 */
	int memberPhoneCheck(String memberPhone);
	/**
	 * 비밀번호 체크를 위한 메서드
	 * @param memberPw
	 * @return
	 */
	boolean memberPasswordCheck(String memberPw);
	
	/**
	 * 회원가입을 진행하기 위한 메서드 입니다.
	 * @param join
	 * @return
	 */
	boolean memberJoin(Map<String, String> join);
	
	List<MemberVo> memberList();
	
	/**
	 * 회원/관리자 공통 로그인 메서드
	 * @param logIn
	 * @return 관리자1, 회원정상2, 회원비번x3, 회원아이디x4, 예외-1
	 */
	int logIn(MemberVo tempVo);
	

	
	/**
	 * 회원 삭제 - 관리자용
	 * @param temp
	 * @return 삭제성공시 1반환, 실패시 0반환
	 */
	int deleteMember(MemberVo phoneCheck);
	
	
	/**
	 * 회원용 - 정보수정 메서드 (포인트 수정 못함)
	 * @param modify
	 * @return 성공하면 0, 실패하면 1 반환
	 */
	int infoModify(Map<String, String> modify);

	MemberVo showInfo(String memberPhone);

	boolean phoneCheck(MemberVo phoneCheck);

	/**
	 * 스타일 추가
	 * @param styleVo sv를 가지고 온다.
	 * @return 값중복시 1, 성공적인등록 2, 등록실패 3
	 */
	int addStyle(StyleVo sv);

	List<StyleVo> styleList();

	int deleteStyle(String styleName);

	/**
	 * 디자이너 고용
	 * @param designerName
	 * @return	기존에 있는 디자이너들과 이름이 중복이면 1 , 추가성공 2, 추가 실패 3
	 */
	int hireDesigner(String designerName);

	/**
	 * 디자이너 해고
	 * @param designerName
	 * @return	해고 실패 1, 해고 성공 2
	 */
	int fireDesigner(String designerName);

	

	/**
	 * 예약할 디자이너가 디자이너-리스트에 있는지 체크
	 * @param designerSel
	 * @return 있으면 true, 없으면 false
	 */
	boolean designerNameCheck(String designerSel);

	StyleVo styleCheck(StyleVo sv);

	/**
	 * session값을 얻기 위한 List
	 * @param sessionVo
	 * @return
	 */
	MemberVo getSession(MemberVo sessionVo);

	
	/**
	 * 예약하기
	 * @param 예악정보가 있는 Vo r을 가지고 온다.
	 * @return 성공 true / 실패 false 반환
	 */
	boolean reserve(ReservationVo r);


	/**
	 * 예약정보조회
	 * @return
	 */
	List<ReservationVo> showReserve();

	
	
	
	/**
	 * 회원의 예약/예약취소가 발생하면, 예약상태 가능/불가능, 예약일, 예약자 폰번호 정보를 디자이너 리트스에 갱신해준다.
	 * @param rDC
	 * @return
	 */
	/* 안써
	boolean reserveDateCheck(DesignerVo rDC);

	*/
	
	
	/**
	 * 예약정보조회_회원 : 진행시 예약된게 없는상태에서 조회를 시도하는지 체크하는 부분
	 * @param 현재 session의 memberPhone정보
	 * @return 예약정보 존재하면 true / 없으면 false
	 */
	boolean reserveCheck(String memberPhone);

	
	
	
	/**
	 * 예약확인용 : 예약조회 / 예약취소전에 해당 회원정보가 예약리스트에 있는지 체크하는 기능
	 * 회원/관리자 공통으로 사용할 수 있다.
	 * @param memberPhone
	 * @return
	 */
	String preReserveCheck(String memberPhone);

	
	
	
	
	/**
	 * 개인회원-예약삭제용
	 * @param String inputName, int inputIndex
	 * @return 삭제성공 designer이름 반환 / 삭제실패 null
	 */
	String reserveCancel(String inputName, int inputIndex);

	
	
	/**
	 * 회원의 결제 정보를 담을 Vo.
	 * @param payInfoVo에 폰번호를 담아 보내고
	 * @return payInfoVo에 모든 예약정보를 받아서 반환한다.
	 */
	ReservationVo payInfoVo(ReservationVo payInfoVo);

	/**
	 * 결제자 정보를 매출에 추가해주기 위한 메서드
	 * @param payInfoVo
	 * @return	성공 true / 실패 false
	 */
	boolean salesListAdd(ReservationVo payInfoVo);

	
	/**
	 * 일일매출정보 리스트를 받아온다
	 * @return salesList를 반환한다.
	 */
	List<SalesListVo> getSalesList();

	/**
	 * 매출에 출력을 원하는 디자이너가 존재하는지 안하는지.
	 * @param designerName
	 * @return 있으면 true / 없으면 false
	 */
	boolean salesList(String designerName);

	
	/**
	 * 2017. 09. 06
	 * 디자이너의 현재 상태(스케쥴) 표시
	 * @return 리스트가 비어있으면 null , 비어있지 않으면 to.String
	 */
	String statusDesigner();

	
	/**
	 * 예약자 정보를 vo로 담아와서, 디자이너 스케쥴표에 저장
	 * @param dsVo
	 */
	boolean DesignerStatusUpdate(DesignerStatusVo dsVo);

	/**
	 * 예약취소시, 예약자의 아이디(세션정보)를 이용해서, 기존에 예약한 날짜 값을 가질러 db에 가기위한 메서드
	 * @param memberPhone
	 * @return String형 날짜정보
	 */
	String ReserveDateCheck(String memberPhone);

	
	
	/**
	 * 개인회원용 디자이너 스케쥴 초기화 메서드
	 * 예약취소시에 스케쥴도 없애 주어야 하기 때문
	 * @param designerStatusInit
	 * @return
	 */
	boolean designerStatusInit(DesignerStatusVo designerStatusInit);

	
	
	/**
	 * 2017-09-08
	 * 해고하기전에 요청한 이름이 디자이너 리스트에 있는지 없는지 
	 * @param designerName
	 * @return 있으면 true / 없으면 false
	 */
	boolean fireNameIsTrue(String designerName);

	
	/**
	 * 2017-09-08
	 * 디자이너 해고전에, 예약목록은 없는지, 상태리스트에서 체크한다.
	 * @param designerName
	 * @return 예약 있으면 true , 없으면 false
	 */
	boolean fireDesignerReserveCheck(String designerName);

	
	
	/**
	 * DB에서 statusDesignerList 받아온다.
	 * @return
	 */
	List<DesignerStatusVo> statusDesignerList();

	
	
	
	/**
	 * DB에서 designerList 받아온다.
	 * @return
	 */
	List<DesignerVo> designerList();

	
	
	/**
	 * DB에서 reservationList 받아온다.
	 * @return
	 */
	List<ReservationVo> reservationList();

	
	/**
	 * 관리자-예약삭제용
	 * @param int inputIndex
	 * @return 삭제성공 designer이름 반환 / 삭제실패 null
	 */
	String reserveCancelAdmin(int inputIndex);

	
	
	/**
	 * 결제 진행시에 결제한 해당 예약을,,  예약리스트에서 없애주는놈.
	 * @param index
	 * @return 성공하면 true, 실패하면 false
	 */
	boolean reserveCancel(int index);

	
	/**
	 * 예약리스트 인덱스번호 = 디자이너스케쥴 인덱스번호 이기때문에
	 * 삭제되는놈의 index를 이용해서, 양쪽 리스트의 값을 모두 삭제할 수 있다.
	 * @param index
	 * @return 성공 true / 실패 false
	 */
	boolean DesignerStatusUpdate(int index);

	boolean memberNameCheck(String memberName);

	boolean memberAgeCheck(String memberAge);

	boolean memberGenderCheck(String memberGender);

	boolean dateCheck(String textDate);
	


	





}
