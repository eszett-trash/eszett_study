package main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import package_Service.ImplementService;
import package_Service.InterfaceService;
import package_Vo.DesignerStatusVo;
import package_Vo.SalesListVo;
import package_Vo.DesignerVo;
import package_Vo.MemberVo;
import package_Vo.ReservationVo;
import package_Vo.StyleVo;


/**
 * 
 * 스타일 삭제시,,예약된 내역에 삭제할 스타일이 있으면,,막아줘야함
 * 
 * 
 * 
 * 
 * 		 09. 05 -	회원모드 : 회원가입, 회원정보수정, 회원탈퇴 / 관리자모드 : 회원삭제 구현 	
 * 		 09. 05	-	DB 설계 어려워서 Vo -> interface -> Impl 순으로 설계 시작	
 * 2017. 09. 04	-	프로젝트 시작
 * @author HoYa
 */
public class View { // 클래스 시작

	InterfaceService is = new ImplementService();
	Scanner sc = new Scanner(System.in);
	MemberVo sessionVo = new MemberVo(); // 현재 로그인한 사람의 정보를 가진다. 세션ID로 쓰인다.

	/**
	 * 메인 메뉴 입니다.
	 */
	public void mainMenu() {	//메인에서 불러와야 해서,, 이놈만 public
		// Date date = new Date();
		// Date date1 = new Date();
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy년MM월dd일");
		// System.out.println(sdf.format(date));
		while (true) {
			System.out.println("┌─────────예 약 헤 어────────┐");
			System.out.println("│ 1. 로             그             인       ★ ");
			System.out.println("│ 2. 회        원        가        입     ˝");
			System.out.println("└────────────────────────┘");
			System.out.print("입력하세요 : ");
			int menuSel = 0;
			try {
				menuSel = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("잘못 입력 하였습니다.");
				continue;
			}
			switch (menuSel) {
			case 1:
				logIn();	//로그인 메서드
				break;
			case 2:
				memberJoin();	//회원가입 메서드
				break;
			default:
				System.out.println("잘못 입력 하였습니다.");
				continue;
			}
		}//while 종료
	}//main 메서드 종료

	
	/**
	 * 로그인 메뉴 입니다.
	 * @param alogin
	 * @return
	 */
	private void logIn() {
		System.out.println("──────────────────로그인★");
		while (true) {
			System.out.print("아이디를 입력하세요 : ");
			String memberPhone = null;
			try {
				memberPhone = sc.next().trim();
			} catch (Exception e) {
				System.out.println("잘못 입력 하였습니다.");
				continue;
			}
			System.out.print("비밀번호를 입력하세요 : ");
			String password = null;

			try {
				password = sc.next().trim();
			} catch (Exception e) {
				System.out.println("잘못 입력 하였습니다.");
				continue;
			}

			sessionVo.setMemberPhone(memberPhone); // 임시로 사용할 MemberVo
			sessionVo.setPassword(password); 

			int flag = is.logIn(sessionVo);
			if (flag == 1) {
				sessionVo.setMemberPhone("admin");
				sessionVo.setPassword("admin");
			}

			if (flag == -1) {
				System.out.println("오류가 발생했습니다.");
				break;
			} else if (flag == 1) {
				System.out.println("관리자님 환영합니다.");
				adminMenu();
				break;
			} else if (flag == 2) {
				System.out.println("회원님 환영합니다.");
				
				MemberVo tempVo = is.getSession(sessionVo); //1를 가지고 DB에 다녀온다. 
				/* sessionVo에 현재 로그인한 회원의 비밀번호를 제외한 모든 정보가 담긴다. 로그아웃 전까지 */
				sessionVo.setMemberAge(tempVo.getMemberAge());
				sessionVo.setMemberGender(tempVo.getMemberGender());
				sessionVo.setMemberName(tempVo.getMemberName());
				sessionVo.setMemberPhone(tempVo.getMemberPhone());
			//	sessionVo.setMemberPoint(tempVo.getMemberPoint());
				memberMenu();
				break;
			} else if (flag == 3) {
				System.out.println("비밀번호가 맞지 않습니다.");
				break;
			} else
				System.out.println("아이디가 맞지 않습니다.");
			break;

		}// while 종료
	}// logIn 메서드 종료

	/**
	 * 회원 메뉴 입니다.
	 */
	private void memberMenu() { // 회원 메뉴 시작
		while (true) {
			System.out.println("┌─────────회 원 메 뉴────────┐");
			System.out.println("│ 1. 예        약        하        기      ★");
			System.out.println("│ 2. 예        약        조        회      ˝");
			System.out.println("│ 3. 예        약        취        소      ˝");
			System.out.println("│ 4. 회        원        정        보    ˝");
			System.out.println("│ 0. 로        그        아        웃       ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");
			int menuSel = 0;
			System.out.print("입력하세요 : ");
			try {
				menuSel = Integer.parseInt(sc.next());
			} catch (Exception e) {
				 continue;
			}
			switch (menuSel) {
			case 1:
				reserve();
				break;
			case 2:
				reserveCheck();
				break;
			case 3:
				reserveCancel();
				break;
			case 4:
				customerMenu();
				break;
			case 0:
				logOut();
				return;
			default:
				System.out.println("잘못 입력 하였습니다.");
				continue;
			}
		}
	}// 회원 메뉴 끝

	/**
	 * 관리자 메뉴 입니다.
	 */
	private void adminMenu() { // 관리자 메뉴 시작
		while (true) {
			System.out.println("┌─────────관 리 자 메 뉴────────┐");
			System.out.println("│ 1. 디    자    이    너    ✂    관     리★");
			System.out.println("│ 2. 예        약        관        리      ˝");
			System.out.println("│ 3. 스     타     일      관     리     ˝");
			System.out.println("│ 4. 결        제        관        리       ˝");
			System.out.println("│ 5. 회        원        관        리      ˝");
			System.out.println("│ 0. 로        그        아        웃    ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");
			System.out.print("입력하세요 : ");
			int adminMenu = 0;
			try {
				adminMenu = Integer.parseInt(sc.next());
			} catch (Exception e) {
				continue;
			}
			switch (adminMenu) {
			case 1:
				manageDesigner();
				break;
			case 2:
				manageReservation();
				break;
			case 3:
				manageStyle();
				break;
			case 4:
				managePay();
				break;
			case 5:
				manageMember();
				break;
			case 0:
				logOut();
				return;
			default:
				System.out.println("잘못 입력 하였습니다.");
				continue;
			}
		}
	}// adminMenu 종료

	/**
	 * 예약하기 메뉴
	 */
	
	private void reserve() {
		ReservationVo r = new ReservationVo();		//예약자 정보를 저장할 Vo
		showDesigner(); //디자이너 리스트 출력
		while (true) { // 디자이너 리스트 먼저 보여주고 고르고,
			//스타일 보여주고 고르고, 날짜는 입력받도록
			statusDesigner();
			String designerSel = null;
			System.out.print("디자이너의 이름을 입력하세요 : ");
			try {
				designerSel = sc.next().trim();
			} catch (InputMismatchException e) {
				continue;
			}
			boolean designerNameCheck = is.designerNameCheck(designerSel);		//디자이너 이름 체크
			if(designerNameCheck){				
				r.setReserveName(sessionVo.getMemberName());			//예약자 이름 완료
				r.setReservePhone(sessionVo.getMemberPhone());			//예약자 폰번호 완료
				r.setReserveAge(sessionVo.getMemberAge());				//예약자 나이 완료
				r.setReserveGender(sessionVo.getMemberGender());		//예약자 성별 완료
				r.setReserveDesigner(designerSel);						//예약한 디자이너 완료
				System.out.println(designerSel +" 디자이너를 선택하였습니다.");
				System.out.println();
				break;
			}if(!designerNameCheck){
				System.out.println("잘못 입력 하였습니다.");
				return;
			}
		}
		while (true) {
			showStyle(); // 스타일의 리스트를 출력
			String styleSel = null;
			System.out.print("스타일을 입력하세요 : ");
			styleSel = sc.next().trim();
			int stylePrice = 0; // 요청한 스타일의 가격을 받아오기 위해 쓸 임시 변수
			StyleVo sv = new StyleVo();
			sv.setStyleName(styleSel);
			sv.setStylePrice(stylePrice);
			StyleVo temp = is.styleCheck(sv); // 스타일이 있는 상품인지 체크
			try {
				r.setReserveStyle(temp.getStyleName());		//예약한 스타일 완료
				r.setReservePrice(temp.getStylePrice());	//예약한 스타일의 가격 완료
				System.out.println("\n\n");
				System.out.println("선택한 스타일은 " + r.getReserveStyle() + "이며, 가격은 " + r.getReservePrice() + "원 입니다.");
				break;
			} catch (Exception e) {
				System.out.println("잘못 입력 하였습니다.");
			}
		}
		/* 날짜 소스 */
		while (true) {
			System.out.println("예약할 날짜를 입력하세요 : ");
			System.out.println("형식은 [2017-12-31] 입니다.");
			String textDate = null;
			try {
			    textDate = sc.next().trim();
			  while(true){
			    boolean regResult = is.dateCheck(textDate);
				    if(!regResult){
				    	System.out.println("형식에 맞게 입력하세요.");
				    	System.out.println("형식은 [2017-12-31] 입니다.");
				    	return;
				    }
				    break;
			  } 
				SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd");
				Date date = format.parse(textDate);
				java.text.SimpleDateFormat format1 = new java.text.SimpleDateFormat("yyyy년 MM월 dd일");
				String dateString = format1.format(date);
				System.out.println("\n\n");
				System.out.println("예약 날짜는 => " + dateString + " 입니다.");	
				r.setReserveDate(dateString);		//예약한 날짜 완료
				break;
			} catch (ParseException e)  {		
				System.out.println("형식에 맞게 입력하세요.");
			}
		}//날짜 while 끝
		
		if(is.reserve(r)){//R의 vo를 가지고 DB에 간다.
			DesignerStatusVo dsVo = new DesignerStatusVo();			//디자이너 리스트에 예약 불가능을 보여주기 위해
//			private String statusDesignerName;		dsVo의 값은 3개이다.
//			private String statusReserveDate;
//			private String statusReservePhone;
			dsVo.setStatusDesignerName(r.getReserveDesigner());		//예약된 디자이너 이름
			dsVo.setStatusReserveDate(r.getReserveDate());			//예약된 날짜
			dsVo.setStatusReservePhone(r.getReservePhone());		//예약자의 폰번호
			is.DesignerStatusUpdate(dsVo);
			System.out.println("예약이 정상적으로 완료되었습니다.");
		}else{
			System.out.println(sessionVo.getMemberName() + "회원님 하루에 같은 Style을 두번 이상 받을 수 없습니다.");
		}

	}// reserve 끝
	
	
	
	
	
	/**
	 * 2017. 09. 08 예약정보가 없으면 출력 되지 않도록
	 * 2017. 09. 07
	 * 예약조회_관리자용
	 */
	private void showReserve(){
		List<ReservationVo> showReserve = is.showReserve();
		while(true){
			if(showReserve.size()==0){
				System.out.println("예약 정보가 없습니다.");
				return;
			}else{
				System.out.println("예약 번호\t" + "예약자 폰번호\t\t" + "예약자\t" + "나이\t" + "성별\t" + "디자이너\t" + "스타일\t" + "가격\t" + "예약날짜\t");
				for (int i = 0; i < showReserve.size(); i++) {
					System.out.println(showReserve.get(i));
				}
				break;
			}
		}
	}
	
	
		
	
	/**
	 * 예약조회_회원용
	 */
	private void reserveCheck(){
		String memberPhone = sessionVo.getMemberPhone();
		String preReserveCheck = is.preReserveCheck(memberPhone);
		if(preReserveCheck==null){
			System.out.println("예약하신 정보가 없네요.");
			return;
		}
		List<ReservationVo> showReserve = is.showReserve();//회원용은 index를 삭제했다.
		System.out.println("번호\t" + "예약자 번호\t\t" + "예약자\t" + "나이\t" + "성별\t" + "디자이너\t" + "스타일\t" + "가격\t" + "예약날짜\t");
		for (int i = 0; i < showReserve.size(); i++) {
			if(showReserve.get(i).getReservePhone().equals(sessionVo.getMemberPhone())){//session넘버와, 리스트의넘버가같을때
				System.out.println(
						
						showReserve.get(i).getReserveIndex() + "\t"
						+showReserve.get(i).getReservePhone() + "\t"
						+showReserve.get(i).getReserveName() + "\t"
						+showReserve.get(i).getReserveAge() + "\t"
						+showReserve.get(i).getReserveGender() + "\t"
						+showReserve.get(i).getReserveDesigner() + "\t"
						+showReserve.get(i).getReserveStyle() + "\t"
						+showReserve.get(i).getReservePrice() + "\t"
						+showReserve.get(i).getReserveDate());
				
			}
		}
	}


	
	
	/**
	 * 예약취소-회원
	 */
	private void reserveCancel(){ // reservation vo를 만들어서,, 거기에 기존에 예약한 디자이너 이름을 받아서 저장하고, 그 값들을 vo로 만들어서  새로운 designerList에 넣고, 그걸 add
		String memberPhone = sessionVo.getMemberPhone();
		String preReserveCheck = is.preReserveCheck(memberPhone);	//예약디자이너의 정보를 반환받는다.
		if(preReserveCheck==null){
			System.out.println("예약 정보가 없습니다.");
			return;
		}	
		reserveCheck();	//예약정보를 보여준다.
		System.out.println("현재 회원님의 예약 정보입니다.");
		while(true){
			int inputIndex = 0;
			String inputName = null;
			
			try {
				System.out.print("취소하고 싶은 예약 번호를 입력하세요 : ");
				inputIndex = Integer.parseInt(sc.next());
			} catch (NumberFormatException e) {
				System.out.println("잘못된 입력입니다.");
				continue;
			}
			
			System.out.print("이름을 입력하세요 : ");
			inputName = sc.next().trim();
			
			String ReserveDateCheck = is.ReserveDateCheck(memberPhone);	//예약된 날짜 정보를 얻어오기 위해 db로 출발
			String reserveCancel = is.reserveCancel(inputName, inputIndex);
			//삭제성공하면 designerName을 반환해주고, 실패하면 Null이다
			if(reserveCancel!=null){
				System.out.println("예약 취소 완료 !");
				//예악리스트를 삭제 했으면, 디자이너 상태 리스트도 초기화 해주러 가자.
				DesignerStatusVo designerStatusInit = new DesignerStatusVo();			//디자이너 리스트에 초기화를 해주기 위해
				designerStatusInit.setStatusDesignerName(reserveCancel);     			//예약된 디자이너 이름
				designerStatusInit.setStatusReserveDate(ReserveDateCheck);				//예약된 날짜
				designerStatusInit.setStatusReservePhone(memberPhone);
				
				boolean designerInit = is.designerStatusInit(designerStatusInit);
				if (designerInit) {
//					System.out.println("디자이너 리스트 초기화 성공");	//개발단계에서 필요한 정보
					break;
				}else{
//					System.out.println("디자이너 리스트 초기화 실패");
				}
			}
			if (reserveCancel==null) {
				System.out.println("예약 취소 실패 !");
				return;
			}
		}
	}
	
		
		
	
	
	
	/**
	 * 예약취소-관리자
	 */
	private void reserveCancelAdmin(){ // reservation vo를 만들어서,, 거기에 기존에 예약한 디자이너 이름을 받아서 저장하고, 
										//그 값들을 vo로 만들어서  새로운 designerList에 넣고, 그걸 add
		List<ReservationVo> showReserve = is.showReserve();
		while(true){
			if(showReserve.size()==0){
				System.out.println("예약 정보가 없습니다.");
				return;
			}else{
				System.out.println("예약 번호\t" + "예약자 폰번호\t\t" + "예약자\t" + "나이\t" + "성별\t" + "디자이너\t" + "스타일\t" + "가격\t" + "예약날짜\t");
				for (int i = 0; i < showReserve.size(); i++) {
					System.out.println(showReserve.get(i));
				}
				break;
			}
		}
		
		
			while(true){
				int inputIndex = 0;
				String inputPhone = null;
				try {
					System.out.print("예약 취소를 진행할 예약 번호를 입력하세요 : ");
					inputIndex = Integer.parseInt(sc.next());
				} catch (NumberFormatException e) {
					System.out.println("잘못된 입력입니다.");
					continue;
				}
				
				System.out.print("예약 취소를 진행할 회원의 폰번호를 입력하세요 : ");
				inputPhone = sc.next().trim();
				
				String ReserveDateCheck = is.ReserveDateCheck(inputPhone);	//예약된 날짜 정보를 얻어오기 위해 db로 출발
				String reserveCancel = is.reserveCancelAdmin(inputIndex);	//DB에서 예약정보를 삭제한 후 디자이너값을받아옴
				//삭제성공하면 designerName을 반환해주고, 실패하면 Null이다
				if(reserveCancel!=null){
					System.out.println("예약 취소 완료 !");
					//예악리스트를 삭제 했으면, 디자이너 상태 리스트도 초기화 해주러 가자.
					DesignerStatusVo designerStatusInit = new DesignerStatusVo();			//디자이너 리스트에 초기화를 해주기 위해
					designerStatusInit.setStatusDesignerName(reserveCancel);     			//예약된 디자이너 이름
					designerStatusInit.setStatusReserveDate(ReserveDateCheck);				//예약된 날짜
					designerStatusInit.setStatusReservePhone(inputPhone);					//예약한사람 폰번호
					
					boolean designerInit = is.designerStatusInit(designerStatusInit);
					if (designerInit) {
//						System.out.println("디자이너 리스트 초기화 성공");	//개발단계에서 필요한 정보
						break;
					}else{
//						System.out.println("디자이너 리스트 초기화 실패");
					}
				}
				if (reserveCancel==null) {
					System.out.println("예약 취소 실패 !");
					return;
				}
			}
		}
	
	
	

	/**
	 * 회원 메뉴
	 */
	private void customerMenu() { // 고객메뉴
		while (true) {
			System.out.println("┌─────────회 원 정 보────────┐");
			System.out.println("│ 1. 정       보       조       회       ★");
			System.out.println("│ 2. 정       보       수       정         ˝");
			System.out.println("│ 3. 회       원       탈       퇴        ˝");
			System.out.println("│ 4. 뒤       로       가       기       ˝");
			System.out.println("│ 0. 로       그       아       웃          ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");
			System.out.print("입력하세요 : ");
			int customerMenu = 0;
			try {
				customerMenu = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("올바르지 않는 입력 입니다.");
				continue;
			}
			switch (customerMenu) {
			case 1:
				infoCheck();
				break;
			case 2:
				infoModify();
				break;
			case 3:
				deleteMember();
				break;
			case 4:
				return;
			case 0:
				logOut();
				break;
			default:
				System.out.println("잘못 입력 하였습니다.");
				continue;
			}
		}// while끝
	}// customerMenu 끝

	/**
	 * 디자이너관리(관리자 메뉴)
	 */
	private void manageDesigner() { // 디자이너 관리
		while (true) {
			System.out.println("┌─────────디자이너 관리────────┐");
			System.out.println("│ 1. 디   자   이   너      조   회       ★");
			System.out.println("│ 2. 디   자   이   너     스  케  쥴     ˝");
			System.out.println("│ 3. 디   자   이   너      고   용      ˝");
			System.out.println("│ 4. 디   자   이   너      해   고        ˝");
			System.out.println("│ 5. 이        전        메        뉴         ˝");
			System.out.println("│ 0. 로        그        아        웃        ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");
			System.out.println("입력하세요 : ");
			int manageDesigner = 0;
			try {
				manageDesigner = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("올바르지 않는 입력 입니다.");
				continue;
			}
			switch (manageDesigner) {
			case 1:
				showDesigner();	 //디자이너 상태조회로 바꿔야ㅕ함
				break;
			case 2:
				statusDesignerAdmin();	//디자이너상태;
				break;
			case 3:
				hireDesigner();
				break;
			case 4:
				fireDesigner();
				break;
			case 5:
				return;
			case 0:
				logOut();
			default:
				System.out.println("다시 숫자를 입력해주세요.");
				continue;
			}
		}// while끝
	}// manageDesigner끝

	/**
	 * 관리자예약관리(관리자 메뉴)
	 */

	private void manageReservation() { // 관리자 예약관리
		while (true) {
			System.out.println("┌─────────예 약 관 리────────┐");
			System.out.println("│ 1. 예     약     자      현    황    ★");
			System.out.println("│ 2. 예        약        취        소     ˝");
			System.out.println("│ 3. 이        전        메        뉴       ˝");
			System.out.println("│ 0. 로        그        아        웃      ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");
			System.out.print("입력하세요 : ");
			int manageReservation = 0;
			try {
				manageReservation = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("올바르지 않는 입력 입니다.");
				continue;
			}
			switch (manageReservation) {
			case 1:
				showReserve();
				break;
			case 2:
				reserveCancelAdmin();
				break;
			case 3:
				return;
			case 0:
				logOut();
			default:
				System.out.println("다시 숫자를 입력해주세요.");
				continue;
			}
		}// while끝
	}// manageReservation끝

	/**
	 * 스타일 (관리자 메뉴)
	 */
	private void manageStyle() { // 관리자 예약관리
		while (true) {
			System.out.println("┌────────스 타 일 관 리───────┐");
			System.out.println("│ 1. 스   타   일        보   기       ★"); // 컷트,퍼머,염색 종류랑 가격 보여주기
			System.out.println("│ 2. 스   타   일        추   가      ˝");
			System.out.println("│ 3. 스   타   일        삭   제     ˝");
			System.out.println("│ 4. 이       전       메       뉴      ˝");
			System.out.println("│ 0. 로       그       아       웃       ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");

			int style = 0;
			try {
				style = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("올바르지 않는 입력 입니다.");
				continue;
			}
			switch (style) {
			 case 1:
				 showStyle();
				 break;
			 case 2:
				 addStyle();
				 break;
			case 3:
				deleteStyle();
				break;
			 case 4:
			return;
			case 0:
				logOut();
			default:
				System.out.println("다시 숫자를 입력해주세요.");
				continue;
			}
		}// while끝
	}// style끝

	/**
	 * 결제관리(관리 메뉴)
	 */
	private void managePay() { // 관리자 결제관리
		while (true) {
			System.out.println("┌─────────결 제 관 리────────┐");
			System.out.println("│ 1. 결        제        하        기   	 ★");
			System.out.println("│ 2. 매        출        내        역     ˝");
			System.out.println("│ 3. 디  자  이  너  별      매  출      ˝");
			System.out.println("│ 4. 이        전        메        뉴       ˝");
			System.out.println("│ 0. 로        그        아        웃      ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");
			int managePay = 0;
			try {
				managePay = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("올바르지 않는 입력 입니다.");
				continue;
			}
			switch (managePay) {
			case 1:
				payment();
				break;
			case 2:
				salesList();
				break;
			case 3:
				designerSalesList();
				break;
			case 4:
				return;
			case 0:
				logOut();
				break;
			default:
				System.out.println("다시 숫자를 입력해주세요.");
				continue;
			}
		}// while끝
	}// managePay끝

	/**
	 * 회원관리(관리 메뉴)
	 */
	private void manageMember() { // 관리자 회원관리
		while (true) {
			System.out.println("┌─────────회 원 관 리────────┐");
			System.out.println("│ 1. 회        원        보        기     ★");
			System.out.println("│ 2. 회        원        삭        제        ˝");
			System.out.println("│ 3. 이        전        메        뉴        ˝");
			System.out.println("│ 0. 로        그        아        웃    ˝");
			System.out.println("│ 로그인 정보 ☎ " + sessionVo.getMemberPhone() + "˝");
			System.out.println("└────────────────────────┘");

			int manageMember = 0;
			try {
				manageMember = Integer.parseInt(sc.next());
			} catch (Exception e) {
				System.out.println("올바르지 않는 입력 입니다.");
				continue;
			}
			switch (manageMember) {
			case 1:
				memberList();
				break;
			case 2:
				deleteMember();
				break;
			case 3:
				return;
			case 0:
				logOut();
			default:
				System.out.println("다시 숫자를 입력해주세요.");
				continue;
			}
		}// while끝
	}// manageMember끝

	/**
	 * 회원가입을 시도해보자 폰번호, 비밀번호, 이름, 나이, 성별 순서~
	 */
	private void memberJoin() {
		System.out.println("\n\n\n");
		System.out.println("회원 등록 페이지 ");

		/**
		 * 폰번호를 입력받습니다. 폰번호 = ID이므로 중복 확인을 합니다.
		 */
		String memberPhone = "";
		while (true) {
			System.out.println("폰번호는 010-123(4)-5678");
			System.out.print("폰번호를 입력하세요 : ");
			memberPhone = sc.next().trim();
			int numberFlag = is.memberPhoneCheck(memberPhone); // 폰번호 중복체크
			if (numberFlag == 0) { // 문제 없을때 0, 중복일때 1, 정규식 만족못할때 2 , 예외 3
				System.out.println("폰번호 확인 성공.");
				break;		
			} else if (numberFlag == 1) {
				System.out.println("기존에 등록된 번호입니다.");
				continue;
			} else if (numberFlag == 2) {
				System.out.println("010-123(4)-5678 양식에 맞춰주세요.");
				continue;
			} else if (numberFlag == 3) {
				System.out.println("폰번호를 다시 입력하세요.");
				 continue;
			}
		}

		String password = "";
		while (true) {
			System.out.println("패스워드는 특수문자2개이상 포함, 자리수 제한없음");
			System.out.println("패스워드를 입력하세요 : ");
			password = sc.next().trim();
			boolean regResult = is.memberPasswordCheck(password);
			if (regResult) { // true이면 정규식 통과
				break;
			} else {
				System.out.println("비밀번호를 다시 입력하세요.");
				continue;
			}
		}

		String memberName = "";
		while (true) {
			System.out.println("이름은 한글2~6자,영어 4~12자");
			System.out.println("이름을 입력하세요 : ");
			memberName = sc.next().trim();
			boolean regResult = is.memberNameCheck(memberName);
			if (regResult) { // true이면 정규식 통과
				break;
			} else {
				System.out.println("이름을 다시 입력하세요.");
				continue;
			}
		}


		String memberAge = "";
		while (true) {
			System.out.println("나이를 입력하세요 : ");
			memberAge = sc.next().trim();
			boolean regResult = is.memberAgeCheck(memberAge);
			if (regResult) { // true이면 정규식 통과
				break;
			} else {
				System.out.println("나이를 다시 입력하세요.");
				continue;
			}
		}


		String memberGender = "";
		while (true) {
			System.out.println("성별은 남자 또는 여자");
			System.out.println("성별을 입력하세요 : ");
			memberGender = sc.next().trim();
			boolean regResult = is.memberGenderCheck(memberGender);
			if (regResult) { // true이면 정규식 통과
				break;
			} else {
				System.out.println("성별을 다시입력해주세요.");
				continue;
			}
		}

		Map<String, String> join = new HashMap<String, String>();
		join.put("memberName", memberName);
		join.put("memberPhone", memberPhone);
		join.put("memberAge", memberAge);
		join.put("memberGender", memberGender);
		join.put("memberPw", password);

		boolean joinFlag = is.memberJoin(join);

		if (joinFlag) {
			System.out.println("회원 가입 완료");
		} else {
			System.out.println("회원 가입 실패");
		}
	}// 회원가입 끝

	/**
	 * 회원삭제
	 * 2017. 09.05 메서드를 호출한 사람이 관리자/회원인지 확인한 후 회원을 삭제한다.
	 */

	private void deleteMember() {
		String memberPhone = null;
		String password = null;
		int deleteCheck = 0;
		// Map<String, String> deleteMember = new HashMap<String, String>();
		MemberVo phoneCheck = new MemberVo();

		if (sessionVo.getMemberPhone().equals("admin")
				&& sessionVo.getPassword().equals("admin")) { // 관리자일때
			System.out.println("안녕하세요 관리자님");
			while (true) {
				memberList();	//회원 목록을 한번 보여준다.
				System.out.println("삭제할 회원의 폰번호를 입력하세요.");
				memberPhone = sc.next().trim();
				phoneCheck.setMemberPhone(memberPhone); // 관리자는 폰번호만 알고 있으면 된다.
				boolean phoneCheckResult = is.phoneCheck(phoneCheck);
				if (phoneCheckResult) {
					// deleteMember.put("memberPhone", memberPhone);
					deleteCheck = is.deleteMember(phoneCheck);
					if (deleteCheck == 1) {
						System.out.println("회원 삭제 성공");
						break;
					} else if (deleteCheck == 0) {
						System.out.println("회원 탈퇴 실패");
						return;
					}
				} else {
					System.out.println("관리자님 입력하신 회원정보는 DB에 없습니다.");
					return;
				}
			}// while 끝
		} else { // 이걸 호출한 세션 이놈이 일반 회원일때
			System.out.println("안녕하세요 회원님~");
			System.out.println("탈퇴를 위해 다시한번 로그인해 주세요.");
			while (true) {
				System.out.print("탈퇴할 아이디(폰번호)를 입력해 주세요 : ");
				try {
					memberPhone = sc.next().trim();
				} catch (Exception e) {
					System.out.println("올바르지 않는 입력 입니다.");
					continue;
				}
				System.out.print("비밀번호를 입력해 주세요");
				try {
					password = sc.next().trim();
				} catch (Exception e) {
					System.out.println("올바르지 않는 입력 입니다.");
					continue;
				}
				sessionVo.setMemberPhone(memberPhone); // 입력받은 폰번호를 세션 id로 쓰기 위함
				sessionVo.setPassword(password); // 입력받은 password를 세션 password로 쓰기
												// 위함
				int flag = is.logIn(sessionVo);
				if (flag == 2) { // 회원 정보가 맞을때
					// deleteMember.put("memberPhone", memberPhone);
					deleteCheck = is.deleteMember(sessionVo); // 세션 vo를 들고 db에 간다.
															// 앞에서 로그인 체크를
															// 했기때문에..굳이
															// password는필요없는데..
					if (deleteCheck == 1) {
						System.out.println("회원 삭제 성공");
						logOut(); // 삭제를 했기에, 로그아웃하고 세션을 초기화 해준다.
						break;
					} else if (deleteCheck == 0) {
						System.out.println("삭제 실패");
						return;
					}
					break;
				} else if (flag == 3) {
					System.out.println("비밀번호가 틀렸습니다.");
					break;
				} else
					System.out.println("아이디가 맞지 않습니다.");
				break;
			}// while끝
		}// else끝(회원일때)

	}// 회원 삭제 끝

	/**
	 * 회원정보조회 - 회원용
	 */
	private void infoCheck() {
		while (true) {
			// System.out.print("폰번호를 입력해 주세요 : ");
			// String logInPhone = sc.next().trim();
			// System.out.print("비밀번호를 입력해 주세요 : ");
			// String logInPw = sc.next().trim();
			MemberVo mv = is.showInfo(sessionVo.getMemberPhone());
			if (mv != null) {
				System.out.println("이 름\t폰 번 호\t\t나이\t성별");
				System.out.println(mv.getMemberName() + "\t" + mv.getMemberPhone()
						+ "\t" + mv.getMemberAge()	+ "\t" + mv.getMemberGender());
				break;
			}
		}
	}

	/**
	 * 회원정보조회 - 리스트출력- 관리자용
	 */
	private void memberList() {
		List<MemberVo> memberList = is.memberList();
		System.out.println("이름\t폰 번 호\t\t나이\t성별");
		for (int i = 0; i < memberList.size(); i++) {
			System.out.println(memberList.get(i).getMemberName() + "\t"
					+ memberList.get(i).getMemberPhone() + "\t"
					+ memberList.get(i).getMemberAge() + "\t"
					+ memberList.get(i).getMemberGender());

		}
	}// 회원 리스트 출력 끝

	/**
	 * 개인회원용 - 정보 수정 메서드
	 */
	private void infoModify() {
		String memberPhone = null;
		String password = null;
		String memberName = null;
		String memberAge = null;
		String memberGender = null;
		System.out.println("====== 정보수정을 위한 재로그인======");
		while (true) {
			/*------ 정보 수정, 탈퇴시에 재로그인 소스 시작 ------*/
			System.out.println("폰번호를 입력하세요");
			System.out.println("=>");
			memberPhone = sc.next().trim();
			System.out.println("PW를 입력하세요");
			System.out.println("=>");
			password = sc.next().trim();

			sessionVo.setMemberPhone(memberPhone); // 입력받은 폰번호를 세션 id로 쓰기 위함
			sessionVo.setPassword(password); // 입력받은 password를 세션 password로 쓰기 위함

			int flag = is.logIn(sessionVo);
			System.out.println(flag);
			if (flag == -1) {
				System.out.println("예외");
				return;
			} else if (flag == 2) {
				System.out.println("정보를 수정할 폰번호와  PW를 확인했습니다.");
				break;
			} else if (flag == 3) {
				System.out.println("비밀번호가 틀렸습니다.");
				return;
			} else if (flag == 4) {
				System.out.println("아이디가 맞지 않습니다.");
				return;
			}
		}
		/*------ 정보 수정, 탈퇴시에 재로그인 소스 끝 ------*/

		System.out.println("수정할 PW를 입력하세요");
		password = sc.next().trim();

		System.out.println("수정할 이름을 입력하세요");
		memberName = sc.next().trim();

		System.out.println("수정할 나이를 입력하세요");
		memberAge = sc.next().trim();

		System.out.println("수정할 성별을 입력하세요");
		memberGender = sc.next().trim();

		Map<String, String> modify = new HashMap<String, String>();
		modify.put("memberPhone", memberPhone);
		modify.put("memberName", memberName);
		modify.put("password", password);
		modify.put("memberAge", memberAge);
		modify.put("memberGender", memberGender);

		int result = is.infoModify(modify);
		if (result == 0) {
			System.out.println("정보 수정완료!");
			sessionVo.setPassword(password); // 비밀번호가 수정됐을지 모르니, 세션에 바뀐 비밀번호를 다시
											// 저장.
			return;
		} else {
			System.out.println("정보 수정 실패!");
			return;
		}
		// }

	}// 메서드의끝.

	private void logOut() {
		sessionVo = new MemberVo();
		System.out.println("로그아웃 성공!");

		System.out.println("메인메뉴로 돌아갑니다.");
		mainMenu();
	}
	
	/**
	 * style을 추가한다.
	 */
	private void addStyle(){
		while(true){	
			StyleVo sv = new StyleVo();
			String styleName = null;
			int stylePrice = 0;
			
			System.out.println("추가하실 Style 이름을 입력하세요.");
			styleName = sc.next().trim();
			
			try {
				System.out.println("Style의 가격을 입력하세요.");
				stylePrice = Integer.parseInt(sc.next());
			} catch (NumberFormatException e) {
				System.out.println("잘못된 입력입니다.");
				continue;
			}
			
			sv.setStyleName(styleName);
			sv.setStylePrice(stylePrice);
			
			int addStyle = is.addStyle(sv);
			if(addStyle==1){
				System.out.println("Style 값이 중복입니다.");
				return;
			}else if(addStyle==2){
				System.out.println("Style 추가 성공");
				break;
			}else{
				System.out.println("Style 등록 실패");
				return;
			}
		}
	}//addStyle 종료
	
	/**
	 * style을 리스트 출력
	 */
	private void showStyle() {
		List<StyleVo> styleList = is.styleList();
		System.out.println("──────────────");
		System.out.println("스타일\t가격");
		for (int i = 0; i < styleList.size(); i++) {
			System.out.println(styleList.get(i).getStyleName() + "\t"
					+ styleList.get(i).getStylePrice());

		}
		System.out.println("──────────────");
	}// 회원 리스트 출력 끝
	
	/**
	 * style 삭제
	 */
	private void deleteStyle(){
		showStyle();
		while(true){
			String styleName = null;
			System.out.println("삭제할 스타일 이름을 입력하세요.");
			styleName = sc.next().trim();
			int styleDelCheck = is.deleteStyle(styleName);
			//아이디가 없으면 1, 성공적인 삭제 2, 삭제 실패 3
			if(styleDelCheck==1){
				System.out.println("Style 삭제 실패");
				return;
			}if(styleDelCheck==2){
				System.out.println("Style 삭제 성공");
				break;
			}
		}
	}
	
	/**
	 * 디자이너 고용
	 */
	private void hireDesigner(){
		while(true){
			String designerName = null;
			System.out.println("고용할 디자이너의 이름을 입력하세요.");
			designerName = sc.next().trim();
			int hireCheck = is.hireDesigner(designerName);	//디자이너 이름 중복 체크
			if(hireCheck==1){
				System.out.println("디자이너 이름이 중복입니다.");
				return;
			}else if(hireCheck==2){
				System.out.println("새로운 디자이너를 고용했습니다.");
				break;
			}else{
				System.out.println("디자이너 고용 실패");
				return;
			}
			
			
			// designerName 이라는 디자이너가 고용이 되면
			// 이놈에 스케쥴 표를 만들어줘야한다.
			// 스케쥴표에는 designerName과, 예약한 사람의 폰번호,이름,스타일,날짜-시간?
			
			
			
			
			
			
		}//while 끝
	}//디자이너 고용 끝
	
	
	/**
	 *       09. 08 해고할 디자이너가 예약이 있으면 해고 안되도록 설정
	 * 2017. 09. 07 디자이너 해고
	 */
	private void fireDesigner(){
		
		while(true){
			showDesigner();	//현재 디자이너 리스트를 한번 보여준다.
			String designerName = null;
			System.out.println("해고할 디자이너의 이름을 입력하세요.");
			designerName = sc.next().trim();

			boolean nameIsTrue = is.fireNameIsTrue(designerName);//디자이너 리스트에 이사람이 있나 없나...
			if(!nameIsTrue){//이름이 유효하지 않으면
				System.out.println("존재하지 않는 디자이너 입니다.");
				return;
			}else{//유효할 경우에
				boolean reserveCheck = is.fireDesignerReserveCheck(designerName);//이 디자이너가 예약이 있는지 없는지를 다시 체크
				if(reserveCheck){
					System.out.println(designerName + " 디자이너 앞으로 예약된 정보가 있습니다. 예약 취소후 해고하세요.");
					return;
				}else{//예약이 없으면 그대로 진행
					int fireCheck = is.fireDesigner(designerName);
					if(fireCheck==2){
						System.out.println("디자이너 해고 완료");
						break;
					}else{
						System.out.println("디자이너 해고 실패");
						return;
					}
				}
			}
		}//while 끝
	}//디자이너 해고 끝
	
	
	
	
	/**
	 * 2017. 09. 06
	 * 디자이너의 현재 상태(스케쥴) 표시
	 * 예약리스트가 0일경우엔,, 스케쥴을 표시할수가 없다..
	 */
	private void statusDesigner(){
		List<DesignerStatusVo> statusDesignerList = is.statusDesignerList();
		//List<DesignerVo> designerList = is.designerList();
		List<ReservationVo> reservationList = is.reservationList();
		
		while(true){
			if(reservationList.size()==0){
				System.out.println("1건 이상 예약 정보가 있어야 스케쥴이 표시됩니다.");
				return;
			}else{
				System.out.println("디자이너의 스케쥴을 확인하시고 예약하시면 편리합니다.");
				System.out.println("────────────────────────────────────────────");
				System.out.println("번호\t" + "디자이너\t" + "예약 날짜\t\t" + "예약자 폰번호");
				for (int i = 0; i < statusDesignerList.size(); i++) {
					System.out.println(statusDesignerList.get(i).getIndex()
							+ "\t" + statusDesignerList.get(i).getStatusDesignerName()
							+ "\t" + statusDesignerList.get(i).getStatusReserveDate()
							+ "\t" + statusDesignerList.get(i).getStatusReservePhone());
				}System.out.println("────────────────────────────────────────────");
				break;
			}
		}
	}
	
	
	
	/**
	 * 2017. 09. 06
	 * 디자이너의 현재 상태(스케쥴) 표시 관리자버전
	 * 예약리스트가 0일경우엔,, 스케쥴을 표시할수가 없다..
	 */
	private void statusDesignerAdmin(){
		List<DesignerStatusVo> statusDesignerList = is.statusDesignerList();
		//List<DesignerVo> designerList = is.designerList();
		List<ReservationVo> reservationList = is.reservationList();
		
		while(true){
			if(reservationList.size()==0){
				System.out.println("1건 이상 예약 정보가 있어야 스케쥴이 표시됩니다.");
				return;
			}else{
				System.out.println("────────────────────────────────────────────");
				System.out.println("번호\t" + "디자이너\t" + "예약 날짜\t\t" + "예약자 폰번호");
				for (int i = 0; i < statusDesignerList.size(); i++) {
					System.out.println(statusDesignerList.get(i).getIndex()
							+ "\t" + statusDesignerList.get(i).getStatusDesignerName()
							+ "\t" + statusDesignerList.get(i).getStatusReserveDate()
							+ "\t" + statusDesignerList.get(i).getStatusReservePhone());
				}System.out.println("────────────────────────────────────────────");
				break;
			}
		}
	}
	
	/**
	 * 2017. 09. 06
	 * 디자이너 목록을 출력한다.  view
	 */
	
	private void showDesigner(){
		List<DesignerVo> designerList = is.designerList();
		if(designerList.size()==0){
			System.out.println("아직 고용된 디자이너가 없습니다.");
			return;
		}
		System.out.println();
		System.out.println();
		System.out.println("우리 예약헤어의 디자이너 입니다.");
		System.out.print("[");
		System.out.print(designerList.get(0).getDesignerName());
		for (int i = 1; i < designerList.size(); i++) {
			if(designerList.size() != -1){
				System.out.print(", "+designerList.get(i).getDesignerName());
			}
		}
		System.out.println("]");
		System.out.println();
	}//디자이너 목록 출력 끝
	
		

	
	
	
	/**
	 * 결제하기-관리자메뉴
	 */
	private void payment(){
		//결제할 리스트를 출력해준다.
		List<ReservationVo> showReserve = is.showReserve();
		while(true){
			if(showReserve.size()==0){
				System.out.println("결제할 정보가 없습니다.");
				return;
			}else{
				System.out.println("예약 번호\t" + "예약자 폰번호\t\t" + "예약자\t" + "나이\t" + "성별\t" + "디자이너\t" + "스타일\t" + "가격\t" + "예약날짜\t");
				for (int i = 0; i < showReserve.size(); i++) {
					System.out.println(showReserve.get(i));
				}
				break;
			}
		}
		while(true){
			int index = 0;
			try {
				System.out.println("결제할 회원의 예약 번호를 입력하세요 : ");
				index = Integer.parseInt(sc.next());
			} catch (NumberFormatException e) {
				System.out.println("잘못 입력하셨습니다.");
				continue;
			}
			//결제 요청 회원의 예약정보를 vo로 받아서, 예약리스트에서는 삭제를하고, 담아서, 일일매출내역에 새로 기록해준다.
			ReservationVo payInfoVo = new ReservationVo();
			payInfoVo.setReserveIndex(index);
			payInfoVo = is.payInfoVo(payInfoVo);
			if(payInfoVo==null){
				System.out.println("오류가 발생했습니다.");
				return;
			}else{ //예약값을 payInfoVo에 모두 담아왔으므로,, 위의 회원의 예약을 삭제해준다.
				boolean reserveCancel = is.reserveCancel(index);
				if(reserveCancel){
					System.out.println("결제한 금액은 " + payInfoVo.getReservePrice() + "입니다.");
					boolean designerInit = is.DesignerStatusUpdate(index);
					if(designerInit){
			//			System.out.println("디자이너 스케쥴 초기화 성공");
						is.salesListAdd(payInfoVo);//일일 매출 리스트에 결제한 사람의 정보를 추가해준다.
						break;
					}else{
			//			System.out.println("디자이너 스케쥴 초기화 실패");
						return;
					}
				}else{
					System.out.println("결제 실패");
					return;
				}
			}
		}
	}//결제하기 끝
	
	
	/**
	 * 매출내역-총매출
	 */
	private void salesList(){
		List<SalesListVo> salesList = is.getSalesList();
		System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────");
		System.out.println("번호\t" + "고객폰번호\t\t" + "고객이름\t" + "성별\t" + "나이\t" + "담당 디자이너\t" + "스타일\t" + "가격\t" + "방문 날짜");
		for (int i = 0; i < salesList.size(); i++) {
			System.out.println(salesList.get(i));
		}
		System.out.print("──총 매출 : " + salesList.get(0).getTotalPrice());
		System.out.println(" ──────────────────────────────────────────────────────────────────────────────");
		System.out.println();
	}

	/**
	 * 매출내역-디자이너매출
	 */
	private void designerSalesList(){
		salesList();
		while(true){
			System.out.println("조회를 원하는 디자이너의 이름을 입력하세요 : ");
			String designerName = null;
			designerName = sc.next().trim();
			boolean designerCheck = is.salesList(designerName);
			if(!designerCheck){
				System.out.println(designerName + "은(는) 일 한 내역이 없습니다.");
				return;
			}
			System.out.println("─────" + designerName + "의 매출 정보를 출력하겠습니다 ─────────────────────────────────────────────────────────────");
			
			int totalPrice = 0;
			List<SalesListVo> salesList = is.getSalesList();
			System.out.println("번호\t" + "고객폰번호\t\t" + "고객이름\t" + "성별\t" + "나이\t" + "담당 디자이너\t" + "스타일\t" + "가격\t" + "방문 날짜");
			for (int i = 0; i < salesList.size(); i++) {
				if(salesList.get(i).getDesigner().equals(designerName)){
					System.out.println(salesList.get(i).getSalesIndex()
					+"\t"+ salesList.get(i).getVisitorPhone()
					+"\t"+ salesList.get(i).getVisitorName()
					+"\t"+ salesList.get(i).getVisitorGender()
					+"\t"+ salesList.get(i).getVisitorAge()
					+"\t"+ salesList.get(i).getDesigner()
					+"\t\t"+ salesList.get(i).getStyle()
					+"\t"+ salesList.get(i).getPrice()
					+"\t"+ salesList.get(i).getDate() );	
					totalPrice += salesList.get(i).getPrice();
				}
			}
			System.out.println("──"+designerName+" 매출 : " + totalPrice + " ──────────────────────────────────────────────────────────────────────");
			System.out.println();
		//	System.out.print("매출합계 : ");
		//	System.out.println(dailySalesList.get(0).getTotalPrice());
			break;
		}
	
	}


}// 클래스 끝