package package_DataBase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import package_Vo.DesignerStatusVo;
import package_Vo.SalesListVo;
import package_Vo.DesignerVo;
import package_Vo.MemberVo;
import package_Vo.ReservationVo;
import package_Vo.StyleVo;



public class DataBase {
	private int reservationIndex = 0;
	private int designerStatusIndex = 0;
	private int salesIndex = 0;
	//각 Vo들의 List
	private List<MemberVo> 			memberList			= new ArrayList<MemberVo>();		
	private List<ReservationVo>		reservationList 	= new ArrayList<ReservationVo>();	
	private List<StyleVo> 			styleList 			= new ArrayList<StyleVo>();			
	private List<DesignerVo>		designerList		= new ArrayList<DesignerVo>();		
	private List<SalesListVo> 		salesList			= new ArrayList<SalesListVo>();		
	private List<DesignerStatusVo> 	statusDesignerList 	= new ArrayList<DesignerStatusVo>();

	
	//	private String adminId = "1234";
//	private String adminPw = "1234";
	
	
	public DataBase(){
									//	  이 름	 폰 번 호	  		 비밀번호	    나이     성별"
		MemberVo mvInit1 = new MemberVo("관리자", "admin", "admin", "99", "남자", true);
		MemberVo mvInit2 = new MemberVo("전광호", "010-4613-6431", "1234", "31", "남자", false);
		MemberVo mvInit3 = new MemberVo("이지영", "010-1234-5678", "1234", "26", "여자", false);
		MemberVo mvInit4 = new MemberVo("테스트", "010-1111-2222", "test", "20", "남자", false);
		MemberVo mvInit5 = new MemberVo("테스트", "1", "1", "20", "남자", false);
		
		memberList.add(mvInit1);
		memberList.add(mvInit2);
		memberList.add(mvInit3);
		memberList.add(mvInit4);
		memberList.add(mvInit5);
		
		StyleVo svInit1 = new StyleVo("커트" , 12000);
		StyleVo svInit2 = new StyleVo("펌" , 50000);
		StyleVo svInit3 = new StyleVo("염색" , 70000);
		StyleVo svInit4 = new StyleVo("뿌염" , 30000);
		styleList.add(svInit1);
		styleList.add(svInit2);
		styleList.add(svInit3);
		styleList.add(svInit4);

		
		DesignerVo dvInit0 = new DesignerVo("아무고토모타쥬");  
		DesignerVo dvInit1 = new DesignerVo("나초보");  
		DesignerVo dvInit2 = new DesignerVo("개잘해");  
		DesignerVo dvInit3 = new DesignerVo("존망");  
		DesignerVo dvInit4 = new DesignerVo("평타");  
		
		designerList.add(dvInit0);
		designerList.add(dvInit1);
		designerList.add(dvInit2);
		designerList.add(dvInit3);
		designerList.add(dvInit4);
	}
	
	



	/**
	 * 입력한 폰번호와 기존 폰번호 중복값 확인
	 * @param memberPhone
	 * @return
	 */
	public boolean memberPhoneCheck(String memberPhone) {
		for (int i = 0; i < memberList.size(); i++) {
			if(memberList.get(i).getMemberPhone().equals(memberPhone)){
				//새로운 Name과 기존 Name 비교 후 중복값이 있으면 true를 반환
				return true;
			}
		}	return false;
	}
	
	
	public String memberName(String memberName){
		return memberName;
	}
	
	/**
	 * 회원 가입 메서드
	 * @param join
	 * @return	가입 성공시 true, 실패시 false 반환
	 */
	public boolean memberJoin(Map<String, String> join){
		MemberVo mv = new MemberVo();
		mv.setMemberName(join.get("memberName"));
		mv.setMemberAge(join.get("memberAge"));
		mv.setMemberGender(join.get("memberGender"));
		mv.setMemberPhone(join.get("memberPhone"));
		mv.setPassword(join.get("memberPw"));
	//	mv.setMemberIndex(index++);
		
		boolean result = true;
		try {
			memberList.add(mv);
			result = true;
		} catch (Exception e) {
			result = false;
		}
		return result;
	}
	
	/**
	 * memberList를 db에서 view로 보내준다.
	 * @return
	 */
	public List<MemberVo> memberList(){
		return memberList;
		
	}


	/**
	 * 회원/관리자 공통 로그인 메서드
	 * @param logIn
	 * @return 관리자1, 회원정상2, 회원비번x3, 회원아이디x4, 예외-1
	 */
	public int logIn(MemberVo mv) {
		if("admin".equals(mv.getMemberPhone()) && "admin".equals(mv.getPassword())){
			return 1;	// 폰번호와 비밀번호로 관리자라고 구분되면 1값 반환
		}
		for(int i = 0; i < memberList.size(); i++){
			if(memberList.get(i).getMemberPhone().equals(mv.getMemberPhone())){
				if(!memberList.get(i).getPassword().equals(mv.getPassword())){
					return 3; //비밀번호 오류
				}else{
					return 2;
				}
			}
		}
		return 4;
	}
		
	
	/**
	 * 회원 삭제 
	 * @param temp
	 * @return 삭제성공시 1반환, 실패시 0반환
	 */
	public int deleteMember(MemberVo phoneCheck) {
		 int result = 0;
		 for (int i = 0; i < memberList.size(); i++) {
			 if(memberList.get(i).getMemberPhone().equals(phoneCheck.getMemberPhone())){
					 memberList.remove(i);
					 result = 1;
			 }
		}
		return result;
	}

	
	/**
	 * 회원용 - 정보수정 메서드 (포인트 수정 못함)
	 * @param modify
	 * @return 성공하면 0, 실패하면 1 반환
	 */
	public int infoModify(Map<String, String> modify){
//		modify.put("memberPHone", logInPhone);
//		modify.put("memberName", logInName);
//		modify.put("password",logInPw);
//		modify.put("memberAge",logInAge);
//		modify.put("memberGender",logInGender);
		for(int i = 0; i < memberList.size(); i++){
			if(memberList.get(i).getMemberPhone().equals(modify.get("memberPhone"))){
				memberList.get(i).setMemberName(modify.get("memberName"));
				memberList.get(i).setPassword(modify.get("password"));
				memberList.get(i).setMemberAge(modify.get("memberAge"));
				memberList.get(i).setMemberGender(modify.get("memberGender"));
				return 0;
			}
		}
		return 1;
	}

/**
 * 회원정보 조회 : 회원용
 * @param memberPhone
 * @return
 */
	public MemberVo showInfo(String memberPhone) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberPhone().equals(memberPhone)) {
				return memberList.get(i);
			}	
		}
		return null;
	}




	/**
	 * 폰번호(id) 중복 검사, 
	 * @param phoneCheck
	 * @return 중복이면 true반환, 안되면 false반환
	 */
	public boolean phoneCheck(MemberVo phoneCheck) {
		for (int i = 0; i < memberList.size(); i++) {
			if(memberList.get(i).getMemberPhone().equals(phoneCheck.getMemberPhone())){	//DB에 입력받은 번호가 있는지 확인
				return true;
			}
		}
		return false;
	}




/**
 * 스타일 추가
 * @param styleVo sv를 가지고 온다.
 * @return 값중복시 1, 성공적인등록 2, 등록실패 3
 */
	public int addStyle(StyleVo sv) {
		int flag = 3;
		StyleVo add = new StyleVo();	
		for (int i = 0; i < styleList.size(); i++) {
			if(styleList.get(i).getStyleName().equals(sv.getStyleName())){//db와 입력받은 스타일 이름이 같은지 검사
				flag = 1;	//스타일 이름이 중복되면 1
				return flag;
			}
		}
	//	add.setStyleIndex(index++);
		add.setStyleName(sv.getStyleName());
		add.setStylePrice(sv.getStylePrice());
		boolean result = styleList.add(add);	
			if(result){
				flag = 2;	//중복되지 않고 && 성공적인 등록 2
				return flag;
			}
		return flag;
	}




/**
 * style, 리스트로 출력
 * @return
 */
public List<StyleVo> styleList() {
	return styleList;
}




/**
 * style 삭제
 * @param styleName
 * @return 실패 1, 성공적인 삭제 2
 */
public int deleteStyle(String styleName) {
	int result = 1;
	for (int i = 0; i < styleList.size(); i++) {
		if(styleList.get(i).getStyleName().equals(styleName)){	//입력받은 name이 db에 있을경우
			styleList.remove(i);		//제거
			result = 2;					//삭제 성공 
			return result;		
		}
	}
	return result;
}




/**
 * 디자이너 고용
 * @param designerName
 * @return	기존에 있는 디자이너들과 이름이 중복이면 1 , 추가성공 2, 추가 실패 3
 */
public int hireDesigner(String designerName) {
	int result = 0;
	for (int i = 0; i < designerList.size(); i++) {
		if(designerList.get(i).getDesignerName().equals(designerName)){
			result = 1;	//디자이너 이름이 중복일경우
			return result;
		}
	}
	DesignerVo dvAdd = new DesignerVo();
	dvAdd.setDesignerName(designerName);
//	dvAdd.setReserveCheck("가능");
//	dvAdd.setDate("");
//	dvAdd.setReservePhone("");
	boolean dvAddResult = designerList.add(dvAdd);
	
	if(dvAddResult){
		result = 2; //추가 성공
		return result;
	}else{
		result = 3;	//추가 실패
		return result;
	}
}




/**
 * 디자이너 해고
 * @param designerName
 * @return	해고 실패 1, 해고 성공 2
 */
public int fireDesigner(String designerName) {
	int result = 1;
	for (int i = 0; i < designerList.size(); i++) {	//입력받은 디자이너 이름을 리스트에서 찾아서
		if(designerList.get(i).getDesignerName().equals(designerName)){	//찾아서 있을때
			designerList.remove(i);	//모든 정보 삭제
			result = 2;
		}
	}
	
	return result;
}





public List<DesignerVo> designerList() {
	return designerList;
}




/**
 * 예약할 디자이너가 디자이너-리스트에 있는지 체크
 * @param designerSel
 * @return 있으면 true, 없으면 false
 */
public boolean designerNameCheck(String designerSel) {
	for (int i = 0; i < designerList.size(); i++) {
		if(designerList.get(i).getDesignerName().equals(designerSel)){
			return true;
		}
	}
	return false;
}




/**
 * 예약할 스타일이 있는 상품인지 체크
 * 2017-09-06
 * @param vo
 * @return 있으면 true, 없으면 false
 */
public StyleVo styleCheck(StyleVo vo) {
	
	for (int i = 0; i < styleList.size(); i++) {
		if (vo.getStyleName().equals(styleList.get(i).getStyleName())){
			return styleList.get(i);
		}
	}
	return null;
}




/**
 * session값을 얻기 위한 List
 * @param sessionVo
 * @return
 */
	public MemberVo getSession(MemberVo sessionVo) {
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getMemberPhone().equals(sessionVo.getMemberPhone())
					&& memberList.get(i).getPassword().equals(sessionVo.getPassword())) {
				sessionVo.setMemberPhone(memberList.get(i).getMemberPhone());
				sessionVo.setMemberName(memberList.get(i).getMemberName());
				sessionVo.setMemberAge(memberList.get(i).getMemberAge());
				sessionVo.setMemberGender(memberList.get(i).getMemberGender());
		//		sessionVo.setMemberPoint(memberList.get(i).getMemberPoint());
				return sessionVo;
			}
		}
		return null;
	}



	/**
	 * 예약하기
	 * @param 예악정보가 있는 Vo r을 가지고 온다.
	 * @return 성공 true / 실패 false 반환
	 */
	public boolean reserve(ReservationVo r) {
		for (int i = 0; i < reservationList.size(); i++) {
			if (r.getReserveDate().equals(reservationList.get(i).getReserveDate())
					&& r.getReserveStyle().equals(reservationList.get(i).getReserveStyle())
					&& r.getReserveName().equals(reservationList.get(i).getReserveName())) {
				return false;//같은날짜에 같은사람이 같은스타일은 안되게 하기~
			}
		}
		r.setReserveIndex(reservationIndex++);
		return reservationList.add(r);		//예약하기에서 끌어모은 디자이너, 스타일, 날짜정보를 r이라는 vo 하나로 담아서 Add함
		// ReservationVo rv = new ReservationVo();
		// rv.setReserveIndex(index++);
		// rv.setReserveName(r.getReserveName());
		// rv.setReservePhone(r.getReservePhone());
		// rv.setReserveGender(r.getReserveGender());
		// rv.setReserveAge(r.getReserveAge());
		// r.setReserveDesigner(r.getReserveDesigner());
		// rv.setReserveStyle(r.getReserveStyle());
		// rv.setReservePrice(r.getReservePrice());
		// rv.setReserveDate(r.getReserveDate());
	}





	public List<ReservationVo> showReserve() {
		return reservationList;
	}







	/**
	 * 예약정보조회_회원 : 진행시 예약된게 없는상태에서 조회를 시도하는지 체크하는 부분
	 * @param 현재 session의 memberPhone정보
	 * @return 예약정보 존재하면 true / 없으면 false
	 */
	public boolean reserveCheck(String memberPhone) {
		for (int i = 0; i < reservationList.size(); i++) {
			if(reservationList.get(i).getReservePhone().equals(memberPhone)){
				return true;
			}
		}
		return false;
	}

	/**
	 * 예약확인용 : 예약조회 / 예약취소전에 해당 회원정보가 예약리스트에 있는지 체크하는 기능
	 * @param memberPhone
	 * @return
	 */
	public String preReserveCheck(String memberPhone) {
		for (int i = 0; i < reservationList.size(); i++) {
			if(reservationList.get(i).getReservePhone().equals(memberPhone)){
				return reservationList.get(i).getReserveDesigner();
				
			}
		}
		return null;
	}

	/**
	 * 개인회원-예약삭제용
	 * @param String inputName, int inputIndex
	 * @return 삭제성공 designer이름 반환 / 삭제실패 null
	 */
	public String reserveCancel(String inputName, int inputIndex) {
		String designerTemp = null;
		for (int i = 0; i < reservationList.size(); i++) {
			if (reservationList.get(i).getReserveIndex() == inputIndex && 
					reservationList.get(i).getReserveName().equals(inputName)) {
				designerTemp = reservationList.get(i).getReserveDesigner();
				reservationList.remove(i);
				return designerTemp;
			}
		}
		return null;
	}




	/**
	 * 항상! 예약리스트를 지웠으면, 그 예약과 연동된 디자이너 리스트의 값도 초기화 해주어야 함
	 * @param memberPhone
	 * @return
	 */
	public boolean designerInit(String memberPhone) {
		DesignerVo temp = new DesignerVo();
	//	temp.setReserveCheck("가능");
	//	temp.setDate("");
	//	temp.setReservePhone("");
		
		for (int i = 0; i < designerList.size(); i++) {
//			if(designerList.get(i).getReservePhone().equals(memberPhone)){
//				temp.setDesignerName(designerList.get(i).getDesignerName());
//				designerList.remove(i);
//			}
		}
		
//		DesignerVo rDC = new DesignerVo();			//디자이너 리스트에 예약 불가능을 보여주기 위해
//		rDC.setDesignerName(r.getReserveDesigner());     //예약된 디자이너 이름
//		rDC.setDate(r.getReserveDate());				  //예약된 날짜
//		rDC.setReserveCheck("불가능");
//		rDC.setReservePhone(r.getReservePhone());
//		is.reserveDateCheck(rDC);
//		
		boolean result = designerList.add(temp);
		
		
		return result;
	}




	/**
	 * 회원의 결제 정보를 담을 Vo.
	 * @param payInfoVo에 폰번호를 담아 보내고
	 * @return payInfoVo에 모든 예약정보를 받아서 반환한다.
	 */
	public ReservationVo payInfoVo(ReservationVo payInfoVo) {
		for (int i = 0; i < reservationList.size(); i++) {
			if( reservationList.get(i).getReserveIndex()==(payInfoVo.getReserveIndex())){
				payInfoVo.setReserveIndex(reservationList.get(i).getReserveIndex());
				payInfoVo.setReserveName(reservationList.get(i).getReserveName());
				payInfoVo.setReservePhone(reservationList.get(i).getReservePhone());
				payInfoVo.setReserveGender(reservationList.get(i).getReserveGender());
				payInfoVo.setReserveAge(reservationList.get(i).getReserveAge());
				payInfoVo.setReserveDesigner(reservationList.get(i).getReserveDesigner());
				payInfoVo.setReserveStyle(reservationList.get(i).getReserveStyle());
				payInfoVo.setReservePrice(reservationList.get(i).getReservePrice());
				payInfoVo.setReserveDate(reservationList.get(i).getReserveDate());
				return payInfoVo;
			}
		}
		return null;
	}




	/**
	 * 결제자 정보를 일일매출에 추가해주기 위한 메서드
	 * @param payInfoVo
	 * @return	성공 true / 실패 false
	 */
	public boolean salesListAdd(ReservationVo payInfoVo) {
		SalesListVo dSLVadd = new SalesListVo();
		
		dSLVadd.setSalesIndex(salesIndex++);
		dSLVadd.setVisitorName(payInfoVo.getReserveName());
		dSLVadd.setVisitorPhone(payInfoVo.getReservePhone());
		dSLVadd.setVisitorGender(payInfoVo.getReserveGender());
		dSLVadd.setVisitorAge(payInfoVo.getReserveAge());
		dSLVadd.setDesigner(payInfoVo.getReserveDesigner());
		dSLVadd.setStyle(payInfoVo.getReserveStyle());
		dSLVadd.setPrice(payInfoVo.getReservePrice());
		dSLVadd.setDate(payInfoVo.getReserveDate());
		dSLVadd.setTotalPrice(dSLVadd.getTotalPrice()+payInfoVo.getReservePrice());
		if(salesList.size() != 0){
			salesList.get(0).setTotalPrice(salesList.get(0).getTotalPrice()+payInfoVo.getReservePrice());
		}
		return salesList.add(dSLVadd);
		
	}




	/**
	 * 일일매출정보 리스트를 받아온다
	 * @return salesList를 반환한다.
	 */
	public List<SalesListVo> getSalesList() {
		return salesList;
	}




	/**
	 * 매출에 출력을 원하는 디자이너가 존재하는지 안하는지.
	 * @param designerName
	 * @return 있으면 true / 없으면 false
	 */
	public boolean salesList(String designerName) {
		for (int i = 0; i < salesList.size(); i++) {
			if(salesList.get(i).getDesigner().equals(designerName)){
				return true;
			}
		}
		return false;
	}


	
	/**
	 * 2017. 09. 06
	 * 디자이너의 현재 상태(스케쥴) 표시
	 * @return 리스트가 비어있으면 null , 비어있지 않으면 to.String
	 */
	public String getStatusDesigner(){
		String result = null;
		if(statusDesignerList.size()==0){
			return null;
		}else{
			for(int i = 0; i < statusDesignerList.size(); i++) {
				result += statusDesignerList.get(i).toString();
			}
			return result;
		}
			
	}




/**
 * 예약자 정보를 vo로 담아와서, 디자이너 스케쥴표에 저장
 * @param dsVo
 */
	public boolean DesignerStatusUpdate(DesignerStatusVo dsVo) {
		dsVo.setIndex(designerStatusIndex++);
		 return statusDesignerList.add(dsVo);
		
//		for (int i = 0; i < designerList.size(); i++) {
//		if(designerList.get(i).getDesignerName().equals(rDC.getDesignerName())){
//			designerList.set(i, null);
//			designerList.set(i, rDC);
//			return true;
//		}
//	}
//	return false;
//	DesignerVo test = new DesignerVo();
//	test.setDesignerName(rDC.getDesignerName());
//	test.setReserveCheck(rDC.getReserveCheck());
//	test.setDate(rDC.getDate());
//	test.setReservePhone(rDC.getReservePhone());
//	return designerList.add(test);
		
		
	}




	/**
	 * 예약취소시, 예약자의 아이디(세션정보)를 이용해서, 기존에 예약한 날짜 값을 가질러 db에 가기위한 메서드
	 * @param memberPhone
	 * @return String형 날짜정보
	 */
	public String ReserveDateCheck(String memberPhone) {
		for (int i = 0; i < reservationList.size(); i++) {
			if(memberPhone.equals(reservationList.get(i).getReservePhone())){
				return reservationList.get(i).getReserveDate();
			}
		}
		return null;
	}




/**
 * 개인회원용 디자이너 스케쥴 초기화 메서드
 * 예약취소시에 스케쥴도 없애 주어야 하기 때문
 * @param designerStatusInit
 * @return
 */
	public boolean designerStatusInit(DesignerStatusVo designerStatusInit) {
		for (int i = 0; i < statusDesignerList.size(); i++) {
			if (statusDesignerList.get(i).getStatusDesignerName()
					.equals(designerStatusInit.getStatusDesignerName())
					&& statusDesignerList.get(i).getStatusReserveDate()
							.equals(designerStatusInit.getStatusReserveDate())
					&& statusDesignerList.get(i).getStatusReservePhone()
							.equals(designerStatusInit.getStatusReservePhone())) {
				System.out.println("for진입");
				statusDesignerList.remove(i);
			//	statusDesignerList.set(i, rDC);
				return true;
			}
		}

		return false;
	}





	/**
	 * 2017-09-08
	 * 해고하기전에 요청한 이름이 디자이너 리스트에 있는지 없는지 
	 * @param designerName
	 * @return 있으면 true / 없으면 false
	 */
	public boolean fireNameIsTrue(String designerName) {
		for (int i = 0; i < designerList.size(); i++) {
			if(designerList.get(i).getDesignerName().equals(designerName)){
				return true;
			}
		}
		return false;
	}




/**
 * 2017-09-08
 * 디자이너 해고전에, 예약목록은 없는지, 상태리스트에서 체크한다.
 * @param designerName
 * @return 예약 있으면 true , 없으면 false
 */
	public boolean fireDesignerReserveCheck(String designerName) {
		for (int i = 0; i < statusDesignerList.size(); i++) { //디자이너 상태 리스트에서
			if(statusDesignerList.get(i).getStatusDesignerName().equals(designerName)){//예약된정보가 있는지
				return true;//있으면 트루
			}
		}
		return false;
	}




/**
 * DB에서 statusDesignerList 받아온다.
 * @return
 */
public List<DesignerStatusVo> statusDesignerList() {
	return statusDesignerList;
}




/**
 * DB에서 reservationList 받아온다.
 * @return
 */
public List<ReservationVo> reservationList() {
	return reservationList;
}




/**
 * 관리자-예약삭제용
 * @param int inputIndex
 * @return 삭제성공 designer이름 반환 / 삭제실패 null
 */
public String reserveCancelAdmin(int inputIndex) {
	String designerTemp = null;
	for (int i = 0; i < reservationList.size(); i++) {
		if (reservationList.get(i).getReserveIndex() == inputIndex) {
			designerTemp = reservationList.get(i).getReserveDesigner();
			reservationList.remove(i);
			return designerTemp;
		}
	}
	return null;
}




/**
 * 결제 진행시에 결제한 해당 예약을,,  예약리스트에서 없애주는놈.
 * @param index
 * @return 성공하면 true, 실패하면 false
 */
	public boolean reserveCancel(int index) {
		
		
		//String designerTemp = null;
		
		for (int i = 0; i < reservationList.size(); i++) {
			if (reservationList.get(i).getReserveIndex() == index){
				//designerTemp = reservationList.get(i).getReserveDesigner();
				reservationList.remove(i);
				//return designerTemp;
				return true;
			}
		}
		//return null;
		
		
		
		return false;
	}




/**
 * 예약리스트 인덱스번호 = 디자이너스케쥴 인덱스번호 이기때문에
 * 삭제되는놈의 index를 이용해서, 양쪽 리스트의 값을 모두 삭제할 수 있다.
 * @param index
 * @return 성공 true / 실패 false
 */
public boolean DesignerStatusUpdate(int index) {
	for (int i = 0; i < statusDesignerList.size(); i++) {
		if(statusDesignerList.get(i).getIndex()==index){
			statusDesignerList.remove(i);
			return true;
		}
	}
	return false;
}



}

