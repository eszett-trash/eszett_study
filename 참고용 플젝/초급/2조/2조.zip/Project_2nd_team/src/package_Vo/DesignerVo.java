package package_Vo;



public class DesignerVo {
//	private int DesignerIndex;			//디자이너가 생성될때 생성되는 index번호
	private String DesignerName;		//디자이너의 이름

	
	
	
	
	
	public DesignerVo(){
		
	}
	
	
	
	public DesignerVo(String designerName) {
		super();
	//	DesignerIndex = designerIndex;
		DesignerName = designerName;
	//	this.reserveCheck = reserveCheck;
	//	this.date = date;
	//	this.reservePhone = reservePhone;
	}



	public String getDesignerName() {
		return DesignerName;
	}



	public void setDesignerName(String designerName) {
		DesignerName = designerName;
	}



	@Override
	public String toString() {
		return DesignerName +"\t";
	}



	
	
	
	
}
