package package_Vo;

public class SalesListVo {
	
	private int 	salesIndex;
	private String 	visitorPhone;		//방문자(결제자) 폰번호
	private String 	visitorName;		//방문자(결제자) 이름
	private String 	visitorAge;			//방문자(결제자) 나이
	private String 	visitorGender;		//방문자(결제자) 성별
	
	private String	Designer;			//일을 한 디자이너 정보[저장된 장소 index번호가 동일하다]
	private String 	Style;				//서비스 받은 스타일 정보[저장된 장소 index번호가 동일하다]
	private int		Price;				//서비스 받은 스타일의 가격
	private String 	Date;				//미용실 예약 날짜 = 방문 날짜 = 결제날짜
	
	private int		 totalPrice;		//전체매출
	
	
	

	

	public int getSalesIndex() {
		return salesIndex;
	}

	public void setSalesIndex(int salesIndex) {
		this.salesIndex = salesIndex;
	}

	public String getVisitorPhone() {
		return visitorPhone;
	}

	public void setVisitorPhone(String visitorPhone) {
		this.visitorPhone = visitorPhone;
	}

	public String getVisitorName() {
		return visitorName;
	}

	public void setVisitorName(String visitorName) {
		this.visitorName = visitorName;
	}

	public String getVisitorAge() {
		return visitorAge;
	}

	public void setVisitorAge(String visitorAge) {
		this.visitorAge = visitorAge;
	}

	public String getVisitorGender() {
		return visitorGender;
	}

	public void setVisitorGender(String visitorGender) {
		this.visitorGender = visitorGender;
	}

	public String getDesigner() {
		return Designer;
	}

	public void setDesigner(String designer) {
		Designer = designer;
	}

	public String getStyle() {
		return Style;
	}

	public void setStyle(String style) {
		Style = style;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
//		방문자번호, 방문자이름,  방문자 성별 , 방문자 나이, 디자이너 스타일 가격 예약날짜 );
		return salesIndex + "\t" + visitorPhone + "\t" + visitorName + "\t" + visitorAge 
				 + "\t" + visitorGender + "\t" + Designer
				 + "\t\t" + Style + "\t" + Price + "\t" + Date;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}

