package package_Vo;

public class DesignerStatusVo {
	
	
	private int index;					//현재 Vo가 생성될 때 = 예약이 발생할때, 사용할 index
	private String statusDesignerName;	//디자이너의 이름
	private String statusReserveDate;	//예약 날짜
	private String statusReservePhone;	//예약한 회원의 폰번호
	
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getStatusDesignerName() {
		return statusDesignerName;
	}
	public void setStatusDesignerName(String statusDesignerName) {
		this.statusDesignerName = statusDesignerName;
	}
	public String getStatusReserveDate() {
		return statusReserveDate;
	}
	public void setStatusReserveDate(String statusReserveDate) {
		this.statusReserveDate = statusReserveDate;
	}
	public String getStatusReservePhone() {
		return statusReservePhone;
	}
	public void setStatusReservePhone(String statusReservePhone) {
		this.statusReservePhone = statusReservePhone;
	}
	
	@Override
	public String toString() {
		return  index + "\t" +
				statusDesignerName + "\t" +
				statusReserveDate + "\t" +
				statusReservePhone+"\n" ;
	}

	
	







}
