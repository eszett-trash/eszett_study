package package_Vo;

public class StyleVo {
	
//	private int styleIndex;		//별도의 인덱스 번호
	
	private String styleName;	//커트, 펌, 염색 등... 판매한 Style들
	
	private int stylePrice;		//스타일의 가격
	
	
	
	
	public StyleVo(){
		
	}
	
	public StyleVo(String styleName, int stylePrice) {
		super();
	//	this.styleIndex = styleIndex;
		this.styleName = styleName;
		this.stylePrice = stylePrice;
	}
	
	
	public String getStyleName() {
		return styleName;
	}
	public void setStyleName(String styleName) {
		this.styleName = styleName;
	}
	public int getStylePrice() {
		return stylePrice;
	}
	public void setStylePrice(int stylePrice) {
		this.stylePrice = stylePrice;
	}
	@Override
	public String toString() {
		return styleName+"\t"+ styleName+"\t"+
				stylePrice+"\t"+ stylePrice ;
	}


	
	

}
