package package_Vo;

public class ReservationVo {
	
	private int reserveIndex;			//index
	
	private String reservePhone;		//예약자의 폰번호
	private String reserveName;			//예약자의 이름
	private String reserveAge;			//예약자의 나이
	private String reserveGender;		//예약자의 성별
	
	private String	reserveDesigner;	//예약한 디자이너 정보[저장된 장소 index번호가 동일하다]
	private String 	reserveStyle;		//예약한 스타일 정보[저장된 장소 index번호가 동일하다]
	private int 	reservePrice;		//예약한 스타일의 가격
	private String	reserveDate;		//미용실 예약 날짜
	
	
	
	
	public int getReserveIndex() {
		return reserveIndex;
	}

	public void setReserveIndex(int reserveIndex) {
		this.reserveIndex = reserveIndex;
	}



	




	public String getReservePhone() {
		return reservePhone;
	}

	public void setReservePhone(String reservePhone) {
		this.reservePhone = reservePhone;
	}

	public String getReserveName() {
		return reserveName;
	}

	public void setReserveName(String reserveName) {
		this.reserveName = reserveName;
	}

	public String getReserveAge() {
		return reserveAge;
	}

	public void setReserveAge(String reserveAge) {
		this.reserveAge = reserveAge;
	}

	public String getReserveGender() {
		return reserveGender;
	}

	public void setReserveGender(String reserveGender) {
		this.reserveGender = reserveGender;
	}

	public String getReserveDesigner() {
		return reserveDesigner;
	}

	public void setReserveDesigner(String reserveDesigner) {
		this.reserveDesigner = reserveDesigner;
	}

	public String getReserveStyle() {
		return reserveStyle;
	}

	public void setReserveStyle(String reserveStyle) {
		this.reserveStyle = reserveStyle;
	}

	public int getReservePrice() {
		return reservePrice;
	}

	public void setReservePrice(int reservePrice) {
		this.reservePrice = reservePrice;
	}

	public String getReserveDate() {
		return reserveDate;
	}

	public void setReserveDate(String reserveDate) {
		this.reserveDate = reserveDate;
	}

	@Override
	public String toString() {
		return  
				reserveIndex + "\t" + reservePhone + "\t" + reserveName + "\t"
				+ reserveAge + "\t" + reserveGender + "\t" + reserveDesigner + "\t"
				+ reserveStyle + "\t" + reservePrice + "\t" + reserveDate;
	}

	
	
	
		
}
