package package_Vo;

public class MemberVo {
//	private int memberIndex;			//index
	private String memberName;			//회원 이름
	private String memberPhone;			//회원 휴대폰번호
	private String password;			//회원 패스워드
	private String memberAge;			//회원 나이
	private String memberGender;		//회원 성별
	private boolean isAdmin;			//관리자 여부
	
	
	public MemberVo(){		//기본 생성자
		
	}

	// 매개변수가 있는 생성자, 회원의 기본정보...

	public MemberVo(String memberName, String memberPhone,
			String password, String memberAge, String memberGender,
			boolean isAdmin) {
		super();
//		this.memberIndex = memberIndex;
		this.memberName = memberName;
		this.memberPhone = memberPhone;
		this.password = password;
		this.memberAge = memberAge;
		this.memberGender = memberGender;
//		this.memberPoint = memberPoint;
		this.isAdmin = isAdmin;
	}


	

	

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberPhone() {
		return memberPhone;
	}

	public void setMemberPhone(String memberPhone) {
		this.memberPhone = memberPhone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMemberAge() {
		return memberAge;
	}

	public void setMemberAge(String memberAge) {
		this.memberAge = memberAge;
	}

	public String getMemberGender() {
		return memberGender;
	}

	public void setMemberGender(String memberGender) {
		this.memberGender = memberGender;
	}



	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}



	@Override
	//"번호\t이 름\t폰 번 호\t나이\t성별\t포인트"
	public String toString() {
		return memberName +"\t"+ memberPhone +"\t"+ password +"\t"+
				memberAge +"\t"+ memberGender +"\t"+ isAdmin ;
	}

	
}
