package Theater_VO;

public class MovieVO {
	
	private int mIndex;//인덱스
	private String mName;  //영화이름
	private String mRuntime; //상영시간
	private String mRoom; //상영관
	
	
	public final int getmIndex() {
		return mIndex;
	}
	public final void setmIndex(int mIndex) {
		this.mIndex = mIndex;
	}
	public final String getmName() {
		return mName;
	}
	public final void setmName(String mName) {
		this.mName = mName;
	}
	public final String getmRuntime() {
		return mRuntime;
	}
	public final void setmRuntime(String mRuntime) {
		this.mRuntime = mRuntime;
	}
	public final String getmRoom() {
		return mRoom;
	}
	public final void setmRoom(String mRoom) {
		this.mRoom = mRoom;
	}
	
	

	
	
}
