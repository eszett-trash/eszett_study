package Theater_Main;

public class ServiceImplement implements ServiceInter{

}
