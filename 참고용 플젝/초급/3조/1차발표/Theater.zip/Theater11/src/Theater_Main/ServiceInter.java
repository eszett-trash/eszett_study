package Theater_Main;

public interface ServiceInter {

}
