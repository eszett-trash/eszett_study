package Theater_Main;

public class View {

	public void mainMenu() {
		// TODO Auto-generated method stub
		
		
	}

}

